# PNX 3.0.6 / PNX-Terra cross-chunk generation — stage 7

Target PNX commit: `c57499365737654eca32df008751ef6bca5af142`.

## Purpose

This stage closes two lifecycle hazards in the pinned PNX pipeline and makes the asynchronous stage extension usable from both asynchronous and synchronous generation entry points.

## Changes

1. `GenerateStage.applyAsync(context)` is the non-blocking stage contract. Existing stages retain their `apply()` implementation; dependency-aware stages may override `applyAsync()`.
2. `Generator.syncGenerate()` now composes `applyAsync()` futures and waits only on the synchronous caller thread. It no longer bypasses an asynchronous stage by calling `apply()` directly.
3. `Generator.asyncGenerate()` gains explicit failure callbacks. Stage failures, executor submission failures, and callback failures are surfaced rather than silently abandoning the pipeline.
4. `Level.generateChunk()` releases its in-flight reservation on both success and failure. This fixes the stuck `chunkGenerationQueue` condition when a stage fails.
5. `Level.syncGenerateChunk()` releases its reservation in `finally`, including exceptional exits.
6. `PopulatorStage` marks the chunk `POPULATED` only after all populators have run and buffered block updates have been flushed.
7. `ChunkState.canSend()` now requires `FINISHED`, preventing the chunk-send path from treating a chunk as ready while population, lighting, or finalization remains incomplete.

## Why the sendability change is necessary

At the pinned revision `ChunkState.canSend()` returned true from `POPULATED`, while `PopulatorStage.apply()` set `POPULATED` at method entry. This made a chunk publishable before its population writes were applied. The final state is set by `FinishedStage` after `LightPopulationStage`; requiring `FINISHED` makes that boundary explicit.

## Validation performed

- Patch was generated against the exact source text retrieved from the pinned revision for `GenerateStage`, `Generator`, `ChunkState`, `PopulatorStage`, and the targeted `Level` methods.
- Unified diff syntax was checked with `git apply --numstat`; all five file hunks apply cleanly to a local fixture containing the exact retrieved file text / target method fragment.
- `git diff --check` passed on the applied fixture.
- The patch was reviewed for the existing `Consumer` import in `Generator` and existing `log`/`chunkGenerationQueue` symbols in `Level`.

## Not yet validated

- Full PNX Gradle build: not run; the environment cannot resolve GitHub/Gradle distribution hosts.
- Binary/source compatibility against all plugins: not tested.
- Runtime chunk send, unload/reload, and concurrent sync/async generation: not tested.
- The new core does **not** yet instantiate `ChunkGenerationRequestCoordinator` or `CrossChunkDependencyScheduler` inside `Level`.
- It does not yet add Terra's concrete dependency-finalize stage or serialize/apply the cross-chunk operation journal to real PNX `BlockState` objects.

## Important operational caveat

Changing `canSend()` to require `FINISHED` is intentionally conservative and affects all generators, not only Terra. Existing populated generators should continue from `GENERATED` through their remaining stages when a chunk is requested by a loader, but this needs a complete PNX build and runtime regression test before deployment. Do not install this patch on the production server yet.

## Apply order

Apply this patch to the clean pinned PNX commit. It includes the asynchronous-stage API that was previously delivered as stage 5; do not apply the stage-5 patch separately on top of it.
