# Stage 7 — PNX core lifecycle integration

Target: PowerNukkitX commit `c57499365737654eca32df008751ef6bca5af142`.

The patch supersedes the earlier stage-5 async-stage patch. It includes the asynchronous stage API, async and sync stage-chain handling, failure cleanup for Level generation reservations, delayed POPULATED marking, and FINISHED-only chunk publication.

The archive also contains the standalone stage-6 journal, dependency scheduler, request coordinator, and tests. The stage-6 code remains an integration-ready core library, not yet instantiated by PNX Level.

Read `REPORT.md` for validation boundaries and deployment caveats. Do not install on the production server yet.
