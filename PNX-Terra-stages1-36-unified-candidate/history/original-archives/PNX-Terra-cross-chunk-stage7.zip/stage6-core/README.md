# PNX-Terra cross-chunk stage 6 — coalesced generation requests

This stage adds a scheduler-neutral request coordinator on top of the stage-4 journal/barrier core.

## What it guarantees

- Concurrent requests for the same chunk share one active phase runner.
- A later request can extend the target from `GENERATED` to `POPULATED` or `FINALIZED` without starting a second runner.
- Waiters complete as soon as their own requested phase has completed; deeper requests continue independently.
- A failure completes current waiters exceptionally. A later request retries from the last phase the driver reports as durably completed.
- Already completed phases are skipped on restart/re-entry.
- Idle slots can be explicitly forgotten on chunk unload to bound memory use.
- `CrossChunkDependencyScheduler` turns feature write bounds into actual `POPULATED` phase requests and returns a non-blocking target-readiness future.
- No blocking waits, `join`, `get`, or worker-thread monitor waits are used by the coordinator.

## PNX/Terra phase mapping

For the pinned Terra pipeline, the intended mapping is:

| Coordinator phase | PNX/Terra boundary |
|---|---|
| `TERRAIN` | Terra terrain stage complete |
| `GENERATED` | PNX `GeneratedStage` complete |
| `STRUCTURES` | PNX Terra `StructureStage` complete |
| `POPULATED` | Terra `PopulateStage` placements committed |
| `FINALIZED` | Terra finalize/barrier, lighting and final chunk publication prerequisites complete |

The `Driver` is deliberately an adapter seam, not a claim that the PNX scheduler is already wired. It must use the exact pinned PNX scheduler, persist phase completion only after durable work, coalesce with `Level.generateChunk`, and ensure no sendable state is published before `POPULATED`/`FINALIZED` as required.

## Validation

Requires JDK 21+:

```sh
javac --release 21 -Xlint:all -d out $(find main/java test/java -name '*.java')
java -cp out org.powernukkitx.terra.crosschunk.JournalSmokeTest
java -cp out org.powernukkitx.terra.crosschunk.Stage4SmokeTest
java -cp out org.powernukkitx.terra.crosschunk.ChunkGenerationRequestCoordinatorTest
java -cp out org.powernukkitx.terra.crosschunk.CrossChunkDependencySchedulerTest
```

This is standalone core validation, not a PNX/Terra build or runtime integration test.
