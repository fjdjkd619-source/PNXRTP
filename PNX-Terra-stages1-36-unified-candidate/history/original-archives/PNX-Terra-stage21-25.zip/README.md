# PNX-Terra — стадии 21–25

## Базовые версии

- PowerNukkitX 3.0.6 — `c57499365737654eca32df008751ef6bca5af142`
- PNX-Terra 1.0.0 — `74318b4a1eae95322550f12d5eb8a76d92a93731`
- Terra 6.6.1-BETA — `05ddc8b8a66e17412670647cce78ef837b091256`
- Origen 2.2.0 — `228426bb192a8d6029952aae1a77008dea5f3cda`
- Java compile target — 21

Пакет инкрементальный: он накладывается на подготовленное состояние Stage 18–20, а не на чистые upstream-репозитории.

## Стадии

### Stage 21 — канонизация и совместимость BlockState

- Добавлен строгий parser Terra `BlockState#getAsString(true)` для идентификатора и набора свойств.
- Свойства сортируются для стабильной сериализации.
- Добавлен `BlockStatePropertyBridge`: тождественное отображение разрешено только при совпадении имени и значения в PNX schema; любые отличия требуют явной таблицы соответствий.
- Неизвестный блок, неизвестное свойство, неразрешённое значение, неоднозначное отображение и конфликт двух свойств приводят к отказу, а не к подмене блока.

Ограничение: таблица соответствий ещё не наполнена полным реестром Terra↔PNX и новый bridge пока не подключён к отсутствующему в этом source snapshot `PNXBlockStateDelegate`. Это слой совместимости и тестируемый контракт, а не заявление о полной поддержке всех блоков.

### Stage 22 — durable block-entity intents

- `PlacementRecord` расширен неизменяемыми `BlockEntityIntent` и `PhysicsIntent`.
- WAL поднят до версии 3. Новые записи сохраняют координаты, тип и ограниченный canonical payload block entity, а также отложенные physics requests.
- Чтение старых WAL v1/v2 сохранено; v3 payload проверяет лимиты, длины и отсутствие trailing bytes.
- Индекс `placementsByTarget` учитывает блоки, block entities и physics intents.
- Digest placement для чанка включает все три вида операций.

Ограничение: PNX NBT encoder/decoder и реальное создание конкретных BlockEntity ещё не подключены. Payload — платформенно-нейтральный байтовый контракт; он не объявляется готовым NBT-кодеком.

### Stage 23 — water layer и physics intents

- Terra `setBlockState(..., physics=true)` теперь сохраняет отложенный physics intent в root placement WAL; вложенные структуры передают intents родителю.
- Добавлен `WaterLayerPolicy`: водный второй слой создаётся только по явной классификации (waterlogged property или intrinsically water-containing block), без догадок по названию блока.
- Требование canonical water-state payload проверяется до записи.

Ограничение: WaterLayerPolicy пока не подключён вместо существующей эвристики `PNXServerWorld`; реальный PNX neighbor-update executor не реализован. До его появления финализатор отклоняет physics intents fail-closed, поэтому такой чанк не получает applied acknowledgement.

### Stage 24 — структурированная диагностика

- Добавлены `GenerationDiagnostic` и `DiagnosticSink` с этапом, feature ID, structure ID, anchor chunk, мировыми координатами, severity и типом причины.
- `PNXServerWorld` получил внедряемый sink; по умолчанию он безопасно игнорирует сообщения.
- Отказ неизвестной структуры и структуры с неподдерживаемыми entity intents публикуется как WARNING; ошибка durable WAL commit — как ERROR с координатами anchor.

Ограничение: общий перехват всех исключений каждого Terra stage ещё не подключён; для этого нужно изменение Terra Core stage wrapper и runtime logger.

### Stage 25 — единый intent finalization contract

- Финализатор теперь применяет блоки, затем block-entity intents, затем physics intents, и только потом сохраняет чанк и добавляет `ChunkApplied`.
- Все intent-данные включены в digest, поэтому позднее изменение любого вида операции блокирует acknowledgement.
- Адаптеры, не поддерживающие конкретный тип intent, по умолчанию выбрасывают исключение. Это намеренный fail-closed режим: нельзя подтвердить чанк, если его block entity или physics не применены.

Ограничение: PNX `PnxChunkHandle` пока не реализует реальное применение block entities/physics. Межчанковое применение обычных block states из Stage 18–20 остаётся действующим; новые intent-типы не считаются runtime-поддержанными.

## Проверки

- `javac --release 21 -Xlint:all -Werror` — PASS для независимого core-контракта (journal, scheduler, finalization coordinator, state bridge, water policy, diagnostics и тесты).
- 10 тестовых наборов × 10 повторов = 100 успешных запусков.
- Проверены: стабильная канонизация свойств; явное alias mapping; fail-closed неизвестных свойств; WAL v3 round-trip; v2 WAL backward compatibility; entity/physics target indexing; digest; negative chunk coordinates; deterministic intent resolution; unsupported adapter never acknowledges; diagnostics; water-layer classification.
- Полный Gradle build PNX/Terra/PNX-Terra — NOT RUN.
- Компиляция полного PNXServerWorld против полного pinned PNX/Terra checkout — NOT RUN.
- Реальное создание NBT-backed BlockEntity — NOT RUN.
- Реальное neighbor physics / fluid simulation — NOT RUN.
- Полный runtime test — NOT RUN.
- JAR — NOT BUILT.
- Production server/world/config/plugins — NOT MODIFIED.

## Порядок применения

1. Сначала Stage 15 Terra Core patch.
2. Stage 15 PNX-Terra adapter patch.
3. Stage 16–17 adapter patches.
4. Stage 18 PNX core patch.
5. Stage 18–20 adapter patch.
6. Затем этот Stage 21–25 adapter patch.
7. До сборки обязательны полный `git apply --check` на pinned checkout и полноценные Gradle builds.
8. Только после этого — изолированный runtime test на отдельной копии сервера и мира.

**Не загружать на production.** Это следующий исходный пакет разработки, не готовый JAR.
