# Source audit used for Stage 21–25

Pinned source targets:

- PNX 3.0.6 release and commit: https://github.com/PowerNukkitX/PowerNukkitX/releases/tag/3.0.6
- PNX `BlockManager.java`: https://github.com/PowerNukkitX/PowerNukkitX/blob/c57499365737654eca32df008751ef6bca5af142/src/main/java/org/powernukkitx/level/generator/object/BlockManager.java
- PNX `BlockEntityHolder.java`: https://github.com/PowerNukkitX/PowerNukkitX/blob/c57499365737654eca32df008751ef6bca5af142/src/main/java/org/powernukkitx/block/BlockEntityHolder.java
- PNX `IChunk.java`: https://github.com/PowerNukkitX/PowerNukkitX/blob/c57499365737654eca32df008751ef6bca5af142/src/main/java/org/powernukkitx/level/format/IChunk.java
- PNX `BlockEntity.java`: https://github.com/PowerNukkitX/PowerNukkitX/blob/c57499365737654eca32df008751ef6bca5af142/src/main/java/org/powernukkitx/blockentity/BlockEntity.java
- Terra `BlockState.java`: https://github.com/PolyhedralDev/Terra/blob/05ddc8b8a66e17412670647cce78ef837b091256/common/api/src/main/java/com/dfsek/terra/api/block/state/BlockState.java
- Terra `WritableWorld.java`: https://github.com/PolyhedralDev/Terra/blob/05ddc8b8a66e17412670647cce78ef837b091256/common/api/src/main/java/com/dfsek/terra/api/world/WritableWorld.java
- Terra `ReadableWorld.java`: https://github.com/PolyhedralDev/Terra/blob/05ddc8b8a66e17412670647cce78ef837b091256/common/api/src/main/java/com/dfsek/terra/api/world/ReadableWorld.java
- Terra `BlockEntity.java`: https://github.com/PolyhedralDev/Terra/blob/05ddc8b8a66e17412670647cce78ef837b091256/common/api/src/main/java/com/dfsek/terra/api/block/entity/BlockEntity.java
- TerraScript `BlockFunction.java`: https://github.com/PolyhedralDev/Terra/blob/05ddc8b8a66e17412670647cce78ef837b091256/common/addons/structure-terrascript-loader/src/main/java/com/dfsek/terra/addons/terrascript/script/functions/BlockFunction.java

## Relevant findings

1. PNX `BlockManager.applySubChunkUpdate()` groups writes by chunks using `level.getChunk(..., true)`. That path may load a target chunk, so it must not be used by a worker that is supposed to apply only to already-loaded chunks.
2. The same method applies block states first and then loops over staged `Block` instances; if a block implements `BlockEntityHolder`, it calls `getOrCreateBlockEntity()`. The Stage 18–20 `PnxChunkHandle` mutates `IChunk` directly and does not perform this holder pass. Therefore a future BE finalizer must explicitly create/restore entities after block-state application and before save/ack.
3. PNX `IChunk` exposes block-entity collection access (`getBlockEntities`, `getTile`, `addBlockEntity`, `removeBlockEntity`) and `batchProcess` for block writes. `BlockEntityHolder` exposes `createBlockEntity(initialData, args)` and `getOrCreateBlockEntity`.
4. PNX `BlockEntity` constructor registers the entity with both chunk and level; creating it from a worker thread or before its target block state is in place is unsafe. The actual thread/ownership constraints need runtime validation before enabling the adapter.
5. Terra's `BlockEntity` API exposes `update(boolean applyPhysics)`, position, and block state, but no portable NBT serialization contract. This is why the new WAL stores a bounded opaque adapter payload and does not pretend that Terra's API alone supplies PNX NBT bytes.
6. Terra's `WritableWorld#setBlockState(x,y,z,state,physics)` carries a physics boolean. TerraScript's `BlockFunction` first reads current block state and then calls that method with the configured physics value. The PNX adapter previously discarded that flag; Stage 21–25 now records true requests in the root transaction WAL, but execution remains disabled until a safe PNX update executor is implemented.
7. PNX `BlockManager.applySubChunkUpdate` has a separate block-layer path and recognizes PNX block-entity holders, but Terra's API does not expose a universal waterlogging contract. Stage 23 therefore uses an explicit classifier interface instead of assuming every block with a familiar name should receive a water layer.
