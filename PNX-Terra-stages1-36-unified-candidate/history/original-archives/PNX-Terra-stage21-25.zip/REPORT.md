# Технический отчёт — Stage 21–25

## Результат

Подготовлен инкрементальный Stage 21–25 source package поверх Stage 18–20. Главный результат — расширение durable placement contract: теперь WAL и digest умеют учитывать не только block-state writes, но также block-entity и physics intents. Финализатор требует применить все intent-классы до сохранения и acknowledgement.

## Что подтверждено

1. Core Java 21 compilation with `-Xlint:all -Werror` passed.
2. Ten test suites passed in ten consecutive rounds (100 suite executions).
3. New WAL v3 round-trip passed; a handcrafted v2 placement frame was read by the v3 journal implementation.
4. Auxiliary intents are included in per-target index and placement digest.
5. Unsupported block entity / physics adapters fail closed and cannot produce `ChunkApplied` acknowledgement.
6. Physics flag from Terra's `WritableWorld#setBlockState(..., physics)` is captured in PNXServerWorld root/nested placement state and included in the WAL record.
7. Diagnostics for disabled/unknown structures and durable WAL commit failure are emitted through the injected sink.

## Что не подтверждено и не должно считаться готовым

- Terra↔PNX full block/property registry map is not populated; bridge is strict and standalone, not fully wired into `PNXBlockStateDelegate`.
- PNX block entity NBT codec and real block-entity creation are not implemented. WAL stores a bounded opaque payload contract only.
- `WaterLayerPolicy` is not yet wired into PNXServerWorld's old water heuristic.
- Physics intents are durably captured but not executed by PNX neighbor-update logic. The PNX chunk adapter's default intent handler rejects them, so the target cannot be acknowledged.
- Diagnostic sink is wired to selected rejection/commit paths, not all Terra stage exceptions.
- No complete PNX/Terra/PNX-Terra build; no real PNX runtime test; no JAR.
- No production server changes.

## Security/correctness posture

The new behavior is deliberately conservative. If a placement includes unsupported block-entity or physics work, finalization fails before save acknowledgement. The system must not silently discard a container's contents, sign data, spawner state, or physics request and then mark the chunk complete.
