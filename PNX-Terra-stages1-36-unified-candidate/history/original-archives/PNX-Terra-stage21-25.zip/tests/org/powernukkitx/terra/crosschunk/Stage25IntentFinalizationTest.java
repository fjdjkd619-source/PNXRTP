package org.powernukkitx.terra.crosschunk;

import org.powernukkitx.terra.crosschunk.finalize.ChunkFinalizationCoordinator;
import org.powernukkitx.terra.crosschunk.journal.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

public final class Stage25IntentFinalizationTest {
    public static void main(String[] args) throws Exception {
        Path wal=Files.createTempDirectory("pnx-stage25-").resolve("finalize.wal");
        ChunkPos target=new ChunkPos(0,0);
        PlacementKey key=new PlacementKey("world",1,target,"feature","structure",0,64,0,0,1);
        PlacementRecord record=new PlacementRecord(key,List.of(new BlockWrite(0,64,0,0,new byte[]{1})),
                List.of(new BlockEntityIntent(1,64,1,"Chest",new byte[]{2})),
                List.of(new PhysicsIntent(0,64,0,true)));
        try(PlacementJournal journal=new PlacementJournal(wal)){
            journal.appendPlacement(record);
            ChunkFinalizationCoordinator<FakeChunk> coordinator=new ChunkFinalizationCoordinator<>("world",journal,Runnable::run);
            FakeChunk unsupported=new FakeChunk(false);
            boolean failed=false;
            try { coordinator.prepare(target,CompletableFuture.completedFuture(null),()->unsupported).join(); }
            catch(CompletionException expected){failed=true;}
            check(failed,"adapter without entity support fails closed");
            check(!journal.isChunkApplied("world",target,PlacementDigest.compute(journal.placementsFor(target),target)),"unsupported intents never acknowledged");
            FakeChunk supported=new FakeChunk(true);
            var prepared=coordinator.prepare(target,CompletableFuture.completedFuture(null),()->supported).join();
            check(supported.blocks==1&&supported.entities==1&&supported.physics==1,"all intent classes reach adapter before save");
            coordinator.persist(prepared,()->supported);
            check(supported.saved,"chunk persisted after complete intent application");
            check(journal.isChunkApplied("world",target,prepared.digest()),"acknowledgement follows durable save");
        }
        System.out.println("Stage25IntentFinalizationTest: PASS");
    }
    private static final class FakeChunk implements ChunkFinalizationCoordinator.ChunkHandle {
        private final boolean supports; int blocks,entities,physics; boolean saved;
        FakeChunk(boolean supports){this.supports=supports;}
        public ChunkPos position(){return new ChunkPos(0,0);} public boolean isLoaded(){return true;}
        public boolean isGenerated(){return true;} public boolean isInitiated(){return true;}
        public void applyProjection(NavigableMap<PlacementProjection.Position,PlacementProjection.Winner> p){blocks=p.size();}
        public void applyBlockEntityIntents(NavigableMap<PlacementProjection.Position,PlacementProjection.EntityWinner> p){if(!supports&&!p.isEmpty())throw new UnsupportedOperationException();entities=p.size();}
        public void applyPhysicsIntents(List<PhysicsIntent> p){if(!supports&&!p.isEmpty())throw new UnsupportedOperationException();physics=p.size();}
        public void saveDurably(){saved=true;}
    }
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
}
