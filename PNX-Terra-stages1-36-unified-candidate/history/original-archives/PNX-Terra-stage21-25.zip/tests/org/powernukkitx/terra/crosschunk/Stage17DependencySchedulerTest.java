package org.powernukkitx.terra.crosschunk;

import org.powernukkitx.terra.crosschunk.journal.*;
import org.powernukkitx.terra.crosschunk.scheduler.CrossChunkDependencyScheduler;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public final class Stage17DependencySchedulerTest {
    public static void main(String[] args) throws Exception {
        check(CrossChunkDependencyScheduler.expectedAnchors(new ChunkPos(0,0),0,0).equals(Set.of(new ChunkPos(0,0))),"zero reach anchor set");
        Set<ChunkPos> neg=CrossChunkDependencyScheduler.expectedAnchors(new ChunkPos(-1,-1),16,16);
        check(neg.contains(new ChunkPos(-2,-2))&&neg.contains(new ChunkPos(-1,-1))&&neg.contains(new ChunkPos(0,0)),"negative and positive overlap envelope");

        Path wal=Files.createTempDirectory("pnx-stage17-").resolve("world.wal");
        try(PlacementJournal journal=new PlacementJournal(wal)){
            CrossChunkDependencyScheduler scheduler=new CrossChunkDependencyScheduler("world",journal);
            Set<ChunkPos> expected=CrossChunkDependencyScheduler.expectedAnchors(new ChunkPos(0,0),0,0);
            CompletableFuture<Void> ready=scheduler.registerTarget(new ChunkPos(0,0),0,0);
            check(!ready.isDone(),"target initially blocked");
            CrossChunkDependencyScheduler.AnchorSession session=scheduler.openAnchor(new ChunkPos(0,0));
            var ticket=session.beginPlacement();
            session.finishPopulation();
            check(!ready.isDone(),"population cannot complete with in-flight root placement");
            PlacementKey key=new PlacementKey("world",1,new ChunkPos(0,0),"feature","structure",1,64,1,0,0);
            ticket.commit(new PlacementRecord(key,List.of(new BlockWrite(1,64,1,0,"stone".getBytes(StandardCharsets.UTF_8)))));
            check(ready.isDone(),"target releases only after durable placement and anchor marker");
            check(scheduler.isAnchorComplete(new ChunkPos(0,0)),"anchor marker persisted");
        }
        try(PlacementJournal recovered=new PlacementJournal(wal)){
            CrossChunkDependencyScheduler scheduler=new CrossChunkDependencyScheduler("world",recovered);
            CompletableFuture<Void> ready=scheduler.registerTarget(new ChunkPos(0,0),0,0);
            check(ready.isDone(),"completed dependencies restored after restart");
        }
        Path wideWal=Files.createTempDirectory("pnx-stage17-wide-").resolve("world.wal");
        try(PlacementJournal journal=new PlacementJournal(wideWal)){
            CrossChunkDependencyScheduler scheduler=new CrossChunkDependencyScheduler("world",journal);
            var ready=scheduler.registerTarget(new ChunkPos(0,0),16,16,false);
            Set<ChunkPos> anchors=CrossChunkDependencyScheduler.expectedAnchors(new ChunkPos(0,0),16,16);
            check(anchors.size()==9,"wide dependency envelope includes all overlapping anchor chunks");
            int completed=0;
            for(ChunkPos anchor:anchors){var session=scheduler.openAnchor(anchor);session.finishPopulation();completed++;if(completed<anchors.size())check(!ready.isDone(),"target remains blocked until every source anchor completes");}
            check(ready.isDone(),"wide target barrier releases after final source anchor");
        }

        Path requestWal=Files.createTempDirectory("pnx-stage17-request-").resolve("world.wal");
        try(PlacementJournal journal=new PlacementJournal(requestWal)){
            AtomicInteger attempts=new AtomicInteger();
            CrossChunkDependencyScheduler scheduler=new CrossChunkDependencyScheduler("world",journal,
                    anchor -> attempts.incrementAndGet()>1);
            scheduler.registerTarget(new ChunkPos(0,0),0,0,false);
            check(attempts.get()==0,"dependency-prefetch registration does not recurse");
            scheduler.activateTarget(new ChunkPos(0,0));
            check(attempts.get()==1,"activation retries one missing source anchor");
            scheduler.activateTarget(new ChunkPos(0,0));
            check(attempts.get()==2,"queue-rejected anchor can be requested again");
        }

        Path abortWal=Files.createTempDirectory("pnx-stage17-abort-").resolve("world.wal");
        try(PlacementJournal journal=new PlacementJournal(abortWal)){
            CrossChunkDependencyScheduler scheduler=new CrossChunkDependencyScheduler("world",journal);
            var ready=scheduler.registerTarget(new ChunkPos(0,0),0,0);
            var session=scheduler.openAnchor(new ChunkPos(0,0));
            var ticket=session.beginPlacement();ticket.abort();session.finishPopulation();
            check(ready.isDone(),"empty but successfully populated anchor can complete");
            check(journal.placementsFor(new ChunkPos(0,0)).isEmpty(),"aborted root writes absent from WAL");
        }
        System.out.println("Stage17DependencySchedulerTest: PASS");
    }
    static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
}
