package org.powernukkitx.terra.crosschunk.bounds;

import java.util.Map;
import java.util.Optional;

/** Only profiles whose complete write/read closure was bounded from the pinned Origen pack. */
public final class OrigenBoundsCatalog {
    public static final String PACK_ID = "origen";
    private static final Map<String, ScriptBoundsProfile> PROFILES = Map.of(
            "waterfall", new ScriptBoundsProfile(PACK_ID, "waterfall",
                    new Bounds3i(-5, -50, -5, 5, 2, 5),
                    new Bounds3i(-5, -50, -5, 5, 2, 5),
                    512, 128, 0, java.util.List.of(),
                    "waterfall.tesf: fixed width=1, length=4, inwardLength=-3, downwardsMaxSearch=50; four cardinal wall orientations; nested calls absent"),
            "dripstone_column", new ScriptBoundsProfile(PACK_ID, "dripstone_column",
                    new Bounds3i(-10, -10, -10, 10, 100, 10),
                    new Bounds3i(-10, -10, -10, 10, 100, 10),
                    100_000, 100_000, 0, java.util.List.of("is_dripstone_column_replaceable"),
                    "dripstone_column.tesf: maxRadius=10, maxDepth=10, maxHeight=100; mask target is a read-only script whose sole read is getBlock(0,0,0)"),
            "mangrove_tree_procedural", new ScriptBoundsProfile(PACK_ID, "mangrove_tree_procedural",
                    new Bounds3i(-30, -30, -30, 30, 28, 30),
                    new Bounds3i(-31, -30, -31, 31, 28, 31),
                    20_000, 10_000, 3,
                    java.util.List.of("mangrove_leaves_clump", "propagule", "place_vines", "is_leaf", "spore_blossom", "bee_nest"),
                    "mangrove_tree_procedural.tesf: root path length<=30 gives |x|,|z|<=30; branch/leaf/vine closures fit inside that horizontal envelope; y lower bound conservatively -30, top branch/leaf closure envelope <=28; root neighbor reads add one block; bee_nest spawns three entities"));

    private OrigenBoundsCatalog() {}

    public static Optional<ScriptBoundsProfile> find(String structureId) {
        return Optional.ofNullable(PROFILES.get(structureId));
    }

    public static Map<String, ScriptBoundsProfile> allVerified() { return PROFILES; }

    /** Maximum horizontal write reach across profiles currently accepted by the fail-closed adapter. */
    public static int maxHorizontalReach() {
        return PROFILES.values().stream().filter(profile -> profile.maxEntitySpawns() == 0).mapToInt(profile -> Math.max(
                Math.max(Math.abs(profile.writeBounds().minX()), Math.abs(profile.writeBounds().maxX())),
                Math.max(Math.abs(profile.writeBounds().minZ()), Math.abs(profile.writeBounds().maxZ()))
        )).max().orElse(0);
    }

    /** Unknown scripts remain unbounded and must not be scheduled for finalization. */
    public static ScriptBoundsProfile requireVerified(String structureId) {
        return find(structureId).orElseThrow(() ->
                new IllegalStateException("No verified Origen runtime envelope for structure: " + structureId));
    }
}
