package org.powernukkitx.terra.crosschunk.journal;

import java.util.*;

/** Immutable root placement transaction. Duplicate coordinates within this placement are last-write-wins. */
public record PlacementRecord(PlacementKey key, List<BlockWrite> writes,
                              List<BlockEntityIntent> blockEntities, List<PhysicsIntent> physics) {
    public PlacementRecord(PlacementKey key, List<BlockWrite> writes) { this(key, writes, List.of(), List.of()); }
    public PlacementRecord {
        Objects.requireNonNull(key, "key"); Objects.requireNonNull(writes, "writes");
        Objects.requireNonNull(blockEntities, "blockEntities"); Objects.requireNonNull(physics, "physics");
        if (writes.isEmpty() && blockEntities.isEmpty() && physics.isEmpty()) throw new IllegalArgumentException("A committed placement must contain at least one intent");
        if (writes.size() > 2_000_000 || blockEntities.size() > 65_536 || physics.size() > 2_000_000)
            throw new IllegalArgumentException("Placement exceeds intent limit");
        writes=List.copyOf(writes); blockEntities=List.copyOf(blockEntities); physics=List.copyOf(physics);
    }
    public Set<ChunkPos> targetChunks() {
        TreeSet<ChunkPos> result = new TreeSet<>();
        writes.forEach(w -> result.add(w.chunk())); blockEntities.forEach(e -> result.add(e.chunk())); physics.forEach(p -> result.add(p.chunk()));
        return Collections.unmodifiableSet(result);
    }
}
