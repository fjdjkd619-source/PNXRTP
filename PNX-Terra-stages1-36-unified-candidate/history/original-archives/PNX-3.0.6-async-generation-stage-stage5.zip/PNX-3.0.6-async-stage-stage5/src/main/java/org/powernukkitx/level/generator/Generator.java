package org.powernukkitx.level.generator;

import org.powernukkitx.block.BlockID;
import org.powernukkitx.level.DimensionData;
import org.powernukkitx.level.Level;
import org.powernukkitx.level.format.ChunkState;
import org.powernukkitx.level.format.IChunk;
import org.powernukkitx.level.generator.holder.EmptyObjectHolder;
import org.powernukkitx.level.generator.holder.ObjectHolder;
import com.google.common.base.Preconditions;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * @author MagicDroidX (Nukkit Project)
 */
@Slf4j
public abstract class Generator implements BlockID {
    protected final Map<String, Object> options;
    protected final GenerateStage start;
    protected final GenerateStage end;
    protected final DimensionData dimensionData;
    protected Level level;

    public Generator(DimensionData dimensionData, Map<String, Object> options) {
        this.dimensionData = dimensionData;
        this.options = options;
        GenerateStage.Builder builder = new GenerateStage.Builder();
        stages(builder);
        this.start = builder.getStart();
        this.end = builder.getEnd();
    }

    public Map<String, Object> getSettings() {
        return this.options;
    }

    public void setLevel(Level level) {
        this.level = level;
    }

    public abstract void stages(GenerateStage.Builder builder);

    public abstract String getName();

    @NotNull
    public DimensionData getDimensionData() {
        return dimensionData;
    }

    public IChunk syncGenerate(IChunk chunk) {
        return this.syncGenerate(chunk, getEndName(chunk));
    }

    protected IChunk syncGenerate(IChunk chunk, String to) {
        Preconditions.checkNotNull(to);
        final ChunkGenerateContext context = new ChunkGenerateContext(this, level, chunk);
        final GenerateStage start = getStart(context);
        if (chunk.getChunkState().ordinal() < ChunkState.STARTED.ordinal()) {
            chunk.setChunkState(ChunkState.STARTED);
        }
        if (start == null) {
            return context.getChunk();
        }
        CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
            start.apply(context);
        }, start.getExecutor());
        GenerateStage now = start;
        while ((now = now.getNextStage()) != null) {
            final GenerateStage finalNow = now;
            if (finalNow.name().equals(to)) {
                future = future.thenRunAsync(() -> finalNow.apply(context), now.getExecutor());
                break;
            }
            future = future.thenRunAsync(() -> finalNow.apply(context), finalNow.getExecutor());
        }
        future.join();
        return context.getChunk();
    }

    protected String getEndName(IChunk chunk) {
        return end.name();
    }

    protected GenerateStage getStart(ChunkGenerateContext context) {
        return start;
    }

    public final void asyncGenerate(IChunk chunk) {
        asyncGenerate(chunk, getEndName(chunk), (c) -> {
        });
    }

    public final void asyncGenerate(IChunk chunk, Consumer<ChunkGenerateContext> callback) {
        asyncGenerate(chunk, getEndName(chunk), callback);
    }

    public final void asyncGenerate(IChunk chunk, String to, Consumer<ChunkGenerateContext> callback) {
        Preconditions.checkNotNull(to);
        final ChunkGenerateContext context = new ChunkGenerateContext(this, level, chunk);
        final GenerateStage start = getStart(context);
        if (chunk.getChunkState().ordinal() < ChunkState.STARTED.ordinal()) {
            chunk.setChunkState(ChunkState.STARTED);
        }
        asyncGenerate0(context, start, to, () -> callback.accept(context));
    }

    protected final void asyncGenerate0(final ChunkGenerateContext context, final GenerateStage start, String to, final Runnable callback) {
        if (start == null || to == null) {
            callback.run();
            return;
        }

        start.applyAsync(context).whenComplete((ignored, failure) -> {
            if (failure != null) {
                log.error("Failed to execute generation stage {} for chunk ({}, {})",
                        start.name(), context.getChunk().getX(), context.getChunk().getZ(), failure);
                return;
            }
            if (to.equals(start.name())) {
                callback.run();
            } else {
                asyncGenerate0(context, start.getNextStage(), to, callback);
            }
        });
    }

    public ObjectHolder createObjectHolder(Level level) {
        return new EmptyObjectHolder();
    }
}
