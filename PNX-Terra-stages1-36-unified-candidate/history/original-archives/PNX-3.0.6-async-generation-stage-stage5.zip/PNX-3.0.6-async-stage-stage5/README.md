# PNX 3.0.6 async generation-stage extension — stage 5

Target PNX commit: `c57499365737654eca32df008751ef6bca5af142`.

## Why this patch exists

At the pinned commit, `GenerateStage.apply(ChunkGenerateContext)` is synchronous and returns `void`. `Generator.asyncGenerate0` dispatches each stage to its executor, but immediately schedules the next stage only after `apply` returns. A cross-chunk dependency barrier cannot safely wait inside `apply` without blocking a compute worker.

This patch adds a backward-compatible overridable `applyAsync(context)` method. The default implementation runs the existing synchronous `apply` on the stage executor. A stage that needs an asynchronous dependency can override it and return a future that completes when its work is truly finished. `Generator.asyncGenerate0` advances only when that future completes.

Existing plugins and stages remain source/binary compatible because `apply` stays abstract and `applyAsync` is a concrete method.

## Scope and limitation

This is the PNX core enabling hook only. It does not schedule Terra source-chunk dependencies, does not alter synchronous `syncGenerate`, and does not by itself prevent early chunk publication. A Terra integration must:

- schedule every source chunk in the computed feature-bound halo;
- ensure each source chunk commits all its placement journal records before signalling source completion;
- implement a Terra finalize stage by overriding `applyAsync` and completing only after the dependency barrier and target operations finish;
- keep the chunk non-sendable until that finalize stage has completed;
- account for synchronous `syncGenerate` paths separately (they still call `apply` synchronously).

The `syncGenerate` limitation is deliberate and must not be hidden: this patch enables non-blocking async generation but does not claim complete scheduler integration.
