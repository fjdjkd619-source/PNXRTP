# PNX-Terra cross-chunk generation — Stage 8 report

Date: 2026-11-28  
Target PowerNukkitX commit: `c57499365737654eca32df008751ef6bca5af142`  
Target Terra adapter: PNX-Terra 1.0.0 / Terra 6.6.1-BETA

## Result

Stage 8 adds the first PNX-facing journal application adapter. It converts the previously platform-neutral write-ahead journal into actual PNX `BlockState` writes against a target `IChunk`.

### New implementation

1. `PnxBlockStatePayloadCodec`
   - Encodes a PNX state as magic + payload version + canonical block identifier + `specialValue`.
   - Does not persist `blockStateHash`, which is an internal runtime/registry hash.
   - On decode, resolves the identifier through `Registries.BLOCK`, resolves the special value through `BlockProperties`, and rejects missing/noncanonical states.
   - This payload is compatible only when the receiving server has the same block registry definitions; a future cross-version migration needs explicit identifier/property migration.

2. `PnxJournalChunkApplier`
   - Reads the journal snapshot for one target chunk.
   - Refuses missing, ungenerated, or uninitialized chunks; uses `Level.getChunkIfLoaded`, never `getChunk(..., true)` for lookup.
   - Resolves conflicts deterministically per absolute block coordinate and layer.
   - Evaluates `REPLACEABLE_ONLY` against the pre-apply block through an injected PNX `Block` predicate.
   - Applies winning states through `BlockManager.setBlockStateAt(..., layer, state)` and `applySubChunkUpdate()`.
   - Serializes target-chunk applies, uses an injected generation executor rather than the common pool, persists through an injected callback, and only then appends the applied digest to `AppliedChunkLedger`.
   - Rechecks the journal digest after persistence and applies again if new operations arrived during the save.
   - Failed persistence does not acknowledge the digest; retry is idempotent.

## Exact source API verification

The following APIs were checked against the pinned PNX source:

- `Level.getChunkIfLoaded(int, int)`
- `IChunk.getBlockState`, `isGenerated`, `isInitiated`, `getDimensionData`
- `Block.get(BlockState, Level, x, y, z, layer)`
- `BlockManager.setBlockStateAt(x, y, z, layer, BlockState)` and `applySubChunkUpdate()`
- `BlockProperties.containBlockState(BlockState)` and `getBlockState(short)`
- `Registries.BLOCK.getBlockProperties(identifier)`

Relevant source files:
- `src/main/java/org/powernukkitx/level/Level.java`
- `src/main/java/org/powernukkitx/block/BlockState.java`
- `src/main/java/org/powernukkitx/block/BlockProperties.java`
- `src/main/java/org/powernukkitx/level/format/IChunk.java`
- `src/main/java/org/powernukkitx/level/generator/object/BlockManager.java`

## Validation performed

- Compiled all stage 3/4/6 core classes plus stage 8 adapter using `javac --release 21 -Xlint:all -Werror` against local API contract stubs for the PNX types used by the adapter. No warnings or errors.
- Recompiled and ran all existing standalone suites:
  - journal durability/conflict/negative-coordinate/torn-tail smoke test — PASS
  - feature bounds/barrier/late digest/ledger smoke test — PASS
  - request coordinator coalescing/target extension/retry/unload test — PASS
  - dependency scheduler halo/failure propagation test — PASS
- This is a Java contract-stub compile, not compilation against the complete PNX Gradle project. No PNX/Terra Gradle build or server runtime test was run.

## Explicit limitations — not yet production-ready

1. `ChunkPersister` is an injected seam. This stage does not guess the pinned LevelProvider's durable save contract. Stage 9 must wire the exact provider save operation and make the chunk remain non-publishable until persistence + ledger acknowledgement.
2. The adapter does not yet intercept `PNXServerWorld.setBlockState()` or `PlacementScope.commit()`. Stage 9 must route every Terra placement write into the journal, including nested TerraScript buffers, while keeping transaction abort semantics.
3. This does not yet install a concrete `ChunkGenerationRequestCoordinator.Driver` into `Level.generateChunk()` or `Generator`. Stage 10 must merge ordinary generation and dependency requests into one runner.
4. `BlockManager.applySubChunkUpdate()` is the PNX write path and internally obtains chunk references. The adapter prechecks that the target is loaded and initialized, and rechecks under the target monitor immediately before application; the full server lifecycle still needs an unload/pin integration to prove there is no unload race.
5. The adapter is not yet a complete packet-publication gate. For newly generated chunks, Terra's finalize stage must await this applier before `FINISHED`/send. Late operations to already published chunks require an explicit update/re-finalization policy.
6. Entity creation and block-entity state mutation are not represented in this block-state journal. They remain separate planned adapters.
7. No production server files, worlds, player data, configs, plugins, or JARs were modified.

## Next stage

Stage 9: connect `PlacementScopeProvider` / `WriteTransaction` to this journal. Encode staged PNX states at transaction commit, assign deterministic placement IDs, append each whole placement atomically, and ensure aborted/nested transactions do not leak journal records. In parallel, wire the real chunk persistence callback from the pinned PNX provider.
