# Stage 8 — PNX journal/block-state adapter

Target PNX commit: `c57499365737654eca32df008751ef6bca5af142`.

This stage adds the first adapter that understands actual PNX `BlockState`, `Level`, `IChunk`, and `BlockManager` APIs.

## Included

- `PnxBlockStatePayloadCodec`: durable payload is `(format magic, version, block identifier, specialValue)`. It deliberately does not persist `blockStateHash`, because that is an internal registry hash. Decode resolves the state through `Registries.BLOCK` and rejects unknown/noncanonical states.
- `PnxJournalChunkApplier`: reads journal operations for one target chunk, resolves deterministic winners per coordinate+layer, applies them through PNX `BlockManager`, and refuses to load missing chunks. `REPLACEABLE_ONLY` is evaluated against the pre-apply block through an injected predicate.
- Per-target asynchronous serialization and repeat-until-stable behavior. A later journal append invalidates the digest and triggers another pass.
- Durable acknowledgement is written only after an injected chunk persistence future succeeds. Failure leaves the ledger unacknowledged and safe to replay.

## Exact PNX source observations

- `Level.getChunkIfLoaded(int,int)` exists and does not request generation.
- `IChunk` exposes `getBlockState`, `isGenerated`, `isInitiated`, and dimension height.
- `BlockManager.setBlockStateAt(x,y,z,layer,state)` and `applySubChunkUpdate()` provide the platform write path, including block-entity holder creation and chunk dirty marking.
- `BlockProperties.getBlockState(short)` and `containBlockState(BlockState)` allow registry-validated identifier/special-value payloads.

## Important integration boundary

The adapter intentionally does not invent a `LevelProvider` persistence call. The PNX integration must supply `ChunkPersister` using the pinned provider's actual save contract. The caller must also keep the target chunk non-publishable until this future completes and the digest is acknowledged. Do not mark the ledger before persistence.

This is not yet a complete PNX/Terra runtime integration. It does not patch `Level.generateChunk`, does not install a concrete generation-stage driver, and does not gate all packet publication paths. It is the PNX-facing journal application layer required before those hooks can safely be wired.
