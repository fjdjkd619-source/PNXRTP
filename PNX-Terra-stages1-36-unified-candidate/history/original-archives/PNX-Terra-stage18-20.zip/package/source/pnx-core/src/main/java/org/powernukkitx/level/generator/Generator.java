package org.powernukkitx.level.generator;

import org.powernukkitx.block.BlockID;
import org.powernukkitx.level.DimensionData;
import org.powernukkitx.level.Level;
import org.powernukkitx.level.format.ChunkState;
import org.powernukkitx.level.format.IChunk;
import org.powernukkitx.level.generator.holder.EmptyObjectHolder;
import org.powernukkitx.level.generator.holder.ObjectHolder;
import com.google.common.base.Preconditions;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * @author MagicDroidX (Nukkit Project)
 */
@Slf4j
public abstract class Generator implements BlockID {
    protected final Map<String, Object> options;
    protected final GenerateStage start;
    protected final GenerateStage end;
    protected final DimensionData dimensionData;
    protected Level level;

    public Generator(DimensionData dimensionData, Map<String, Object> options) {
        this.dimensionData = dimensionData;
        this.options = options;
        GenerateStage.Builder builder = new GenerateStage.Builder();
        stages(builder);
        this.start = builder.getStart();
        this.end = builder.getEnd();
    }

    public Map<String, Object> getSettings() {
        return this.options;
    }

    public void setLevel(Level level) {
        this.level = level;
    }

    public abstract void stages(GenerateStage.Builder builder);

    public abstract String getName();

    @NotNull
    public DimensionData getDimensionData() {
        return dimensionData;
    }

    public IChunk syncGenerate(IChunk chunk) {
        return this.syncGenerate(chunk, getEndName(chunk));
    }

    protected IChunk syncGenerate(IChunk chunk, String to) {
        Preconditions.checkNotNull(to);
        final ChunkGenerateContext context = new ChunkGenerateContext(this, level, chunk);
        final GenerateStage first = getStart(context);
        if (chunk.getChunkState().ordinal() < ChunkState.STARTED.ordinal()) {
            chunk.setChunkState(ChunkState.STARTED);
        }
        if (first == null) {
            return context.getChunk();
        }
        CompletableFuture<Void> future = asyncGenerateFuture0(context, first, to);
        future.join();
        return context.getChunk();
    }

    protected String getEndName(IChunk chunk) {
        return end.name();
    }

    protected GenerateStage getStart(ChunkGenerateContext context) {
        return start;
    }

    public final void asyncGenerate(IChunk chunk) {
        asyncGenerate(chunk, getEndName(chunk), (c) -> {
        });
    }

    public final void asyncGenerate(IChunk chunk, Consumer<ChunkGenerateContext> callback) {
        asyncGenerate(chunk, getEndName(chunk), callback);
    }

    public final void asyncGenerate(IChunk chunk, String to, Consumer<ChunkGenerateContext> callback) {
        Preconditions.checkNotNull(to);
        final ChunkGenerateContext context = new ChunkGenerateContext(this, level, chunk);
        final GenerateStage first = getStart(context);
        if (chunk.getChunkState().ordinal() < ChunkState.STARTED.ordinal()) {
            chunk.setChunkState(ChunkState.STARTED);
        }
        asyncGenerateFuture0(context, first, to).whenComplete((ignored, failure) -> {
            if (failure != null) log.error("Asynchronous chunk generation failed at stage {} for chunk ({}, {})",
                    to, chunk.getX(), chunk.getZ(), failure);
            // Always release the Level generation-queue slot. A failed chunk remains non-sendable
            // and can be retried by the normal chunk request path.
            callback.accept(context);
        });
    }

    /** Future-returning pipeline used by integrations with asynchronous dependency barriers. */
    public final CompletableFuture<Void> asyncGenerateFuture(IChunk chunk) {
        final ChunkGenerateContext context = new ChunkGenerateContext(this, level, chunk);
        final GenerateStage first = getStart(context);
        if (chunk.getChunkState().ordinal() < ChunkState.STARTED.ordinal()) {
            chunk.setChunkState(ChunkState.STARTED);
        }
        return asyncGenerateFuture0(context, first, getEndName(chunk));
    }

    protected final void asyncGenerate0(final ChunkGenerateContext context, final GenerateStage first, String to, final Runnable callback) {
        asyncGenerateFuture0(context, first, to).whenComplete((ignored, failure) -> {
            if (failure != null) log.error("Asynchronous generation stage chain failed at {}", to, failure);
            callback.run();
        });
    }

    private CompletableFuture<Void> asyncGenerateFuture0(final ChunkGenerateContext context,
                                                          final GenerateStage stage, String to) {
        if (stage == null || to == null) return CompletableFuture.completedFuture(null);
        CompletableFuture<Void> applied = stage.applyAsync(context);
        if (to.equals(stage.name())) return applied;
        return applied.thenCompose(ignored -> asyncGenerateFuture0(context, stage.getNextStage(), to));
    }

    public ObjectHolder createObjectHolder(Level level) {
        return new EmptyObjectHolder();
    }
}
