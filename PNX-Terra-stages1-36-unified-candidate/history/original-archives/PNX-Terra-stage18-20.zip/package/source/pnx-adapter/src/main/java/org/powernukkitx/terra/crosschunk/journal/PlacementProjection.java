package org.powernukkitx.terra.crosschunk.journal;

import java.util.*;

/** Deterministic target-chunk projection. Lowest stable placement key wins coordinate/layer conflicts. */
public final class PlacementProjection {
    private PlacementProjection() {}
    public record Position(int x, int y, int z, int layer) implements Comparable<Position> {
        @Override public int compareTo(Position o) {
            int c=Integer.compare(x,o.x); if(c==0)c=Integer.compare(y,o.y); if(c==0)c=Integer.compare(z,o.z);
            return c==0?Integer.compare(layer,o.layer):c;
        }
    }
    public record Winner(String placementId, BlockWrite write) {}

    public static NavigableMap<Position, Winner> resolve(Collection<PlacementRecord> records, ChunkPos target) {
        TreeMap<String, PlacementRecord> stableOrder = new TreeMap<>();
        for (PlacementRecord record : records) stableOrder.put(record.key().stableId(), record);
        TreeMap<Position, Winner> winners = new TreeMap<>();
        for (var entry : stableOrder.entrySet()) {
            // Preserve script order inside one placement; only its final write to a cell survives.
            LinkedHashMap<Position, BlockWrite> local = new LinkedHashMap<>();
            for (BlockWrite write : entry.getValue().writes()) {
                if (write.chunk().equals(target)) local.put(new Position(write.x(),write.y(),write.z(),write.layer()),write);
            }
            for (var cell : local.entrySet()) winners.putIfAbsent(cell.getKey(), new Winner(entry.getKey(),cell.getValue()));
        }
        return Collections.unmodifiableNavigableMap(winners);
    }
}
