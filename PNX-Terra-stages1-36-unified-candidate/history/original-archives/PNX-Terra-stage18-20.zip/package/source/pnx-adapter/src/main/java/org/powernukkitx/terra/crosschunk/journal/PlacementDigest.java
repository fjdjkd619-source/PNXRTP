package org.powernukkitx.terra.crosschunk.journal;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;
import java.util.Comparator;
import java.util.HexFormat;
import java.util.List;

/** Stable digest of every durable placement affecting one target, independent of append/completion order. */
public final class PlacementDigest {
    private PlacementDigest() {}

    public static String compute(Collection<PlacementRecord> records, ChunkPos target) {
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (DataOutputStream out = new DataOutputStream(bytes)) {
                out.writeInt(1);
                out.writeInt(target.x());
                out.writeInt(target.z());
                List<PlacementRecord> ordered = records.stream()
                        .filter(record -> record.targetChunks().contains(target))
                        .sorted(Comparator.comparing(record -> record.key().stableId())).toList();
                out.writeInt(ordered.size());
                for (PlacementRecord record : ordered) {
                    out.writeUTF(record.key().stableId());
                    List<BlockWrite> writes = record.writes().stream()
                            .filter(write -> write.chunk().equals(target)).toList();
                    out.writeInt(writes.size());
                    for (BlockWrite write : writes) {
                        out.writeInt(write.x()); out.writeInt(write.y()); out.writeInt(write.z());
                        out.writeByte(write.layer());
                        byte[] payload = write.canonicalState();
                        out.writeInt(payload.length); out.write(payload);
                    }
                }
            }
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes.toByteArray()));
        } catch (IOException impossible) {
            throw new IllegalStateException("In-memory digest encoding failed", impossible);
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 unavailable", impossible);
        }
    }
}
