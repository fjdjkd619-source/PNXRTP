package org.powernukkitx.terra.crosschunk.journal;

import java.util.*;

/** Immutable root placement transaction. Duplicate coordinates within this placement are last-write-wins. */
public record PlacementRecord(PlacementKey key, List<BlockWrite> writes) {
    public PlacementRecord {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(writes, "writes");
        if (writes.isEmpty()) throw new IllegalArgumentException("A committed placement must contain writes");
        if (writes.size() > 2_000_000) throw new IllegalArgumentException("Placement exceeds write limit");
        writes = List.copyOf(writes);
    }
    public Set<ChunkPos> targetChunks() {
        TreeSet<ChunkPos> result = new TreeSet<>();
        writes.forEach(w -> result.add(w.chunk()));
        return Collections.unmodifiableSet(result);
    }
}
