# Stage 18–20 finalization contract

## Generation pipeline

`Terrain -> Generated -> Structure -> Populate -> CrossChunkApply(async) -> LightPopulation -> CrossChunkPersist -> Finished`

A dependency-only source anchor is generated only through `terra_populate`. It writes root placements durably and appends its anchor-complete marker, but it does not activate its own target barrier or become sendable. A later player-demanded run resumes the populate tail, skips an already-completed anchor, then executes CrossChunkApply/LightPopulation/CrossChunkPersist/Finished.

## Target finalization

1. `activateTarget(target)` requests every source anchor in the conservative footprint.
2. The future completes only after all anchors have durable population-complete markers.
3. The applier uses `Level.getChunkIfLoaded` and validates loaded/generated/initiated state and object identity.
4. `PlacementProjection` resolves same-cell conflicts deterministically.
5. The adapter decodes canonical block state payloads, applies both PNX layers, verifies the batch, updates heightmap, and invalidates lighting.
6. PNX lighting runs after the cross-chunk writes.
7. `LevelProvider.saveChunk(x,z,chunk)` completes before the `ChunkApplied` digest event is appended and fsynced.
8. `ChunkState.canSend()` is true only for FINISHED, so the Level send queue cannot publish the target before the persist stage.

## Failure policy

- Missing/unloaded target: fail closed; never force-load from the projection applier.
- Dependency request queue full: retry asynchronously.
- Missing old-world anchor marker on a finished chunk: fail closed; no automatic overwrite.
- Incomplete durable anchor-start marker: replay population tail; idempotent placement keys protect WAL commits.
- Apply/save/digest failure: no acknowledgement and no FINISHED state; normal chunk request can retry.
- Target chunk instance replaced between prepare and persist: reject stale acknowledgement.

## Supported payload boundary

The current journal stores block-state writes for layers 0 and 1. Entity intents and block-entity NBT/loot/state are not included. Do not enable structures requiring those adapters until a separate atomic intent format is implemented.
