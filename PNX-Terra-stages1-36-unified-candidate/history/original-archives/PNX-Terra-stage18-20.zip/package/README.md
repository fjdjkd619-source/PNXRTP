# PNX-Terra — Stage 18–20

**Назначение:** завершить межчанковый цикл размещения: дождаться исходных чанков, применить WAL-проекцию к целевому чанку, сохранить её и только после этого разрешить публикацию чанка.

## Зафиксированные версии

- PowerNukkitX: `3.0.6`, commit `c57499365737654eca32df008751ef6bca5af142`
- PNX-Terra: `1.0.0`, commit `74318b4a1eae95322550f12d5eb8a76d92a93731`
- Terra: `6.6.1-BETA`, commit `05ddc8b8a66e17412670647cce78ef837b091256`
- Origen: `2.2.0`, commit `228426bb192a8d6029952aae1a77008dea5f3cda`
- Java target: 21

## Что реализовано

### Stage 18 — применение WAL и финализация чанка

1. Асинхронный контракт `GenerateStage.applyAsync` и future-конвейер генератора. Ожидание зависимостей не блокирует compute worker.
2. Новая PNX-очередь `generateChunkToStage`: dependency-prefetch доводит исходный чанк ровно до `terra_populate`, не запуская рекурсивную финализацию его самого.
3. Межчанковая проекция выбирает победителей детерминированно через `PlacementProjection`.
4. Применение разрешено только к уже загруженному, сгенерированному и инициализированному целевому чанку. Адаптер использует `Level.getChunkIfLoaded`; target applier не вызывает force-load API.
5. Состояния `POPULATED` больше недостаточно для отправки игроку: `ChunkState.canSend()` возвращает true только для `FINISHED`.
6. Проекция применяется до lighting stage; после lighting целевой чанк синхронно сохраняется через `LevelProvider.saveChunk(x,z,chunk)`, затем в WAL добавляется digest acknowledgement.
7. Digest проверяется повторно под WAL lock перед acknowledgement. Если журнал изменился между prepare/save/ack, подтверждение отклоняется, чанк остаётся непубликуемым.
8. PNX `batchProcess` поглощает исключения callback, поэтому после batch выполняется проверка фактического состояния каждого записанного блока. Частичное применение не получает acknowledgement.
9. Добавлен индекс `placementsByTarget`, чтобы выборка журнала для чанка не сканировала все placement records.

### Stage 19 — восстановление после сбоев

1. WAL v2 добавляет `AnchorStarted` и `ChunkApplied`; старые события WAL v1 остаются читаемыми.
2. `AnchorStarted` записывается до начала Terra population.
3. После перезапуска незавершённый anchor можно безопасно повторить только при наличии durable start marker. Finished chunk без такого marker не считается безопасным и не перезаписывается автоматически.
4. Если population уже завершилась, но чанк не успел получить projection/save acknowledgement, повторный запуск пропускает повторное выполнение feature graph и повторно применяет сохранённый WAL.
5. Torn/corrupt WAL tail обрезается до последнего корректного CRC32C frame.
6. Dependency scheduler повторяет отклонённые из-за полной очереди запросы асинхронно; закрытие runtime останавливает scheduler и завершает ожидающие барьеры ошибкой.
7. Если чанк выгрузился или был заменён между prepare и persist, stale instance не получает acknowledgement. Следующий запрос может повторить финализацию.

### Stage 20 — интеграционные и стресс-проверки

- WAL, CRC/torn-tail recovery, idempotency, exclusive file lock.
- Отрицательные координаты и геометрия dependency envelope.
- Барьер всех исходных anchor chunks.
- Повтор запроса после queue-full.
- Параллельные append и детерминированный конфликт победителя.
- Индексация записей по целевому чанку.
- Применение только после dependency barrier.
- Save failure, stale digest, late WAL append и unload/replaced-chunk race.
- Повторное восстановление incomplete anchor и сохранённого applied digest.

## Порядок применения патчей

Это инкрементальные изменения **поверх Stage 15 и Stage 16–17**. Не применять на чистые upstream-репозитории без предыдущих стадий.

1. Применить Stage 15 Terra Core patch и собрать patched Terra.
2. Применить Stage 15 PNX-Terra adapter patch.
3. Применить оба Stage 16–17 PNX-Terra adapter patch.
4. Применить `patches/PNX-core-stage18.patch` к PNX 3.0.6 pinned source.
5. Применить `patches/PNX-Terra-adapter-stage18-20.patch` к PNX-Terra после Stage 16–17.
6. Собрать PNX с core patch, затем PNX-Terra против patched PNX API и patched Terra.
7. Только после успешных сборок выполнить runtime-тесты на отдельной копии сервера и отдельном тестовом мире.

WAL по умолчанию хранится в `plugins/PNX-Terra/journal`. Директория должна сохраняться между перезапусками и входить в резервную копию мира.

## Важные ограничения

- Полные Gradle-сборки PNX, Terra и PNX-Terra не выполнялись; JAR не собран.
- Runtime-тест на реальном PowerNukkitX-сервере не выполнялся.
- PNX core patch проверен на захваченных исходниках `Generator`, `GenerateStage`, `ChunkState` и на точном контекстном фрагменте `Level.java`; полный checkout PNX 3.0.6 в этой рабочей среде отсутствовал. Контекст Level был сверен с pinned GitHub source, но полный `git apply --check` на полном PNX checkout ещё требуется.
- PNX-Terra adapter patch `git apply --check` прошёл на сохранённом Stage 16–17 source snapshot.
- Поддерживаются только block-state writes из WAL. Entity intents и block entities (контейнеры, таблички, спавнеры, loot/state) пока не поддержаны и остаются fail-closed.
- Stage 15 guard по-прежнему разрешает только проверенные профили `waterfall` и `dripstone_column`; неизвестные структуры не включаются автоматически.
- Индекс ускоряет поиск по целевому чанку, но WAL и исторические placement records пока не компактизируются. Дисковое и часть memory usage будут расти по мере исследования. WAL compaction/retention должна войти в Stage 29 до финального выпуска.
- Ранее сгенерированные FINISHED chunks без anchor marker не переписываются автоматически. Для существующего мира нужна отдельная миграционная/backfill стратегия.

**Не устанавливать на production.** Этот пакет — исходники и патчи для следующего этапа разработки, а не готовый серверный JAR.
