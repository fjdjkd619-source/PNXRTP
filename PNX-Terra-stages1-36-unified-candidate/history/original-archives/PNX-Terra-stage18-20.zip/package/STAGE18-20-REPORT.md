# Технический отчёт — Stage 18, 19 и 20

## Итог

Подготовлена связка PNX core + PNX-Terra adapter для двухфазной межчанковой финализации. Система теперь имеет явную границу между:

1. durable записью root placement в WAL (Stage 16);
2. завершением population исходного anchor и dependency barrier (Stage 17);
3. применением всех записей к целевому чанку, сохранением и acknowledgement (Stage 18);
4. восстановлением неполных операций после рестарта (Stage 19);
5. проверкой конкурентности, отказов и отрицательных координат (Stage 20).

## Stage 18 — техническая реализация

- PNX `GenerateStage` получил async contract `applyAsync(ChunkGenerateContext)`.
- PNX `Generator` выполняет stages как `CompletableFuture` chain; зависимый stage может завершиться позже, не блокируя compute worker.
- `ChunkState.canSend()` теперь true только в `FINISHED`. PNX Level send queue уже проверяет `canSend()` перед отправкой chunk payload; поэтому `POPULATED` больше не может уйти клиенту до завершения cross-chunk persist stage.
- `Level.generateChunkToStage` ставит исходные anchors в PNX generation queue до имени стадии `terra_populate`. Если очередь занята, запрос возвращается как retryable; если anchor уже генерируется только до terrain stage, запоминается pending stage и population запускается после завершения первой части.
- Dependency-prefetched chunks не регистрируют собственный target barrier и не запускают рекурсивную финализацию. Их population завершает durable anchor marker; полная финализация происходит при player demand.
- `ChunkFinalizationCoordinator.prepare` ждёт barrier, получает только loaded chunk, валидирует loaded/generated/initiated и применяет deterministic projection.
- PNX adapter применяет block state по обоим слоям, проверяет фактические состояния после `batchProcess`, пересчитывает heightmap и сбрасывает LightPopulated до следующего lighting stage.
- После lighting `persist` повторно проверяет digest, синхронно вызывает provider save, снимает dirty flag и только затем добавляет `ChunkApplied` WAL event.
- Поздний WAL append, save failure или смена instance не приводят к acknowledgement.
- В `PlacementJournal` добавлен индекс `placementsByTarget` для более дешёвой выборки проекций.

## Stage 19 — восстановление

- WAL version 2 добавляет `AnchorStarted` и `ChunkApplied`; decoder принимает старые version 1 placement/anchor-complete frames.
- `openAnchor` сначала записывает durable start marker.
- После рестарта incomplete anchors находятся через `incompleteAnchors(worldKey)`.
- Если chunk был FINISHED, но имеет incomplete start marker, его можно вернуть в GENERATED и повторить population tail. Если marker отсутствует, система отказывает fail-closed.
- Если anchor уже завершён, повторная попытка не запускает Terra feature graph заново: использует WAL projection и продолжает финализацию.
- Retry scheduler повторяет missing anchor requests каждые 250 ms без блокировки generation workers. Закрытие runtime закрывает scheduler.
- Applied digest записывается после успешного provider save; повторное открытие WAL восстанавливает acknowledgement.

## Stage 20 — проверки

### Java 21 tests

Компиляция core journal/scheduler/finalizer/test suites:

`javac --release 21 -Xlint:all -Werror`

Результат: PASS.

| Тест | Результат |
|---|---|
| Stage16JournalTest | PASS |
| Stage17DependencySchedulerTest | PASS |
| Stage18FinalizationTest | PASS — 16 assertions |
| Stage19RecoveryTest | PASS — 11 assertions |
| Stage20StressTest | PASS — 14 assertions |

Все пять наборов прошли 10 последовательных раундов — 50 запусков тестовых наборов.

### PNX-facing compile checks

- Journal/runtime/PNX finalizer adapter: `javac --release 21 -Xlint:all -Werror` против минимальных stubs, повторяющих проверенные PNX API signatures — PASS.
- PNX async stage pipeline + ChunkState: `javac --release 21 -Xlint:all,-this-escape -Werror` против API stubs — PASS. Исключён `this-escape` warning, уже присутствующий в базовом конструкторе PNX `Generator`, где вызывается overridable `stages(builder)`.
- Adapter patch `git apply --check` на Stage 16–17 source snapshot — PASS.
- Core patch `git apply --check` на captured core source files + Level context fixture — PASS. Полный PNX checkout не был доступен; Level hunk сверялся с pinned GitHub source excerpt.

## Что не заявляется как выполненное

- Полный Gradle build PNX — NOT RUN.
- Полный Gradle build Terra — NOT RUN.
- Полный Gradle build PNX-Terra — NOT RUN.
- Server runtime generation test — NOT RUN.
- Chunk network publication test в настоящем PNX runtime — NOT RUN.
- JAR — NOT BUILT.
- Production server/world/config/plugins — NOT MODIFIED.

## Остаточные риски и границы

1. WAL compaction/retention не реализованы. Индекс уменьшает стоимость выборки, но исторические placement records и events остаются в WAL/памяти. Это нужно закрыть на Stage 29 до выпуска.
2. Block entity и entity intents не сериализуются и не применяются; такие структуры остаются отключёнными guard.
3. Stage 15 profiles для Origen пока ограничены waterfall и dripstone_column.
4. Existing finished chunks без WAL anchor marker требуют отдельной миграции/backfill; автоматическая перегенерация запрещена.
5. Нужен полный build и runtime validation на отдельной копии PNX 3.0.6 + Terra 6.6.1-BETA + PNX-Terra 1.0.0.

## Вывод

Stage 18–20 подготовлены на уровне исходников, патчей и standalone/API-stub проверок. Ключевой алгоритм cross-chunk projection → save → durable acknowledgement и gate публикации реализован в коде. Но пока не выполнены полные сборки и реальный серверный прогон, эти стадии нельзя считать runtime-подтверждёнными и нельзя устанавливать пакет на production.
