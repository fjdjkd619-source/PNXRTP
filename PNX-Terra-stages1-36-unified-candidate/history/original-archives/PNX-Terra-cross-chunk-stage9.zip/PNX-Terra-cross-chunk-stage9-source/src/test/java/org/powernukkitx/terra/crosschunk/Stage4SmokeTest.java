package org.powernukkitx.terra.crosschunk;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

public final class Stage4SmokeTest {
    public static void main(String[] args) throws Exception {
        boundsIncludeEveryPotentialAnchorChunk();
        barrierIsNonBlockingAndWaitsForAllSources();
        failedDependencyFailsTarget();
        appliedLedgerInvalidatesOnLateArrivalAndRecovers();
        System.out.println("PASS: bounds, async barrier, failure propagation, late-arrival digest invalidation, ledger recovery");
    }

    private static void boundsIncludeEveryPotentialAnchorChunk() {
        FeatureWriteBounds bounds = new FeatureWriteBounds("castle", -40, 55, -17, 31);
        var sources = bounds.sourceChunksForTarget(new ChunkPos(-1, -1));
        check(sources.contains(new ChunkPos(-5, -3)), "negative source chunk missing");
        check(sources.contains(new ChunkPos(2, 1)), "positive source chunk missing");
        check(sources.size() > 1, "large feature should create a dependency halo");
    }

    private static void barrierIsNonBlockingAndWaitsForAllSources() throws Exception {
        GenerationBarrierCoordinator coordinator = new GenerationBarrierCoordinator();
        ChunkPos target = new ChunkPos(0, 0);
        List<ChunkPos> dependencies = GenerationBarrierCoordinator.dependenciesFor(target,
                List.of(new FeatureWriteBounds("village", -20, 20, -20, 20)));
        CompletableFuture<GenerationBarrierCoordinator.BarrierTicket> future = coordinator.awaitTarget(target,
                List.of(new FeatureWriteBounds("village", -20, 20, -20, 20)));
        check(!future.isDone(), "barrier completed before sources");
        for (ChunkPos source : dependencies) {
            if (!source.equals(target)) coordinator.sourcePopulationComplete(source);
        }
        check(!future.isDone(), "barrier ignored target's own feature pass");
        coordinator.sourcePopulationComplete(target);
        var ticket = future.get(1, TimeUnit.SECONDS);
        check(ticket.dependencies().equals(dependencies), "ticket dependency set mismatch");
        check(coordinator.awaitTarget(target, List.of()).isDone(), "completed source should satisfy later await");
    }

    private static void failedDependencyFailsTarget() {
        GenerationBarrierCoordinator coordinator = new GenerationBarrierCoordinator();
        ChunkPos target = new ChunkPos(0, 0);
        var bounds = List.of(new FeatureWriteBounds("fortress", -48, 48, -48, 48));
        var future = coordinator.awaitTarget(target, bounds);
        ChunkPos failing = GenerationBarrierCoordinator.dependenciesFor(target, bounds).stream()
                .filter(p -> !p.equals(target)).findFirst().orElseThrow();
        coordinator.sourcePopulationFailed(failing, new IllegalStateException("synthetic generation failure"));
        check(future.isCompletedExceptionally(), "dependent target did not fail");
    }

    private static void appliedLedgerInvalidatesOnLateArrivalAndRecovers() throws Exception {
        Path dir = Files.createTempDirectory("pnx-terra-stage4");
        Path file = dir.resolve("applied.ledger");
        ChunkPos chunk = new ChunkPos(-2, 7);
        byte[] first = new byte[32]; first[0] = 1;
        byte[] later = new byte[32]; later[0] = 2;
        try (AppliedChunkLedger ledger = new AppliedChunkLedger(file)) {
            check(ledger.markApplied(chunk, first), "first ack not appended");
            check(!ledger.markApplied(chunk, first), "duplicate ack appended");
            check(ledger.isApplied(chunk, first), "ack not visible");
            check(!ledger.isApplied(chunk, later), "late operation did not invalidate old snapshot");
            ledger.markApplied(chunk, later);
        }
        try (AppliedChunkLedger recovered = new AppliedChunkLedger(file)) {
            check(recovered.isApplied(chunk, later), "ledger recovery lost latest ack");
            check(!recovered.isApplied(chunk, first), "ledger recovery restored stale ack");
        }
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
