package org.powernukkitx.terra.crosschunk.transaction;

import org.powernukkitx.terra.crosschunk.CrossChunkOperation;
import org.powernukkitx.terra.crosschunk.CrossChunkPlacementJournal;
import org.powernukkitx.terra.crosschunk.PlacementKey;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public final class PlacementTransactionCoordinatorTest {
    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("pnx-terra-stage9-");
        Path wal = dir.resolve("placements.wal");
        PlacementKey key = PlacementKey.create(77L, "overworld", "castle_feature", "castle", 31, 70, -9, 0, "root");
        try (CrossChunkPlacementJournal journal = new CrossChunkPlacementJournal(wal)) {
            PlacementTransactionCoordinator<String> coordinator = new PlacementTransactionCoordinator<>(journal,
                    value -> value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            try (var root = coordinator.begin(key, 40, CrossChunkOperation.ConflictPolicy.EXCLUSIVE)) {
                root.write(31, 70, -9, 0, "stone");
                PlacementKey nestedDescriptorKey = PlacementKey.create(77L, "overworld", "castle_feature", "inner_tower", 32, 70, -9, 1, "root/inner");
                try (var nested = coordinator.begin(nestedDescriptorKey, 999, CrossChunkOperation.ConflictPolicy.ALLOW)) {
                    nested.write(32, 70, -9, 0, "brick");
                    nested.commit();
                }
                try (var aborted = coordinator.begin(key, 40, CrossChunkOperation.ConflictPolicy.EXCLUSIVE)) {
                    aborted.write(33, 70, -9, 0, "must-not-appear");
                    aborted.abort();
                }
                check(journal.operationsForChunk(1, -1).isEmpty(), "nested commit must not publish before root commit");
                root.commit();
            }
            coordinator.assertNoOpenScopes();
            List<CrossChunkOperation> west = journal.operationsForChunk(1, -1);
            List<CrossChunkOperation> east = journal.operationsForChunk(2, -1);
            check(west.size() == 1 && east.size() == 1, "root commit must atomically publish writes across both target chunks");
            check(west.get(0).ordinal() != east.get(0).ordinal(), "ordinals must be unique across the root placement");
            check(east.get(0).priority() == 40 && east.get(0).policy() == CrossChunkOperation.ConflictPolicy.EXCLUSIVE,
                    "nested descriptor must not override root priority or conflict policy");
            check(!new String(west.get(0).statePayload(), java.nio.charset.StandardCharsets.UTF_8).contains("must-not-appear")
                    && !new String(east.get(0).statePayload(), java.nio.charset.StandardCharsets.UTF_8).contains("must-not-appear"),
                    "aborted nested writes must not be journaled");
        }
        try (CrossChunkPlacementJournal recovered = new CrossChunkPlacementJournal(wal)) {
            check(recovered.operationsForChunk(1, -1).size() == 1
                    && recovered.operationsForChunk(2, -1).size() == 1, "cross-chunk root placement must survive journal recovery");
            check(recovered.operationsForChunk(2, -1).get(0).placementKey().equals(key),
                    "nested descriptor must inherit the root placement identity");
        }
        Path failedWal = dir.resolve("failed-encode.wal");
        try (CrossChunkPlacementJournal journal = new CrossChunkPlacementJournal(failedWal)) {
            PlacementTransactionCoordinator<String> failing = new PlacementTransactionCoordinator<>(journal, value -> {
                throw new java.io.IOException("synthetic codec failure");
            });
            var scope = failing.begin(key, 1, CrossChunkOperation.ConflictPolicy.ALLOW);
            scope.write(0, 64, 0, 0, "bad");
            boolean failed = false;
            try { scope.commit(); } catch (java.io.IOException expected) { failed = true; }
            check(failed && failing.hasOpenScope(), "failed encoding must leave root scope open for explicit abort/retry");
            scope.abort();
            failing.assertNoOpenScopes();
            check(journal.operationsForChunk(0, 0).isEmpty(), "failed encoding must not publish a partial journal frame");
            var abortedRoot = failing.begin(key, 1, CrossChunkOperation.ConflictPolicy.ALLOW);
            abortedRoot.write(1, 64, 1, 0, "discard-root");
            abortedRoot.abort();
            check(journal.operationsForChunk(0, 0).isEmpty() && journal.operationsForChunk(0, 0).isEmpty(),
                    "root abort must publish no journal operations");
        }
        System.out.println("PASS: nested savepoint commit, abort isolation, root atomic publication, identity/policy inheritance, failed-encode rollback, root abort, WAL recovery");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
