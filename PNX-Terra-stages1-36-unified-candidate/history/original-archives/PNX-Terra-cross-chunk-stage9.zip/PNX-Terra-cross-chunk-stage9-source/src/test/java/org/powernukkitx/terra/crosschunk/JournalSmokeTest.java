package org.powernukkitx.terra.crosschunk;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public final class JournalSmokeTest {
    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("terra-cross-chunk-test");
        Path file = dir.resolve("placements.log");
        PlacementKey key = PlacementKey.create(42L, "minecraft:overworld", "origen:fortress",
                "origen:fortress_large", -1, 80, 17, 2, "root/structure[0]");
        CrossChunkOperation op = new CrossChunkOperation(-1, 80, 17, 0, 10,
                CrossChunkOperation.ConflictPolicy.EXCLUSIVE, key, 0, new byte[]{1, 2, 3});
        PlacementKey competing = PlacementKey.create(42L, "minecraft:overworld", "origen:village",
                "origen:house", -1, 80, 17, 0, "root");
        CrossChunkOperation exclusive = new CrossChunkOperation(-1, 80, 17, 0, 5,
                CrossChunkOperation.ConflictPolicy.EXCLUSIVE, competing, 0, new byte[]{9});
        var winnerA = CrossChunkPlacementJournal.resolveWinner(List.of(op, exclusive), true).orElseThrow();
        var winnerB = CrossChunkPlacementJournal.resolveWinner(List.of(exclusive, op), true).orElseThrow();
        if (!winnerA.equals(winnerB) || !winnerA.placementKey().equals(key)) {
            throw new AssertionError("conflict winner depends on arrival order");
        }
        CrossChunkOperation replaceable = new CrossChunkOperation(-1, 80, 17, 0, 100,
                CrossChunkOperation.ConflictPolicy.REPLACEABLE_ONLY, competing, 1, new byte[]{7});
        if (CrossChunkPlacementJournal.resolveWinner(List.of(replaceable), false).isPresent()) {
            throw new AssertionError("REPLACEABLE_ONLY ignored base terrain");
        }
        try (CrossChunkPlacementJournal journal = new CrossChunkPlacementJournal(file)) {
            if (!journal.append(key, List.of(op))) throw new AssertionError("first append not stored");
            if (journal.append(key, List.of(op))) throw new AssertionError("duplicate append not idempotent");
            if (journal.operationsForChunk(-1, 1).size() != 1) throw new AssertionError("floorDiv target chunk wrong");
        }
        Files.write(file, new byte[]{0x50, 0x54}, java.nio.file.StandardOpenOption.APPEND);
        try (CrossChunkPlacementJournal journal = new CrossChunkPlacementJournal(file)) {
            if (journal.operationsForChunk(-1, 1).size() != 1) throw new AssertionError("recovery lost committed op");
        }
        System.out.println("PASS: deterministic conflict winner, replaceable-only guard, durable append, idempotency, negative-coordinate chunking, torn-tail recovery");
    }
}
