package org.powernukkitx.terra.crosschunk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public final class CrossChunkDependencySchedulerTest {
    public static void main(String[] args) {
        schedulesEveryPotentialSourceThroughPopulation();
        propagatesSourceFailure();
        System.out.println("PASS: dependency halo scheduling, POPULATED barrier, source failure propagation");
    }

    private static void schedulesEveryPotentialSourceThroughPopulation() {
        ChunkPos target = new ChunkPos(-1, 2);
        List<FeatureWriteBounds> bounds = List.of(
                new FeatureWriteBounds("castle", -40, 55, -8, 24),
                new FeatureWriteBounds("bridge", 0, 30, -2, 2));
        List<ChunkPos> expected = GenerationBarrierCoordinator.dependenciesFor(target, bounds);
        ImmediateDriver driver = new ImmediateDriver();
        ChunkGenerationRequestCoordinator coordinator = new ChunkGenerationRequestCoordinator(driver);
        CrossChunkDependencyScheduler scheduler = new CrossChunkDependencyScheduler(coordinator, bounds);
        GenerationBarrierCoordinator.BarrierTicket ticket = scheduler.awaitTargetPopulation(target).join();
        check(ticket.dependencies().equals(expected), "ticket contains exact sorted dependency halo");
        check(ticket.dependencies().contains(target), "target includes itself");
        for (ChunkPos source : expected) {
            List<ChunkGenerationRequestCoordinator.Phase> phases = driver.history.get(source);
            check(phases != null, "every source chunk was scheduled: " + source);
            check(phases.equals(List.of(
                    ChunkGenerationRequestCoordinator.Phase.TERRAIN,
                    ChunkGenerationRequestCoordinator.Phase.GENERATED,
                    ChunkGenerationRequestCoordinator.Phase.STRUCTURES,
                    ChunkGenerationRequestCoordinator.Phase.POPULATED)), "source reached POPULATED: " + source);
        }
    }

    private static void propagatesSourceFailure() {
        ChunkPos target = new ChunkPos(0, 0);
        FeatureWriteBounds bounds = new FeatureWriteBounds("wide_structure", -20, 20, -20, 20);
        FailingDriver driver = new FailingDriver();
        ChunkGenerationRequestCoordinator coordinator = new ChunkGenerationRequestCoordinator(driver);
        CrossChunkDependencyScheduler scheduler = new CrossChunkDependencyScheduler(coordinator, List.of(bounds));
        CompletableFuture<GenerationBarrierCoordinator.BarrierTicket> future = scheduler.awaitTargetPopulation(target);
        check(future.isCompletedExceptionally(), "dependency failure must fail target readiness");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static final class ImmediateDriver implements ChunkGenerationRequestCoordinator.Driver {
        final Map<ChunkPos, ChunkGenerationRequestCoordinator.Phase> completed = new ConcurrentHashMap<>();
        final Map<ChunkPos, List<ChunkGenerationRequestCoordinator.Phase>> history = new ConcurrentHashMap<>();
        @Override public ChunkGenerationRequestCoordinator.Phase completedPhase(ChunkPos chunk) {
            return completed.getOrDefault(chunk, ChunkGenerationRequestCoordinator.Phase.NEW);
        }
        @Override public CompletableFuture<Void> runPhase(ChunkPos chunk, ChunkGenerationRequestCoordinator.Phase phase) {
            history.computeIfAbsent(chunk, ignored -> new ArrayList<>()).add(phase);
            completed.put(chunk, phase);
            return CompletableFuture.completedFuture(null);
        }
    }

    private static final class FailingDriver implements ChunkGenerationRequestCoordinator.Driver {
        @Override public ChunkGenerationRequestCoordinator.Phase completedPhase(ChunkPos chunk) {
            return ChunkGenerationRequestCoordinator.Phase.NEW;
        }
        @Override public CompletableFuture<Void> runPhase(ChunkPos chunk, ChunkGenerationRequestCoordinator.Phase phase) {
            return CompletableFuture.failedFuture(new IllegalStateException("source failed"));
        }
    }
}
