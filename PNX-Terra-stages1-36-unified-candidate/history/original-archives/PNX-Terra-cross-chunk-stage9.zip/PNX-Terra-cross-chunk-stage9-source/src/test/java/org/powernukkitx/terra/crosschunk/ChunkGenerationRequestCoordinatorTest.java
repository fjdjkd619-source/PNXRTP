package org.powernukkitx.terra.crosschunk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public final class ChunkGenerationRequestCoordinatorTest {
    public static void main(String[] args) {
        coalescesAndExtendsTarget();
        concurrentBurstUsesSinglePipeline();
        skipsDurablyCompletedPhases();
        failedPhaseCanBeRetried();
        idleSlotCanBeForgotten();
        System.out.println("PASS: request coalescing, target extension, completed-phase skip, retry, unload cleanup");
    }

    private static void coalescesAndExtendsTarget() {
        ChunkPos pos = new ChunkPos(-3, 7);
        ManualDriver driver = new ManualDriver();
        ChunkGenerationRequestCoordinator coordinator = new ChunkGenerationRequestCoordinator(driver);
        CompletableFuture<Void> generated = coordinator.request(pos, ChunkGenerationRequestCoordinator.Phase.GENERATED);
        CompletableFuture<Void> populated = coordinator.request(pos, ChunkGenerationRequestCoordinator.Phase.POPULATED);
        CompletableFuture<Void> finalized = coordinator.request(pos, ChunkGenerationRequestCoordinator.Phase.FINALIZED);
        check(driver.calls(pos) == 1, "only TERRAIN should be running initially");
        check(driver.phases(pos).equals(List.of(ChunkGenerationRequestCoordinator.Phase.TERRAIN)), "first phase order");
        driver.completeNext(pos);
        check(driver.phases(pos).get(1) == ChunkGenerationRequestCoordinator.Phase.GENERATED, "generated phase follows terrain");
        driver.completeNext(pos);
        check(generated.isDone() && !populated.isDone() && !finalized.isDone(), "waiters complete at their own requested phase");
        driver.completeNext(pos);
        driver.completeNext(pos);
        check(populated.isDone() && !finalized.isDone(), "populate waiter completes without waiting for finalization");
        driver.completeNext(pos);
        finalized.join();
        check(driver.phases(pos).equals(List.of(
                ChunkGenerationRequestCoordinator.Phase.TERRAIN,
                ChunkGenerationRequestCoordinator.Phase.GENERATED,
                ChunkGenerationRequestCoordinator.Phase.STRUCTURES,
                ChunkGenerationRequestCoordinator.Phase.POPULATED,
                ChunkGenerationRequestCoordinator.Phase.FINALIZED)), "each phase runs exactly once in order");
    }

    private static void concurrentBurstUsesSinglePipeline() {
        ChunkPos pos = new ChunkPos(-120, 85);
        ManualDriver driver = new ManualDriver();
        ChunkGenerationRequestCoordinator coordinator = new ChunkGenerationRequestCoordinator(driver);
        ExecutorService pool = Executors.newFixedThreadPool(8);
        try {
            List<Future<CompletableFuture<Void>>> submissions = new ArrayList<>();
            ChunkGenerationRequestCoordinator.Phase[] phases = ChunkGenerationRequestCoordinator.Phase.values();
            for (int i = 0; i < 160; i++) {
                final var phase = phases[1 + (i % (phases.length - 1))];
                submissions.add(pool.submit(() -> coordinator.request(pos, phase)));
            }
            List<CompletableFuture<Void>> waiters = new ArrayList<>();
            for (Future<CompletableFuture<Void>> submission : submissions) waiters.add(submission.get());
            while (waiters.stream().anyMatch(future -> !future.isDone())) driver.completeNext(pos);
            waiters.forEach(CompletableFuture::join);
            check(driver.phases(pos).size() == phases.length - 1, "concurrent burst must run each phase exactly once");
            check(driver.phases(pos).get(driver.phases(pos).size() - 1) == ChunkGenerationRequestCoordinator.Phase.FINALIZED,
                    "highest concurrent request must extend the shared pipeline");
        } catch (Exception failure) {
            throw new AssertionError("concurrent burst failed", failure);
        } finally {
            pool.shutdownNow();
        }
    }

    private static void skipsDurablyCompletedPhases() {
        ChunkPos pos = new ChunkPos(0, 0);
        ManualDriver driver = new ManualDriver();
        driver.persisted.put(pos, ChunkGenerationRequestCoordinator.Phase.POPULATED);
        ChunkGenerationRequestCoordinator coordinator = new ChunkGenerationRequestCoordinator(driver);
        coordinator.request(pos, ChunkGenerationRequestCoordinator.Phase.POPULATED).join();
        check(driver.calls(pos) == 0, "already populated chunk must not be regenerated");
        coordinator.request(pos, ChunkGenerationRequestCoordinator.Phase.FINALIZED);
        check(driver.phases(pos).equals(List.of(ChunkGenerationRequestCoordinator.Phase.FINALIZED)), "resume at next missing phase");
        driver.completeNext(pos);
    }

    private static void failedPhaseCanBeRetried() {
        ChunkPos pos = new ChunkPos(4, -9);
        ManualDriver driver = new ManualDriver();
        ChunkGenerationRequestCoordinator coordinator = new ChunkGenerationRequestCoordinator(driver);
        CompletableFuture<Void> first = coordinator.request(pos, ChunkGenerationRequestCoordinator.Phase.POPULATED);
        driver.failNext(pos, new IllegalStateException("simulated stage failure"));
        check(first.isCompletedExceptionally(), "failed phase must fail current waiter");
        CompletableFuture<Void> retry = coordinator.request(pos, ChunkGenerationRequestCoordinator.Phase.POPULATED);
        check(driver.calls(pos) == 2, "retry starts from last durably completed phase");
        while (!retry.isDone()) driver.completeNext(pos);
        retry.join();
    }

    private static void idleSlotCanBeForgotten() {
        ChunkPos pos = new ChunkPos(1, 1);
        ManualDriver driver = new ManualDriver();
        ChunkGenerationRequestCoordinator coordinator = new ChunkGenerationRequestCoordinator(driver);
        coordinator.request(pos, ChunkGenerationRequestCoordinator.Phase.TERRAIN);
        check(!coordinator.forget(pos), "active slot cannot be forgotten");
        driver.completeNext(pos);
        check(coordinator.forget(pos), "idle slot can be forgotten after unload");
        check(coordinator.trackedChunks() == 0, "forget releases retained slot");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static final class ManualDriver implements ChunkGenerationRequestCoordinator.Driver {
        private final Map<ChunkPos, ChunkGenerationRequestCoordinator.Phase> persisted = new ConcurrentHashMap<>();
        private final Map<ChunkPos, List<ChunkGenerationRequestCoordinator.Phase>> history = new ConcurrentHashMap<>();
        private final Map<ChunkPos, List<CompletableFuture<Void>>> pending = new ConcurrentHashMap<>();
        private final AtomicInteger calls = new AtomicInteger();

        @Override
        public ChunkGenerationRequestCoordinator.Phase completedPhase(ChunkPos chunk) {
            return persisted.getOrDefault(chunk, ChunkGenerationRequestCoordinator.Phase.NEW);
        }

        @Override
        public CompletableFuture<Void> runPhase(ChunkPos chunk, ChunkGenerationRequestCoordinator.Phase phase) {
            calls.incrementAndGet();
            history.computeIfAbsent(chunk, ignored -> new ArrayList<>()).add(phase);
            CompletableFuture<Void> future = new CompletableFuture<>();
            pending.computeIfAbsent(chunk, ignored -> new ArrayList<>()).add(future);
            return future.thenRun(() -> persisted.put(chunk, phase));
        }

        int calls(ChunkPos chunk) { return history.getOrDefault(chunk, List.of()).size(); }
        List<ChunkGenerationRequestCoordinator.Phase> phases(ChunkPos chunk) { return history.getOrDefault(chunk, List.of()); }

        void completeNext(ChunkPos chunk) {
            List<CompletableFuture<Void>> list = pending.get(chunk);
            CompletableFuture<Void> future = list.remove(0);
            future.complete(null);
        }

        void failNext(ChunkPos chunk, Throwable failure) {
            List<CompletableFuture<Void>> list = pending.get(chunk);
            list.remove(0).completeExceptionally(failure);
        }
    }
}
