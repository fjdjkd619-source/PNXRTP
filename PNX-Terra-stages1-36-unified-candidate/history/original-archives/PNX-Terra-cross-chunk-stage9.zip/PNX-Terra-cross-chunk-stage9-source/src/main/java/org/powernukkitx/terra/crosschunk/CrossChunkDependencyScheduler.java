package org.powernukkitx.terra.crosschunk;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

/**
 * Connects feature write bounds to the coalesced generation request coordinator.
 * Every possible source/anchor chunk is requested through POPULATED before the
 * target is allowed to enter its placement-finalization step.
 */
public final class CrossChunkDependencyScheduler {
    private final ChunkGenerationRequestCoordinator requests;
    private final List<FeatureWriteBounds> enabledBounds;

    public CrossChunkDependencyScheduler(
            ChunkGenerationRequestCoordinator requests,
            Collection<FeatureWriteBounds> enabledBounds) {
        this.requests = Objects.requireNonNull(requests, "requests");
        this.enabledBounds = List.copyOf(Objects.requireNonNull(enabledBounds, "enabledBounds"));
    }

    /**
     * Schedules all source chunks whose declared feature extents can reach the
     * target and completes asynchronously once their feature placements are
     * committed. No source-generation worker is synchronously blocked.
     */
    public CompletableFuture<GenerationBarrierCoordinator.BarrierTicket> awaitTargetPopulation(ChunkPos target) {
        List<ChunkPos> dependencies = GenerationBarrierCoordinator.dependenciesFor(target, enabledBounds);
        CompletableFuture<?>[] scheduled = dependencies.stream()
                .map(source -> requests.request(source, ChunkGenerationRequestCoordinator.Phase.POPULATED))
                .toArray(CompletableFuture[]::new);
        return CompletableFuture.allOf(scheduled)
                .thenApply(ignored -> new GenerationBarrierCoordinator.BarrierTicket(target, dependencies));
    }
}
