package org.powernukkitx.terra.crosschunk;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.zip.CRC32C;

/**
 * Durable acknowledgement ledger for target-chunk operation snapshots.
 *
 * The caller MUST persist/save the target chunk first, then call markApplied.
 * A crash between chunk save and this acknowledgement causes safe idempotent
 * replay; acknowledging before the chunk is durable can lose generated blocks.
 * A later incoming operation changes the snapshot digest and invalidates the
 * old acknowledgement automatically.
 */
@SuppressWarnings("try")
public final class AppliedChunkLedger implements AutoCloseable {
    private static final int MAGIC = 0x50545841; // PTXA
    private static final short VERSION = 1;
    private static final int BODY_BYTES = Integer.BYTES * 2 + 32;
    private static final int FRAME_BYTES = Integer.BYTES + Short.BYTES + BODY_BYTES + Integer.BYTES;

    private final Path path;
    private final FileChannel channel;
    private final Map<ChunkPos, byte[]> applied = new HashMap<>();
    private boolean closed;

    public AppliedChunkLedger(Path file) throws IOException {
        path = Objects.requireNonNull(file, "file").toAbsolutePath();
        Path parent = path.getParent();
        if (parent != null) Files.createDirectories(parent);
        if (!Files.exists(path)) Files.createFile(path);
        recover();
        channel = FileChannel.open(path, StandardOpenOption.READ, StandardOpenOption.WRITE);
        channel.position(channel.size());
    }

    public synchronized boolean isApplied(ChunkPos chunk, byte[] snapshotDigest) {
        ensureOpen();
        byte[] prior = applied.get(chunk);
        return prior != null && MessageDigest.isEqual(prior, requireDigest(snapshotDigest));
    }

    /** Append acknowledgement after target chunk persistence has succeeded. */
    public synchronized boolean markApplied(ChunkPos chunk, byte[] snapshotDigest) throws IOException {
        ensureOpen();
        Objects.requireNonNull(chunk, "chunk");
        byte[] digest = requireDigest(snapshotDigest);
        byte[] prior = applied.get(chunk);
        if (prior != null && MessageDigest.isEqual(prior, digest)) return false;

        ByteBuffer body = ByteBuffer.allocate(BODY_BYTES);
        body.putInt(chunk.x()).putInt(chunk.z()).put(digest).flip();
        CRC32C crc = new CRC32C();
        crc.update(body.asReadOnlyBuffer());
        ByteBuffer frame = ByteBuffer.allocate(FRAME_BYTES);
        frame.putInt(MAGIC).putShort(VERSION).put(body).putInt((int) crc.getValue()).flip();
        try (FileLock ignored = channel.lock()) {
            channel.position(channel.size());
            while (frame.hasRemaining()) channel.write(frame);
            channel.force(true);
        }
        applied.put(chunk, digest.clone());
        return true;
    }

    private void recover() throws IOException {
        try (FileChannel read = FileChannel.open(path, StandardOpenOption.READ, StandardOpenOption.WRITE)) {
            long size = read.size(), offset = 0, validEnd = 0;
            ByteBuffer frame = ByteBuffer.allocate(FRAME_BYTES);
            while (offset < size) {
                frame.clear();
                int total = 0;
                while (frame.hasRemaining()) {
                    int n = read.read(frame, offset + total);
                    if (n <= 0) break;
                    total += n;
                }
                if (total < FRAME_BYTES) break; // torn final acknowledgement
                frame.flip();
                int magic = frame.getInt();
                short version = frame.getShort();
                int x = frame.getInt(), z = frame.getInt();
                byte[] digest = new byte[32]; frame.get(digest);
                int expectedCrc = frame.getInt();
                if (magic != MAGIC || version != VERSION) throw new IOException("Invalid applied-ledger frame at " + offset);
                ByteBuffer body = ByteBuffer.allocate(BODY_BYTES).putInt(x).putInt(z).put(digest);
                body.flip();
                CRC32C crc = new CRC32C(); crc.update(body);
                if ((int) crc.getValue() != expectedCrc) throw new IOException("Applied-ledger checksum mismatch at " + offset);
                applied.put(new ChunkPos(x, z), digest);
                offset += FRAME_BYTES;
                validEnd = offset;
            }
            if (validEnd != size) { read.truncate(validEnd); read.force(true); }
        }
    }

    private static byte[] requireDigest(byte[] digest) {
        Objects.requireNonNull(digest, "snapshotDigest");
        if (digest.length != 32) throw new IllegalArgumentException("Snapshot digest must be SHA-256 (32 bytes)");
        return digest;
    }

    private void ensureOpen() { if (closed) throw new IllegalStateException("Ledger is closed"); }

    @Override public synchronized void close() throws IOException {
        if (!closed) { closed = true; channel.close(); }
    }
}
