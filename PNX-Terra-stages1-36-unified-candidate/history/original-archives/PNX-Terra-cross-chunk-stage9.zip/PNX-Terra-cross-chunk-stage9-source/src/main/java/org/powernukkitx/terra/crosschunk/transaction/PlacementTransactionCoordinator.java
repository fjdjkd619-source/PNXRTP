package org.powernukkitx.terra.crosschunk.transaction;

import org.powernukkitx.terra.crosschunk.CrossChunkOperation;
import org.powernukkitx.terra.crosschunk.CrossChunkPlacementJournal;
import org.powernukkitx.terra.crosschunk.PlacementKey;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Objects;

/**
 * Bridges Terra's nested placement scopes to the durable cross-chunk journal.
 *
 * A root placement is the atomic journal unit. Nested structure scopes are
 * savepoints: commit merges their writes into the parent; abort discards them.
 * Only committing the root writes one complete placement frame to the WAL.
 *
 * Instances are intended to be owned by one generation context. A thread-local
 * stack isolates concurrent generation workers; a scope must be closed on the
 * same thread and in strict LIFO order.
 */
public final class PlacementTransactionCoordinator<S> {
    @FunctionalInterface
    public interface StateEncoder<S> {
        byte[] encode(S state) throws IOException;
    }

    private final CrossChunkPlacementJournal journal;
    private final StateEncoder<S> encoder;
    private final ThreadLocal<Deque<Scope>> scopes = ThreadLocal.withInitial(ArrayDeque::new);

    public PlacementTransactionCoordinator(CrossChunkPlacementJournal journal, StateEncoder<S> encoder) {
        this.journal = Objects.requireNonNull(journal, "journal");
        this.encoder = Objects.requireNonNull(encoder, "encoder");
    }

    /** Opens a root placement or a nested savepoint belonging to that root. */
    public Scope begin(PlacementKey key, int priority, CrossChunkOperation.ConflictPolicy policy) {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(policy, "policy");
        Deque<Scope> stack = scopes.get();
        Scope parent = stack.peek();
        // A nested Terra structure has its own descriptor, but remains part of
        // the root placement's atomic journal frame. The root key is inherited.
        Scope scope = new Scope(parent, parent == null ? key : parent.key,
                parent == null ? priority : parent.priority,
                parent == null ? policy : parent.policy);
        stack.push(scope);
        return scope;
    }

    public boolean hasOpenScope() {
        return !scopes.get().isEmpty();
    }

    /** Fails closed if a generator stage exits while a scope remains open. */
    public void assertNoOpenScopes() {
        Deque<Scope> stack = scopes.get();
        if (!stack.isEmpty()) {
            throw new IllegalStateException("Generation ended with " + stack.size() + " unclosed placement scope(s)");
        }
        scopes.remove();
    }

    public final class Scope implements AutoCloseable {
        private final Scope parent;
        private final PlacementKey key;
        private final int priority;
        private final CrossChunkOperation.ConflictPolicy policy;
        private final List<PendingWrite<S>> writes = new ArrayList<>();
        private final Thread owner = Thread.currentThread();
        private boolean closed;

        private Scope(Scope parent, PlacementKey key, int priority, CrossChunkOperation.ConflictPolicy policy) {
            this.parent = parent;
            this.key = key;
            this.priority = priority;
            this.policy = policy;
        }

        public void write(int x, int y, int z, int layer, S state) {
            requireTopAndOpen();
            if (layer < 0 || layer > 1) throw new IllegalArgumentException("PNX block layer must be 0 or 1");
            writes.add(new PendingWrite<>(x, y, z, layer, Objects.requireNonNull(state, "state")));
        }

        /** Commits this savepoint; only the root commit reaches durable storage. */
        public void commit() throws IOException {
            requireTopAndOpen();
            Deque<Scope> stack = scopes.get();
            if (parent != null) {
                // Savepoint commit is an in-memory merge only. A parent abort
                // still discards every write made by this nested structure.
                parent.writes.addAll(writes);
            } else {
                // Encode and durably append BEFORE popping/closing the root.
                // If encoding or WAL I/O fails, the scope remains open and can
                // be retried or explicitly aborted; no half-commit is exposed.
                List<CrossChunkOperation> operations = new ArrayList<>(writes.size());
                int ordinal = 0;
                for (PendingWrite<S> write : writes) {
                    byte[] payload = Objects.requireNonNull(encoder.encode(write.state()), "encoder returned null payload");
                    operations.add(new CrossChunkOperation(write.x(), write.y(), write.z(), write.layer(),
                            priority, policy, key, ordinal++, payload));
                }
                journal.append(key, operations);
            }
            stack.pop();
            closed = true;
            cleanup(stack);
        }

        /** Discards this scope and all of its writes without touching the WAL. */
        public void abort() {
            requireTopAndOpen();
            Deque<Scope> stack = scopes.get();
            stack.pop();
            writes.clear();
            closed = true;
            cleanup(stack);
        }

        @Override public void close() {
            if (!closed) abort();
        }

        private void requireTopAndOpen() {
            if (Thread.currentThread() != owner) throw new IllegalStateException("Placement scope is thread-confined");
            if (closed) throw new IllegalStateException("Placement scope is already closed");
            if (scopes.get().peek() != this) throw new IllegalStateException("Placement scopes must close in LIFO order");
        }
    }

    private void cleanup(Deque<Scope> stack) {
        if (stack.isEmpty()) scopes.remove();
    }

    private record PendingWrite<S>(int x, int y, int z, int layer, S state) {}
}
