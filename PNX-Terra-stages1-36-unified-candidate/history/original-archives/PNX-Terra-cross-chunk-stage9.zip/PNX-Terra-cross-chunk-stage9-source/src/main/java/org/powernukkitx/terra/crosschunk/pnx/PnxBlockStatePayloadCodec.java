package org.powernukkitx.terra.crosschunk.pnx;

import org.powernukkitx.block.BlockProperties;
import org.powernukkitx.block.BlockState;
import org.powernukkitx.registry.Registries;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Objects;

/**
 * Stable, registry-aware payload for a PNX BlockState.
 *
 * The payload deliberately stores identifier + specialValue, not the runtime
 * block-state hash. The hash is an implementation detail and is not a durable
 * cross-version identifier. The receiving server must use the same registered
 * block definitions; unknown identifiers/states fail closed.
 */
public final class PnxBlockStatePayloadCodec {
    private static final int MAGIC = 0x504E5853; // PNXS
    private static final short VERSION = 1;
    private static final int MAX_IDENTIFIER_CHARS = 512;

    private PnxBlockStatePayloadCodec() {}

    public static byte[] encode(BlockState state) throws IOException {
        Objects.requireNonNull(state, "state");
        String identifier = Objects.requireNonNull(state.getIdentifier(), "state identifier");
        if (identifier.isBlank() || identifier.length() > MAX_IDENTIFIER_CHARS) {
            throw new IOException("Invalid PNX block identifier length");
        }
        BlockProperties properties = Registries.BLOCK.getBlockProperties(identifier);
        if (properties == null || !properties.containBlockState(state)) {
            throw new IOException("Block state is not canonical in the active PNX registry: " + identifier);
        }
        ByteArrayOutputStream bytes = new ByteArrayOutputStream(64);
        try (DataOutputStream out = new DataOutputStream(bytes)) {
            out.writeInt(MAGIC);
            out.writeShort(VERSION);
            out.writeUTF(identifier);
            out.writeShort(state.specialValue());
        }
        return bytes.toByteArray();
    }

    public static BlockState decode(byte[] payload) throws IOException {
        Objects.requireNonNull(payload, "payload");
        if (payload.length < 10 || payload.length > 1024) {
            throw new IOException("Invalid PNX block-state payload length");
        }
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(payload))) {
            if (in.readInt() != MAGIC) throw new IOException("Invalid PNX block-state payload magic");
            if (in.readShort() != VERSION) throw new IOException("Unsupported PNX block-state payload version");
            String identifier = in.readUTF();
            if (identifier.isBlank() || identifier.length() > MAX_IDENTIFIER_CHARS) {
                throw new IOException("Invalid PNX block identifier");
            }
            short specialValue = in.readShort();
            if (in.available() != 0) throw new IOException("Trailing bytes in PNX block-state payload");
            BlockProperties properties = Registries.BLOCK.getBlockProperties(identifier);
            if (properties == null) throw new IOException("Unregistered PNX block identifier: " + identifier);
            BlockState state = properties.getBlockState(specialValue);
            if (state == null || !identifier.equals(state.getIdentifier())) {
                throw new IOException("Unknown PNX block-state value for " + identifier + ": " + specialValue);
            }
            return state;
        } catch (IllegalArgumentException malformed) {
            throw new IOException("Malformed PNX block-state payload", malformed);
        }
    }
}
