package org.powernukkitx.terra.crosschunk;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Objects;

/**
 * Stable identity of one logical structure placement. All inputs must be
 * deterministic and independent of generation-thread scheduling.
 */
public final class PlacementKey implements Comparable<PlacementKey> {
    private static final byte[] DOMAIN = "PNX-TERRA-PLACEMENT-V1".getBytes(StandardCharsets.UTF_8);
    private final byte[] value;

    private PlacementKey(byte[] value) {
        if (value.length != 32) throw new IllegalArgumentException("SHA-256 key must be 32 bytes");
        this.value = value.clone();
    }

    public static PlacementKey create(long worldSeed, String dimensionId,
                                      String featureId, String structureId,
                                      int anchorX, int anchorY, int anchorZ,
                                      int rotation, String nestedPath) {
        Objects.requireNonNull(dimensionId, "dimensionId");
        Objects.requireNonNull(featureId, "featureId");
        Objects.requireNonNull(structureId, "structureId");
        Objects.requireNonNull(nestedPath, "nestedPath");
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(DOMAIN);
            putLong(digest, worldSeed);
            putString(digest, dimensionId);
            putString(digest, featureId);
            putString(digest, structureId);
            putInt(digest, anchorX);
            putInt(digest, anchorY);
            putInt(digest, anchorZ);
            putInt(digest, rotation);
            putString(digest, nestedPath);
            return new PlacementKey(digest.digest());
        } catch (NoSuchAlgorithmException impossible) {
            throw new AssertionError("SHA-256 is required by the Java runtime", impossible);
        }
    }

    public static PlacementKey fromBytes(byte[] bytes) { return new PlacementKey(bytes); }
    public byte[] bytes() { return value.clone(); }
    public String hex() { return HexFormat.of().formatHex(value); }

    @Override public int compareTo(PlacementKey other) {
        for (int i = 0; i < value.length; i++) {
            int a = value[i] & 0xff, b = other.value[i] & 0xff;
            if (a != b) return Integer.compare(a, b);
        }
        return 0;
    }
    @Override public boolean equals(Object other) {
        return other instanceof PlacementKey key && MessageDigest.isEqual(value, key.value);
    }
    @Override public int hashCode() { return ByteBuffer.wrap(value).getInt(); }
    @Override public String toString() { return hex(); }

    private static void putString(MessageDigest d, String value) {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        putInt(d, bytes.length);
        d.update(bytes);
    }
    private static void putInt(MessageDigest d, int value) {
        d.update(ByteBuffer.allocate(Integer.BYTES).putInt(value).array());
    }
    private static void putLong(MessageDigest d, long value) {
        d.update(ByteBuffer.allocate(Long.BYTES).putLong(value).array());
    }
}
