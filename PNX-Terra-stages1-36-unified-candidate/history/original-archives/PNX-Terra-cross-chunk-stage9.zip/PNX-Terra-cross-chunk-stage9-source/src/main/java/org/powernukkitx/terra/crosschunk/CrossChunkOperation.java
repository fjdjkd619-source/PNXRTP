package org.powernukkitx.terra.crosschunk;

import java.util.Objects;

/** One absolute block-layer write emitted by a committed placement. */
public record CrossChunkOperation(
        int x, int y, int z, int layer,
        int priority, ConflictPolicy policy,
        PlacementKey placementKey, int ordinal,
        byte[] statePayload) {

    public enum ConflictPolicy { ALLOW, PRIORITY, EXCLUSIVE, REPLACEABLE_ONLY }

    public CrossChunkOperation {
        if (layer < 0 || layer > 1) throw new IllegalArgumentException("PNX block layer must be 0 or 1");
        if (ordinal < 0) throw new IllegalArgumentException("ordinal must be non-negative");
        Objects.requireNonNull(policy, "policy");
        Objects.requireNonNull(placementKey, "placementKey");
        Objects.requireNonNull(statePayload, "statePayload");
        if (statePayload.length == 0) throw new IllegalArgumentException("statePayload must not be empty");
        statePayload = statePayload.clone();
    }

    @Override public byte[] statePayload() { return statePayload.clone(); }

    public int targetChunkX() { return Math.floorDiv(x, 16); }
    public int targetChunkZ() { return Math.floorDiv(z, 16); }
}
