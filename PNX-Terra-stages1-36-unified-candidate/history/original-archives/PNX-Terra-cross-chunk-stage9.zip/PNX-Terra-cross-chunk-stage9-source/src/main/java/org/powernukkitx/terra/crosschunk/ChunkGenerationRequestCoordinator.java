package org.powernukkitx.terra.crosschunk;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Coalesces generation requests for the same chunk and monotonically extends
 * the requested completion phase. It never waits synchronously for a stage.
 *
 * <p>The coordinator is deliberately storage/scheduler agnostic. The driver
 * must map phases to the pinned PNX/Terra pipeline, persist its own phase
 * markers, and make each phase idempotent. A failed phase completes current
 * waiters exceptionally; a later request retries from the last completed
 * phase reported by the driver.</p>
 */
public final class ChunkGenerationRequestCoordinator {
    public enum Phase {
        NEW,
        TERRAIN,
        GENERATED,
        STRUCTURES,
        POPULATED,
        FINALIZED;

        public Phase next() {
            int next = ordinal() + 1;
            return next < values().length ? values()[next] : null;
        }
    }

    public interface Driver {
        /** Returns the last durably completed phase for this chunk. */
        Phase completedPhase(ChunkPos chunk);

        /** Schedules one phase and completes only after its work is committed. */
        CompletableFuture<Void> runPhase(ChunkPos chunk, Phase phase);
    }

    private final Driver driver;
    private final ConcurrentHashMap<ChunkPos, Slot> slots = new ConcurrentHashMap<>();

    public ChunkGenerationRequestCoordinator(Driver driver) {
        this.driver = Objects.requireNonNull(driver, "driver");
    }

    /**
     * Request at least {@code requiredPhase}. Concurrent requests for a chunk
     * share one phase runner; a later request can extend its target without
     * starting a second pipeline.
     */
    public CompletableFuture<Void> request(ChunkPos chunk, Phase requiredPhase) {
        Objects.requireNonNull(chunk, "chunk");
        Objects.requireNonNull(requiredPhase, "requiredPhase");
        CompletableFuture<Void> result = new CompletableFuture<>();
        Slot[] selected = new Slot[1];
        boolean[] launch = new boolean[1];
        boolean[] alreadyComplete = new boolean[1];
        slots.compute(chunk, (key, existing) -> {
            Slot slot = existing == null
                    ? new Slot(requireCompleted(driver.completedPhase(key)))
                    : existing;
            synchronized (slot) {
                selected[0] = slot;
                if (slot.completed.ordinal() >= requiredPhase.ordinal()) {
                    alreadyComplete[0] = true;
                } else {
                    slot.waiters.computeIfAbsent(requiredPhase, ignored -> new ArrayList<>()).add(result);
                    if (!slot.running) {
                        slot.running = true;
                        launch[0] = true;
                    }
                }
            }
            return slot;
        });
        if (alreadyComplete[0]) return CompletableFuture.completedFuture(null);
        if (launch[0]) advance(chunk, selected[0]);
        return result;
    }

    /** Number of chunk slots currently retained by this coordinator. */
    public int trackedChunks() {
        return slots.size();
    }

    /**
     * Forget an idle chunk after its unload lifecycle has completed. Active
     * slots cannot be forgotten, preventing a second runner for the same chunk.
     */
    public boolean forget(ChunkPos chunk) {
        boolean[] removed = new boolean[1];
        slots.computeIfPresent(chunk, (key, slot) -> {
            synchronized (slot) {
                if (slot.running || !slot.waiters.isEmpty()) return slot;
                removed[0] = true;
                return null;
            }
        });
        return removed[0] || !slots.containsKey(chunk);
    }

    private void advance(ChunkPos chunk, Slot slot) {
        final Phase next;
        synchronized (slot) {
            Phase target = highestPending(slot);
            if (target == null || slot.completed.ordinal() >= target.ordinal()) {
                slot.running = false;
                return;
            }
            next = slot.completed.next();
            if (next == null) {
                failPending(slot, new IllegalStateException("No phase remains before requested target " + target));
                slot.running = false;
                return;
            }
        }

        final CompletableFuture<Void> phaseFuture;
        try {
            phaseFuture = Objects.requireNonNull(driver.runPhase(chunk, next), "driver returned null future");
        } catch (Throwable failure) {
            onPhaseFailure(slot, failure);
            return;
        }
        phaseFuture.whenComplete((ignored, failure) -> {
            if (failure != null) {
                onPhaseFailure(slot, unwrap(failure));
                return;
            }
            synchronized (slot) {
                if (next.ordinal() > slot.completed.ordinal()) {
                    slot.completed = next;
                }
                completeSatisfied(slot);
                if (highestPending(slot) == null) {
                    slot.running = false;
                    return;
                }
            }
            advance(chunk, slot);
        });
    }

    private static void onPhaseFailure(Slot slot, Throwable failure) {
        synchronized (slot) {
            failPending(slot, failure);
            slot.running = false;
        }
    }

    private static void completeSatisfied(Slot slot) {
        var iterator = slot.waiters.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Phase, List<CompletableFuture<Void>>> entry = iterator.next();
            if (entry.getKey().ordinal() <= slot.completed.ordinal()) {
                entry.getValue().forEach(future -> future.complete(null));
                iterator.remove();
            }
        }
    }

    private static void failPending(Slot slot, Throwable failure) {
        slot.waiters.values().forEach(list -> list.forEach(future -> future.completeExceptionally(failure)));
        slot.waiters.clear();
    }

    private static Phase highestPending(Slot slot) {
        Phase highest = null;
        for (Phase phase : slot.waiters.keySet()) {
            if (highest == null || phase.ordinal() > highest.ordinal()) highest = phase;
        }
        return highest;
    }

    private static Phase requireCompleted(Phase phase) {
        return Objects.requireNonNull(phase, "driver completedPhase returned null");
    }

    private static Throwable unwrap(Throwable failure) {
        return failure instanceof CompletionException && failure.getCause() != null ? failure.getCause() : failure;
    }

    private static final class Slot {
        private Phase completed;
        private boolean running;
        private final EnumMap<Phase, List<CompletableFuture<Void>>> waiters = new EnumMap<>(Phase.class);

        private Slot(Phase completed) {
            this.completed = completed;
        }
    }
}
