package org.powernukkitx.terra.crosschunk;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

/** Stable digest of the complete operation snapshot for one target chunk. */
public final class ChunkOperationDigest {
    private ChunkOperationDigest() {}

    public static byte[] calculate(List<CrossChunkOperation> operations) {
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (DataOutputStream out = new DataOutputStream(bytes)) {
                List<CrossChunkOperation> ordered = CrossChunkPlacementJournal.stableOrder(operations);
                out.writeInt(ordered.size());
                for (CrossChunkOperation op : ordered) {
                    out.writeInt(op.x()); out.writeInt(op.y()); out.writeInt(op.z());
                    out.writeByte(op.layer()); out.writeInt(op.priority());
                    out.writeByte(op.policy().ordinal());
                    out.write(op.placementKey().bytes());
                    out.writeInt(op.ordinal());
                    byte[] payload = op.statePayload();
                    out.writeInt(payload.length); out.write(payload);
                }
            }
            return MessageDigest.getInstance("SHA-256").digest(bytes.toByteArray());
        } catch (IOException impossible) {
            throw new AssertionError(impossible);
        } catch (NoSuchAlgorithmException impossible) {
            throw new AssertionError(impossible);
        }
    }
}
