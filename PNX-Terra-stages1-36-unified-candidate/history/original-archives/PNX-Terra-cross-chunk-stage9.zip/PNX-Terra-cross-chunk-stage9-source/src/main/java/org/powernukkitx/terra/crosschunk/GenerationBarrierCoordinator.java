package org.powernukkitx.terra.crosschunk;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.CompletableFuture;

/**
 * Non-blocking generation dependency coordinator.
 *
 * The scheduler must request/schedule every source chunk in a target's dependency
 * set, then call sourcePopulationComplete only after that source's full feature
 * population has committed its placement journal entries. The target may be
 * finalized only after its returned future completes. No worker thread waits.
 */
public final class GenerationBarrierCoordinator {
    public record BarrierTicket(ChunkPos target, List<ChunkPos> dependencies) {
        public BarrierTicket {
            Objects.requireNonNull(target, "target");
            dependencies = List.copyOf(dependencies);
        }
    }

    private final Map<ChunkPos, Throwable> failedSources = new HashMap<>();
    private final Set<ChunkPos> completedSources = new HashSet<>();
    private final Map<ChunkPos, List<Waiter>> waitersBySource = new HashMap<>();

    /** Build the dependency halo from all enabled feature write bounds. */
    public static List<ChunkPos> dependenciesFor(ChunkPos target, Collection<FeatureWriteBounds> bounds) {
        Objects.requireNonNull(target, "target");
        Objects.requireNonNull(bounds, "bounds");
        Set<ChunkPos> dependencies = new TreeSet<>();
        for (FeatureWriteBounds feature : bounds) dependencies.addAll(feature.sourceChunksForTarget(target));
        dependencies.add(target); // target's own feature pass is always part of the barrier
        return dependencies.stream().sorted().toList();
    }

    /**
     * Returns immediately with a future. The future completes when all source
     * chunks have completed feature population; failures propagate exceptionally.
     */
    public CompletableFuture<BarrierTicket> awaitTarget(
            ChunkPos target, Collection<FeatureWriteBounds> enabledBounds) {
        List<ChunkPos> dependencies = dependenciesFor(target, enabledBounds);
        CompletableFuture<BarrierTicket> future = new CompletableFuture<>();
        List<Throwable> failures = new ArrayList<>();
        synchronized (this) {
            for (ChunkPos source : dependencies) {
                Throwable failure = failedSources.get(source);
                if (failure != null) failures.add(failure);
            }
            if (!failures.isEmpty()) {
                future.completeExceptionally(failures.get(0));
                return future;
            }
            List<ChunkPos> pending = dependencies.stream().filter(source -> !completedSources.contains(source)).toList();
            if (pending.isEmpty()) {
                future.complete(new BarrierTicket(target, dependencies));
                return future;
            }
            Waiter waiter = new Waiter(target, dependencies, new HashSet<>(pending), future);
            for (ChunkPos source : pending)
                waitersBySource.computeIfAbsent(source, ignored -> new ArrayList<>()).add(waiter);
        }
        return future;
    }

    /** Call only after all feature placements originating in source are durably committed. */
    public void sourcePopulationComplete(ChunkPos source) {
        Objects.requireNonNull(source, "source");
        List<Waiter> affected;
        synchronized (this) {
            if (failedSources.containsKey(source)) throw new IllegalStateException("Source chunk already failed: " + source);
            if (!completedSources.add(source)) return;
            affected = waitersBySource.remove(source);
        }
        if (affected == null) return;
        for (Waiter waiter : affected) {
            boolean ready;
            synchronized (this) {
                waiter.pending.remove(source);
                ready = waiter.pending.isEmpty() && !waiter.future.isDone();
            }
            if (ready) waiter.future.complete(new BarrierTicket(waiter.target, waiter.dependencies));
        }
    }

    /** A failed source prevents dependent targets from being finalized as complete. */
    public void sourcePopulationFailed(ChunkPos source, Throwable failure) {
        Objects.requireNonNull(source, "source");
        Objects.requireNonNull(failure, "failure");
        List<Waiter> affected;
        synchronized (this) {
            if (completedSources.contains(source)) throw new IllegalStateException("Source chunk already completed: " + source);
            failedSources.putIfAbsent(source, failure);
            affected = waitersBySource.remove(source);
        }
        if (affected != null) {
            for (Waiter waiter : affected) {
                waiter.future.completeExceptionally(failure);
                removeWaiterFromOtherSources(waiter, source);
            }
        }
    }

    /** Snapshot useful for diagnostics; never used as a readiness substitute. */
    public synchronized Set<ChunkPos> completedSourcesSnapshot() { return Set.copyOf(completedSources); }

    private void removeWaiterFromOtherSources(Waiter waiter, ChunkPos failedSource) {
        synchronized (this) {
            for (ChunkPos source : waiter.pending) {
                if (source.equals(failedSource)) continue;
                List<Waiter> list = waitersBySource.get(source);
                if (list != null) {
                    list.remove(waiter);
                    if (list.isEmpty()) waitersBySource.remove(source);
                }
            }
            waiter.pending.clear();
        }
    }

    private static final class Waiter {
        final ChunkPos target;
        final List<ChunkPos> dependencies;
        final Set<ChunkPos> pending;
        final CompletableFuture<BarrierTicket> future;
        Waiter(ChunkPos target, List<ChunkPos> dependencies, Set<ChunkPos> pending,
               CompletableFuture<BarrierTicket> future) {
            this.target = target; this.dependencies = dependencies; this.pending = pending; this.future = future;
        }
    }
}
