package org.powernukkitx.terra.crosschunk;

/** Immutable chunk coordinate; ordering is stable and independent of scheduling. */
public record ChunkPos(int x, int z) implements Comparable<ChunkPos> {
    @Override public int compareTo(ChunkPos other) {
        int xOrder = Integer.compare(x, other.x);
        return xOrder != 0 ? xOrder : Integer.compare(z, other.z);
    }
}
