package org.powernukkitx.terra.crosschunk;

import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

/**
 * Declared horizontal write bounds relative to a feature's anchor.
 * Bounds must include every nested structure, decorator, and block-entity write.
 * Vertical bounds are intentionally omitted because chunk scheduling is X/Z based.
 */
public record FeatureWriteBounds(
        String featureId,
        int minOffsetX, int maxOffsetX,
        int minOffsetZ, int maxOffsetZ) {

    public FeatureWriteBounds {
        Objects.requireNonNull(featureId, "featureId");
        if (featureId.isBlank()) throw new IllegalArgumentException("featureId must not be blank");
        if (minOffsetX > maxOffsetX || minOffsetZ > maxOffsetZ)
            throw new IllegalArgumentException("Invalid feature write bounds");
    }

    /**
     * Finds every source/anchor chunk that could place any block into target.
     * This is exact for anchors anywhere inside a source chunk and the declared
     * rectangular bounds. It uses long arithmetic to avoid int overflow.
     */
    public Set<ChunkPos> sourceChunksForTarget(ChunkPos target) {
        Objects.requireNonNull(target, "target");
        long targetMinX = (long) target.x() * 16L;
        long targetMaxX = targetMinX + 15L;
        long targetMinZ = (long) target.z() * 16L;
        long targetMaxZ = targetMinZ + 15L;

        // anchor + [minOffset,maxOffset] intersects target block rectangle
        long anchorMinX = targetMinX - maxOffsetX;
        long anchorMaxX = targetMaxX - minOffsetX;
        long anchorMinZ = targetMinZ - maxOffsetZ;
        long anchorMaxZ = targetMaxZ - minOffsetZ;

        long minChunkX = Math.floorDiv(anchorMinX, 16L);
        long maxChunkX = Math.floorDiv(anchorMaxX, 16L);
        long minChunkZ = Math.floorDiv(anchorMinZ, 16L);
        long maxChunkZ = Math.floorDiv(anchorMaxZ, 16L);
        if (minChunkX < Integer.MIN_VALUE || maxChunkX > Integer.MAX_VALUE
                || minChunkZ < Integer.MIN_VALUE || maxChunkZ > Integer.MAX_VALUE)
            throw new IllegalArgumentException("Feature bounds exceed supported chunk coordinates");

        long count = (maxChunkX - minChunkX + 1L) * (maxChunkZ - minChunkZ + 1L);
        if (count > 1_000_000L) throw new IllegalArgumentException("Feature dependency halo is unreasonably large: " + count);
        Set<ChunkPos> result = new TreeSet<>();
        for (long x = minChunkX; x <= maxChunkX; x++)
            for (long z = minChunkZ; z <= maxChunkZ; z++) result.add(new ChunkPos((int) x, (int) z));
        return Set.copyOf(result);
    }
}
