# Stage 9 — transactional placement to durable journal bridge

Target PNX commit: `c57499365737654eca32df008751ef6bca5af142`.

This stage adds a platform-neutral transaction coordinator that turns nested Terra placement scopes into one durable write-ahead-journal frame per root placement.

## Semantics

- Root scope owns the stable `PlacementKey`, priority, and conflict policy.
- Nested Terra structure scopes are savepoints. Their descriptor may differ, but they inherit the root identity and policy.
- Nested commit merges writes into its parent only; it never appends independently.
- Nested abort discards only that savepoint's writes.
- Root abort discards the entire placement.
- Root commit encodes all staged block states first, then appends one complete placement frame through `CrossChunkPlacementJournal.append()`.
- Encoding or WAL failure leaves the root scope open, so the caller can retry or explicitly abort. No partial journal frame is published by the coordinator.
- Each committed write receives a deterministic ordinal based on the root placement's write order; the journal rejects duplicate ordinals.
- Scopes are thread-confined and must close in LIFO order.

## API integration point

`PlacementTransactionCoordinator<S>` accepts a `StateEncoder<S>`. In PNX-Terra, instantiate it with `PnxBlockStatePayloadCodec::encode` and stage the actual `org.powernukkitx.block.BlockState` from `PNXServerWorld.setBlockState()` in the active scope. The Terra `PlacementScopeProvider` adapter must derive the root `PlacementKey` from the root `PlacementDescriptor` plus world seed/dimension and pass nested descriptors through `begin()`; nested descriptors are intentionally mapped to the inherited root identity.

The PNX adapter must still preserve the current transactional read overlay for `getBlockState()` and must route both block layers through the same root transaction. This stage does not silently replace or modify the existing `PNXServerWorld` implementation.

## Validation

Standalone core compiled with `javac --release 21 -Xlint:all -Werror`.

Passed:
- journal durability, duplicate identity, conflict selection, negative chunk coordinates, torn-tail recovery;
- dependency bounds/barriers and late digest invalidation;
- generation request coalescing/retry;
- dependency scheduler failure propagation;
- nested savepoint commit and abort isolation;
- atomic cross-chunk root publication;
- root identity inheritance for nested descriptors;
- encoder failure leaves scope open and publishes no operations;
- WAL recovery of cross-chunk placement.

## Not yet complete

- No concrete `PNXServerWorld` wiring yet; this is the tested transaction bridge core.
- No exact descriptor-to-key adapter (world seed, dimension ID, rotation encoding and root path must be bound in the PNX-Terra integration).
- No PNX/Terra Gradle build or runtime test.
- No concrete chunk persister or publication gate; these remain separate integration work.
- No entity or block-entity transaction journal.
- No production server files, world data, player data, configuration, plugins, or JARs were modified.
