package org.powernukkitx.terra.crosschunk.journal;

public sealed interface JournalEvent permits JournalEvent.PlacementCommitted, JournalEvent.AnchorCompleted {
    record PlacementCommitted(long sequence, PlacementRecord record) implements JournalEvent {}
    record AnchorCompleted(long sequence, String worldKey, ChunkPos anchor) implements JournalEvent {}
}
