package org.powernukkitx.terra.crosschunk.runtime;

import org.powernukkitx.level.Level;
import org.powernukkitx.level.format.IChunk;
import org.powernukkitx.terra.crosschunk.journal.ChunkPos;
import org.powernukkitx.terra.crosschunk.journal.PlacementJournal;
import org.powernukkitx.terra.crosschunk.scheduler.CrossChunkDependencyScheduler;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/** Per-world journal runtime shared by concurrent PNX chunk-population workers. */
public final class PnxGenerationJournalRuntime implements AutoCloseable {
    private final String worldKey;
    private final Level level;
    private final PlacementJournal journal;
    private final CrossChunkDependencyScheduler scheduler;
    private final Set<ChunkPos> dependencyPrefetch = ConcurrentHashMap.newKeySet();

    private PnxGenerationJournalRuntime(String worldKey, Level level, PlacementJournal journal) {
        this.worldKey=worldKey;this.level=level;this.journal=journal;
        this.scheduler=new CrossChunkDependencyScheduler(worldKey,journal,this::requestAnchor);
    }

    public static PnxGenerationJournalRuntime open(Path directory,Level level,int dimensionId)throws IOException{
        Objects.requireNonNull(directory,"directory");Objects.requireNonNull(level,"level");
        String worldKey=level.getName()+"|"+level.getSeed()+"|dimension="+dimensionId;
        Path wal=directory.resolve(sha256(worldKey)+".pnxterra.wal");
        return new PnxGenerationJournalRuntime(worldKey,level,new PlacementJournal(wal));
    }
    public String worldKey(){return worldKey;}
    public CrossChunkDependencyScheduler scheduler(){return scheduler;}
    public CompletableFuture<Void> registerTarget(ChunkPos target,int maxReachBlocks,boolean requestDependencies){
        return scheduler.registerTarget(target,maxReachBlocks,maxReachBlocks,requestDependencies);
    }
    public CompletableFuture<Void> activateTarget(ChunkPos target){return scheduler.activateTarget(target);}
    public CrossChunkDependencyScheduler.AnchorSession openAnchor(ChunkPos anchor){return scheduler.openAnchor(anchor);}
    public PlacementJournal journal(){return journal;}

    /** True once for chunks queued only as source anchors; prevents infinite recursive prefetch. */
    public boolean consumeDependencyPrefetch(ChunkPos anchor){return dependencyPrefetch.remove(anchor);}

    /** Non-blocking, queue-aware source-anchor request. False means PNX's generation queue was full. */
    private boolean requestAnchor(ChunkPos anchor){
        if(journal.isAnchorCompleted(worldKey,anchor))return true;
        if(level.isChunkGenerating(anchor.x(),anchor.z()))return true;
        IChunk loaded=level.getChunkIfLoaded(anchor.x(),anchor.z());
        if(loaded!=null&&loaded.getChunkState().canSend()){
            throw new IllegalStateException("Existing finished chunk has no Terra anchor WAL marker: "+anchor+
                    ". Refusing to treat an unjournaled chunk as a complete dependency.");
        }
        dependencyPrefetch.add(anchor);
        level.generateChunk(anchor.x(),anchor.z());
        if(level.isChunkGenerating(anchor.x(),anchor.z())||journal.isAnchorCompleted(worldKey,anchor))return true;
        dependencyPrefetch.remove(anchor);
        return false;
    }

    private static String sha256(String value){
        try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));}
        catch(NoSuchAlgorithmException impossible){throw new IllegalStateException("SHA-256 unavailable",impossible);}
    }
    @Override public void close()throws IOException{journal.close();}
}
