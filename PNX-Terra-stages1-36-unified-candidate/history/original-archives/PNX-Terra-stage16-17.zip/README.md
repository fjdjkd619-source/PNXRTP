# PNX-Terra — Stage 16 + Stage 17

**Target source revisions**

- PowerNukkitX: `c57499365737654eca32df008751ef6bca5af142` (3.0.6)
- PNX-Terra: `74318b4a1eae95322550f12d5eb8a76d92a93731` (1.0.0)
- Terra: `05ddc8b8a66e17412670647cce78ef837b091256` (6.6.1-BETA)
- Origen: `228426bb192a8d6029952aae1a77008dea5f3cda` (2.2.0)

## What is included

### Stage 16 — durable cross-chunk placement journal

- Append-only WAL with versioned frames, length bounds, CRC32C, and `FileChannel.force(true)` before a successful commit returns.
- Exclusive process file lock; torn or corrupt tail is truncated to the last valid frame during recovery.
- Stable SHA-256 placement identity; idempotent retry of the same root transaction; different payload under the same key is rejected.
- Canonical PNX block-state payload stores namespaced block identifier and named property values. It does **not** persist a runtime/network block ID or `blockStateHash` as the journal identity.
- Both PNX block layers are represented in `BlockWrite`.
- Deterministic cell conflict resolution: within one placement, the last write to a cell wins; between placements, the lexicographically lowest stable placement ID wins.
- PNX-Terra root commit now appends the entire root placement to WAL before merging anchor-local writes into the current generation batch. Cross-chunk writes remain in WAL for the Stage 18 applier.

### Stage 17 — anchor population lifecycle and dependency barrier

- Computes the conservative source-anchor set from the target chunk and maximum active horizontal feature reach, including negative chunk coordinates.
- A target barrier becomes ready only after every expected source anchor has a durable population-complete marker.
- Anchor completion is appended only after Terra PopulateStage ends and every in-flight root placement ticket has either committed durably or aborted.
- Missing source anchors are requested through PNX `Level.generateChunk`; queue-full requests are released for retry rather than blocking a generation thread.
- Dependency-prefetched chunks do not recursively request their own neighbors. When such a chunk later becomes player-demanded, Stage 18 must call `activateTarget` to request its own dependencies.
- No scheduler path synchronously waits for a neighboring chunk or force-loads it.

## Patch order

These are incremental patches on top of Stage 15. Do not apply Stage 16/17 to unpatched upstream files.

1. Apply Stage 15 Terra Core patch and build the patched Terra artifact.
2. Apply Stage 15 PNX-Terra adapter patch.
3. Apply `PNX-Terra-stage16-17-adapter.patch` to the PNX-Terra repository.
4. Apply `PNX-Terra-stage16-17-terra-generator.patch` to the same PNX-Terra repository.
5. Build Terra and PNX-Terra against the pinned PNX source/API, then run isolated runtime tests before considering any server installation.

The default WAL directory is `plugins/PNX-Terra/journal`. It can be changed through the Terra generator option `cross-chunk-journal-dir`. Keep this directory persistent across restarts and back it up with the world.

## Important boundary — Stage 18 is still required

Stage 16/17 persist placements and coordinate dependencies, but they do **not** yet apply WAL projections to neighboring chunks or prevent a target chunk from being sent to a player. Stage 18 must:

1. call `activateTarget(target)` before finalization of a player-demanded target;
2. wait asynchronously for the returned barrier;
3. project all winning journal writes for the target chunk;
4. apply only to an already loaded, generated, initialized chunk without force-loading;
5. save the chunk and acknowledge its digest only after persistence;
6. gate every chunk publication/send path until the dependency barrier and applied digest are complete.

Until Stage 18 is complete, cross-chunk structures are journaled but not yet materialized in their neighboring chunks. **Do not install this package on the production server.**

## Compatibility and migration safety

A finished chunk without a matching durable anchor marker is rejected as an unjournaled dependency. This is intentional fail-closed behavior; it avoids assuming that an old chunk has a complete cross-chunk history. The first end-to-end rollout should use a new/test world or a separately designed migration path.
