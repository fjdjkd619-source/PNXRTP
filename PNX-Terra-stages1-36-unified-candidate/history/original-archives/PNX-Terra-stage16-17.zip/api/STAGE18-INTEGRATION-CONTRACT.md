# Stage 18 integration contract

The Stage 16/17 API intentionally separates durable placement commit from chunk materialization.

## Required target finalization sequence

1. Resolve the target `ChunkPos` and call `runtime.activateTarget(target)`.
2. Await its `CompletableFuture` asynchronously; never block a PNX generation worker waiting for another chunk.
3. Obtain `journal.placementsFor(target)` and call `PlacementProjection.resolve(records, target)`.
4. Check `Level.getChunkIfLoaded(x,z)`; require loaded + generated + initiated state. Never call `Level.getChunk(..., true)` from the applier.
5. Decode each canonical state with `PnxBlockStateCodec.decode(payload)` and stage writes by local coordinates and layer.
6. Apply the projection only after all source anchors are durably complete.
7. Persist the target chunk, then record the applied digest/ledger acknowledgement.
8. Make the chunk publishable only after dependency barrier + digest acknowledgement. Audit every `ChunkState.canSend()` and packet send path for bypasses.

## Failure and retry rules

- Missing/unloaded target chunk: defer; do not force-load.
- Missing source anchor marker: keep target unfinalized and retry source-anchor requests through `activateTarget`.
- WAL append failure: abort the root placement; never merge it into the live PNX batch.
- Chunk save failure: do not acknowledge the digest and do not publish.
- New journal records after a prior projection: invalidate the digest and reapply before finalization.
- Conflict selection must always use `PlacementProjection`; do not rely on asynchronous arrival order.

## Entity and block-entity boundary

The current Stage 15 guard still rejects entity-bearing structures. Block-entity adapters (containers, signs, spawners, loot/state) are also not covered by the block-state WAL codec. Those require a separate atomic intent format before enabling such structures.
