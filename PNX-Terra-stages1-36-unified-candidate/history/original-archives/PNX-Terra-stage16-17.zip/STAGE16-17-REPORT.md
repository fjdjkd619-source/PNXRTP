# Отчёт: Stage 16 и Stage 17

## Итог

Подготовлены исходный код ядра журнала и планировщика зависимостей, PNX block-state codec, PNX placement bridge, а также incremental patches для PNX-Terra и `TerraGenerator`.

### Stage 16 — готовность исходников

1. WAL пишет записи в append-only формате: magic, длина, payload, CRC32C.
2. `force(true)` выполняется до подтверждения commit.
3. Повреждённый или оборванный хвост восстанавливается усечением до последнего проверенного frame.
4. Один WAL нельзя открыть двумя процессами одновременно: используется exclusive `FileLock`.
5. Идентификатор root placement строится из world key, seed, anchor, feature/structure IDs, origin, rotation и ordinal.
6. Повтор того же placement key с тем же payload идемпотентен; другой payload с тем же key отвергается.
7. Блоки сериализуются через identifier + именованные свойства; runtime/network ID не используется как долговременный идентификатор.
8. PNX layer 0 и layer 1 сохраняются отдельно.
9. Конфликты координат разрешаются детерминированно, независимо от порядка завершения генерационных задач.
10. `PNXServerWorld` сначала пишет root placement в WAL и только затем передаёт anchor-local записи в локальный `BlockManager`. Межчанковые записи остаются в WAL для Stage 18.

### Stage 17 — готовность исходников

1. Планировщик вычисляет все anchor chunks, чьи допустимые feature footprints могут пересекать целевой чанк.
2. Формулы используют floor/ceil division, корректные для отрицательных координат.
3. PNX `PopulateStage` открывает anchor session и регистрирует target barrier.
4. Каждая root placement получает ticket; commit ticket завершается только после durable WAL append.
5. Anchor complete marker пишется после завершения PopulateStage и закрытия всех placement tickets.
6. Source-anchor requests идут через `Level.generateChunk`, без синхронного ожидания.
7. Очередь PNX может отклонить запрос при заполнении; scheduler снимает его с pending-request set, чтобы `activateTarget` мог повторить попытку.
8. Dependency-prefetched chunks не инициируют рекурсивную загрузку соседей. Их собственный barrier активируется при player-demanded finalization на Stage 18.
9. Уже завершённый чанк без WAL marker отвергается, а не считается автоматически безопасным.

## Проверки

- `javac --release 21 -Xlint:all -Werror` — PASS для journal/scheduler ядра и тестов.
- `Stage16JournalTest` — PASS: monotonic sequence, idempotency, collision rejection, exclusive lock, CRC/torn-tail recovery, negative coordinates, concurrent appends, stable conflict winner.
- `Stage17DependencySchedulerTest` — PASS: negative-coordinate envelope, 9-anchor barrier, no recursive prefetch, queue rejection/retry, durable anchor completion, restart recovery, aborted root writes.
- Оба теста повторены 50 раз каждый: 100 запусков — PASS.
- PNX-facing codec/runtime bridge скомпилированы `javac -Xlint:all -Werror` против минимальных API stubs — PASS. Это проверка сигнатур/языка, **не** замена компиляции против полного PNX checkout.
- Stage 16/17 adapter patch `git apply --check` на Stage 15 source snapshot — PASS.
- TerraGenerator patch `git apply --check` на сохранённом снимке файла pinned PNX-Terra — PASS.
- Применённые результаты побайтно сравнены с подготовленными source files — PASS.

## Не выполнено / границы

- Полный Gradle build Terra — NOT RUN.
- Полный Gradle build PNX-Terra — NOT RUN.
- Запуск сервера и runtime generation test — NOT RUN.
- JAR не собран.
- Production server/world/config/plugins не изменялись.
- Межчанковое применение записей к соседним чанкам, digest ledger, save acknowledgement и блокировка публикации чанка относятся к Stage 18 и ещё не реализованы.

## Вывод

Stage 16 и Stage 17 подготовлены на уровне исходников и интеграционных патчей. Они обеспечивают durable запись root placements и dependency barrier с безопасной постановкой source anchors в очередь PNX. Однако конечная межчанковая генерация ещё не завершена: без Stage 18 соседние чанки пока не получают WAL writes, а отправка чанков ещё не защищена финализатором. Пакет не предназначен для установки на production.
