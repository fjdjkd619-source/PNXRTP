# Stage 15 — Terra ↔ PNX-Terra guarded placement integration

## Patch order

1. Apply `patches/PNX-Terra-stage15-terra-core.patch` to Terra 6.6.1-BETA at commit `05ddc8b8a66e17412670647cce78ef837b091256`.
2. Build the patched Terra artifact. PNX-Terra shades Terra, so the patched artifact—not the unmodified published Terra 6.6.1-BETA binary—must be used by the PNX-Terra build.
3. Apply `patches/PNX-Terra-stage15-adapter.patch` to PNX-Terra 1.0.0 at commit `74318b4a1eae95322550f12d5eb8a76d92a93731`.
4. Build PNX-Terra against the patched Terra artifact and the pinned PowerNukkitX 3.0.6 source commit `c57499365737654eca32df008751ef6bca5af142`.
5. Do not install on the production server until both builds and disposable-world tests pass.

## What the patches connect

- Terra `FeatureGenerationStage` opens one root placement scope per selected structure.
- `StructureScript` exposes its stable registry ID through `IdentifiedStructure`.
- Terra `StructureFunction` opens nested savepoints; `BufferedWorld` forwards the nested-scope request to the root adapter.
- PNX-Terra buffers each root placement in a private `BlockManager`; nested placements use child managers and merge into their parent only on success.
- Block reads and writes pass through the Stage 14 guard. Read availability is checked against transaction overlays, the PNX batch cache, or an already-loaded chunk. The adapter does not use `BlockManager.getBlockAt()` for TerraScript block reads.
- A guard violation poisons the root; the root batch is discarded.

## Deliberate fail-closed limits

- Only the audited `waterfall` and `dripstone_column` profiles are currently accepted by the adapter.
- `mangrove_tree_procedural` is withheld because it creates entities and this stage does not yet defer/commit entity intents atomically.
- Unknown/non-identified structures are skipped.
- Cross-chunk writes are rejected at root commit. `apply()` also refuses cross-chunk data rather than force-loading a neighbouring chunk. This is temporary until the durable cross-chunk journal and finalization barrier are integrated.
- Block-entity adapters for Terra loot/state operations are still absent.

These limits are intentionally restrictive. This stage is not the final endless-world generation build.
