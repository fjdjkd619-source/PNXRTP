package org.powernukkitx.terra.crosschunk.bounds;

public final class Stage15AdapterGuardContractTest {
    public static void main(String[] args) {
        waterfallReadEnvelopeIncludesWritePreflightReads();
        implicitWriteInspectionUsesWriteEnvelopeAndDoesNotConsumeScriptReadBudget();
        unknownAndEntityBearingProfilesRemainFailClosed();
        nestedDependenciesAreExplicit();
        System.out.println("Stage15AdapterGuardContractTest: PASS");
    }

    private static void waterfallReadEnvelopeIncludesWritePreflightReads() {
        ScriptBoundsProfile profile = OrigenBoundsCatalog.requireVerified("waterfall");
        check(profile.readBounds().maxY() >= profile.writeBounds().maxY(),
                "BlockFunction pre-write read must fit inside read envelope");
        PlacementRuntimeGuard guard = new PlacementRuntimeGuard(profile, 0, 64, 0, Bounds3i.QuarterTurn.NONE);
        guard.beforeRead(5, 66, 5, true);
        guard.complete();
    }

    private static void implicitWriteInspectionUsesWriteEnvelopeAndDoesNotConsumeScriptReadBudget() {
        ScriptBoundsProfile profile = OrigenBoundsCatalog.requireVerified("waterfall");
        PlacementRuntimeGuard guard = new PlacementRuntimeGuard(profile, 0, 64, 0, Bounds3i.QuarterTurn.NONE);
        for (int i = 0; i < profile.maxBlockWrites(); i++) {
            guard.beforeWrite(0, 64, 0);
            guard.beforeImplicitWriteRead(0, 64, 0, true);
        }
        check(guard.snapshot().reads() == 0, "adapter inspection is accounted by write budget");
        expect(BoundsViolationException.class,
                () -> guard.beforeImplicitWriteRead(0, 64, 0, false));
        check(guard.snapshot().state() == PlacementRuntimeGuard.State.FAILED,
                "unloaded implicit read poisons the root placement");
    }

    private static void unknownAndEntityBearingProfilesRemainFailClosed() {
        check(OrigenBoundsCatalog.find("castle").isEmpty(), "unknown structures stay disabled");
        check(OrigenBoundsCatalog.requireVerified("mangrove_tree_procedural").maxEntitySpawns() > 0,
                "mangrove profile requires entity intents and must be withheld by adapter");
    }

    private static void nestedDependenciesAreExplicit() {
        ScriptBoundsProfile waterfall = OrigenBoundsCatalog.requireVerified("waterfall");
        check(waterfall.transitiveDependencies().isEmpty(), "waterfall has no nested dependencies");
        ScriptBoundsProfile mangrove = OrigenBoundsCatalog.requireVerified("mangrove_tree_procedural");
        check(mangrove.transitiveDependencies().contains("mangrove_leaves_clump"),
                "mangrove nested dependency is explicitly allow-listed");
        check(!mangrove.transitiveDependencies().contains("unlisted_structure"),
                "unlisted nested structure is not allowed by the root profile");
    }

    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    private static void expect(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable t) { if (type.isInstance(t)) return; throw new AssertionError(t); }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
}
