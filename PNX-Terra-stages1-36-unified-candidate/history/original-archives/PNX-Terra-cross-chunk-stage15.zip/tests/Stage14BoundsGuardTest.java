package org.powernukkitx.terra.crosschunk.bounds;

public final class Stage14BoundsGuardTest {
    public static void main(String[] args) {
        verifiesKnownProfilesAndUnknownFailClosed();
        enforcesWritesReadsAndEntities();
        rotatesAndTranslatesBounds();
        recordsObservedExtents();
        rejectsReadsThatWouldForceChunkLoads();
        sharesGuardAcrossNestedWorldContexts();
        System.out.println("Stage14BoundsGuardTest: PASS");
    }

    private static void verifiesKnownProfilesAndUnknownFailClosed() {
        check(OrigenBoundsCatalog.allVerified().size() == 3, "three audited profiles");
        check(OrigenBoundsCatalog.find("waterfall").isPresent(), "waterfall profile");
        check(OrigenBoundsCatalog.requireVerified("mangrove_tree_procedural").writeBounds().maxY() == 28, "mangrove top closure bound");
        check(OrigenBoundsCatalog.find("castle").isEmpty(), "unknown remains unknown");
        expect(IllegalStateException.class, () -> OrigenBoundsCatalog.requireVerified("castle"));
    }

    private static void enforcesWritesReadsAndEntities() {
        ScriptBoundsProfile p = OrigenBoundsCatalog.requireVerified("waterfall");
        PlacementRuntimeGuard guard = new PlacementRuntimeGuard(p, 0, 64, 0, Bounds3i.QuarterTurn.NONE);
        guard.beforeWrite(5, 14, 5);
        guard.beforeRead(-5, 15, -5, true);
        expect(BoundsViolationException.class, () -> guard.beforeWrite(6, 64, 0));
        check(guard.snapshot().state() == PlacementRuntimeGuard.State.FAILED, "violation poisons guard");
        expect(IllegalStateException.class, guard::complete);

        ScriptBoundsProfile mangrove = OrigenBoundsCatalog.requireVerified("mangrove_tree_procedural");
        PlacementRuntimeGuard entityGuard = new PlacementRuntimeGuard(mangrove, 0, 64, 0, Bounds3i.QuarterTurn.NONE);
        entityGuard.beforeEntitySpawn(-2, 64, 0);
        entityGuard.beforeEntitySpawn(-2, 64, 0);
        entityGuard.beforeEntitySpawn(-2, 64, 0);
        expect(BoundsViolationException.class, () -> entityGuard.beforeEntitySpawn(-2, 64, 0));
    }

    private static void rotatesAndTranslatesBounds() {
        ScriptBoundsProfile p = OrigenBoundsCatalog.requireVerified("waterfall");
        PlacementRuntimeGuard guard = new PlacementRuntimeGuard(p, 100, 70, -100,
                Bounds3i.QuarterTurn.CLOCKWISE_90);
        guard.beforeWrite(100, 20, -100);
        guard.complete();
        StructureFootprint footprint = HorizontalFootprintProjection.project(p,
                Bounds3i.QuarterTurn.CLOCKWISE_90);
        check(footprint.minX() == -5 && footprint.maxX() == 5, "projected X bounds");
        check(footprint.minZ() == -5 && footprint.maxZ() == 5, "projected Z bounds");
        ScriptBoundsProfile mangrove = OrigenBoundsCatalog.requireVerified("mangrove_tree_procedural");
        StructureFootprint readHalo = HorizontalFootprintProjection.projectReads(mangrove,
                Bounds3i.QuarterTurn.NONE);
        check(readHalo.minX() == -31 && readHalo.maxX() == 31, "read halo remains separate");
    }

    private static void rejectsReadsThatWouldForceChunkLoads() {
        ScriptBoundsProfile p = OrigenBoundsCatalog.requireVerified("mangrove_tree_procedural");
        PlacementRuntimeGuard guard = new PlacementRuntimeGuard(p, 0, 64, 0, Bounds3i.QuarterTurn.NONE);
        expect(BoundsViolationException.class, () -> guard.beforeRead(31, 64, 0, false));
        check(guard.snapshot().state() == PlacementRuntimeGuard.State.FAILED, "unloaded read poisons guard");
    }

    private static void sharesGuardAcrossNestedWorldContexts() {
        ScriptBoundsProfile p = OrigenBoundsCatalog.requireVerified("waterfall");
        PlacementRuntimeGuard guard = new PlacementRuntimeGuard(p, 0, 64, 0, Bounds3i.QuarterTurn.NONE);
        check(PlacementGuardContext.current().isEmpty(), "context starts empty");
        PlacementGuardContext.Scope scope = PlacementGuardContext.installRoot(guard);
        try {
            check(PlacementGuardContext.current().orElseThrow() == guard, "root guard installed");
            expect(IllegalStateException.class, () -> PlacementGuardContext.installRoot(guard));
        } finally {
            scope.close();
        }
        check(PlacementGuardContext.current().isEmpty(), "context removed after close");
    }

    private static void recordsObservedExtents() {
        ScriptBoundsProfile p = OrigenBoundsCatalog.requireVerified("dripstone_column");
        PlacementRuntimeGuard guard = new PlacementRuntimeGuard(p, 32, 0, 48, Bounds3i.QuarterTurn.NONE);
        guard.beforeWrite(32, -10, 48);
        guard.beforeWrite(42, 100, 58);
        PlacementRuntimeGuard.Snapshot snapshot = guard.complete();
        check(snapshot.writes() == 2, "write count");
        check(snapshot.observedWrites().equals(new Bounds3i(32,-10,48,42,100,58)), "observed AABB");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static void expect(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable t) { if (type.isInstance(t)) return; throw new AssertionError("Expected " + type + " got " + t, t); }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
}
