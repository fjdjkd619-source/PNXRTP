package org.powernukkitx.terra.crosschunk;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;
import java.util.TreeMap;
import java.util.zip.CRC32C;

/**
 * Crash-recoverable write-ahead journal for committed Terra placements.
 * It deliberately knows nothing about PNX BlockState serialization or chunk
 * lifecycle: the platform adapter supplies stable statePayload bytes and owns
 * safe target-chunk application.
 *
 * A whole placement is one CRC-protected frame. A torn final frame is truncated
 * during recovery; a complete frame with a bad checksum is treated as corruption.
 */
public final class CrossChunkPlacementJournal implements AutoCloseable {
    private static final int MAGIC = 0x50545851; // PTXQ
    private static final short VERSION = 1;
    private static final int HEADER_BYTES = Integer.BYTES + Short.BYTES + Integer.BYTES + Integer.BYTES;
    private static final int MAX_FRAME_BYTES = 64 * 1024 * 1024;
    private static final int MAX_OPERATIONS = 2_000_000;
    private static final int MAX_STATE_BYTES = 1 * 1024 * 1024;

    private final Path path;
    private final FileChannel channel;
    private final Map<PlacementKey, byte[]> committed = new HashMap<>();
    private final Map<ChunkKey, List<CrossChunkOperation>> byTargetChunk = new HashMap<>();
    private boolean closed;

    public CrossChunkPlacementJournal(Path file) throws IOException {
        this.path = Objects.requireNonNull(file, "file").toAbsolutePath();
        Path parent = path.getParent();
        if (parent != null) Files.createDirectories(parent);
        if (!Files.exists(path)) Files.createFile(path);
        this.channel = recoverAndOpen();
    }

    /**
     * Durably publishes one root placement. Duplicate identical placement IDs
     * are ignored; reusing an ID for different operations is a hard error.
     */
    public synchronized boolean append(PlacementKey key, List<CrossChunkOperation> operations) throws IOException {
        ensureOpen();
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(operations, "operations");
        if (operations.isEmpty()) return false;
        if (operations.size() > MAX_OPERATIONS) throw new IOException("Placement exceeds operation limit");
        Set<Integer> ordinals = new HashSet<>();
        for (CrossChunkOperation op : operations) {
            if (!key.equals(op.placementKey())) throw new IllegalArgumentException("Operation belongs to another placement key");
            if (!ordinals.add(op.ordinal())) throw new IllegalArgumentException("Placement operation ordinals must be unique");
            if (op.statePayload().length > MAX_STATE_BYTES) throw new IOException("Block-state payload exceeds 1 MiB");
        }

        byte[] body = encodeBody(key, operations);
        byte[] fingerprint = sha256(body);
        byte[] prior = committed.get(key);
        if (prior != null) {
            if (!Arrays.equals(prior, fingerprint)) throw new IOException("Placement key collision with different payload: " + key);
            return false;
        }

        CRC32C crc = new CRC32C();
        crc.update(body, 0, body.length);
        ByteBuffer frame = ByteBuffer.allocate(HEADER_BYTES + body.length);
        frame.putInt(MAGIC).putShort(VERSION).putInt(body.length).putInt((int) crc.getValue()).put(body).flip();
        try (FileLock ignored = channel.lock()) {
            channel.position(channel.size());
            while (frame.hasRemaining()) channel.write(frame);
            channel.force(true);
        }
        publish(key, fingerprint, operations);
        return true;
    }

    /** Returns an immutable snapshot. The adapter must not mutate returned payloads. */
    public synchronized List<CrossChunkOperation> operationsForChunk(int chunkX, int chunkZ) {
        ensureOpen();
        List<CrossChunkOperation> list = byTargetChunk.get(new ChunkKey(chunkX, chunkZ));
        return list == null ? List.of() : stableOrder(list);
    }

    /**
     * Stable order for replay. This is not a final conflict resolver: the PNX
     * adapter must resolve REPLACEABLE_ONLY against the pre-placement terrain
     * and apply the documented policy semantics before touching a chunk.
     */
    public static List<CrossChunkOperation> stableOrder(List<CrossChunkOperation> operations) {
        List<CrossChunkOperation> copy = new ArrayList<>(operations);
        copy.sort(Comparator
                .comparingInt(CrossChunkOperation::x)
                .thenComparingInt(CrossChunkOperation::y)
                .thenComparingInt(CrossChunkOperation::z)
                .thenComparingInt(CrossChunkOperation::layer)
                .thenComparing(CrossChunkOperation::placementKey)
                .thenComparingInt(CrossChunkOperation::ordinal));
        return List.copyOf(copy);
    }

    /**
     * Deterministic per-block winner. EXCLUSIVE beats PRIORITY; PRIORITY beats
     * ALLOW; REPLACEABLE_ONLY participates only when the original terrain state
     * is replaceable. Equal-class candidates are resolved by descending
     * priority, then ascending stable placement key, then descending write
     * ordinal (so a later write by the same structure wins).
     */
    public static java.util.Optional<CrossChunkOperation> resolveWinner(
            List<CrossChunkOperation> operations, boolean baseIsReplaceable) {
        List<CrossChunkOperation> eligible = operations.stream()
                .filter(op -> op.policy() != CrossChunkOperation.ConflictPolicy.REPLACEABLE_ONLY || baseIsReplaceable)
                .toList();
        if (eligible.isEmpty()) return Optional.empty();
        CrossChunkOperation.ConflictPolicy tier = eligible.stream().anyMatch(op -> op.policy() == CrossChunkOperation.ConflictPolicy.EXCLUSIVE)
                ? CrossChunkOperation.ConflictPolicy.EXCLUSIVE
                : eligible.stream().anyMatch(op -> op.policy() == CrossChunkOperation.ConflictPolicy.PRIORITY)
                    ? CrossChunkOperation.ConflictPolicy.PRIORITY
                    : CrossChunkOperation.ConflictPolicy.ALLOW;
        return eligible.stream()
                .filter(op -> tier == CrossChunkOperation.ConflictPolicy.ALLOW
                        ? op.policy() == CrossChunkOperation.ConflictPolicy.ALLOW
                            || op.policy() == CrossChunkOperation.ConflictPolicy.REPLACEABLE_ONLY
                        : op.policy() == tier)
                .min(Comparator.comparingInt(CrossChunkOperation::priority).reversed()
                        .thenComparing(CrossChunkOperation::placementKey)
                        .thenComparing(Comparator.comparingInt(CrossChunkOperation::ordinal).reversed()));
    }

    private FileChannel recoverAndOpen() throws IOException {
        try (FileChannel read = FileChannel.open(path, StandardOpenOption.READ, StandardOpenOption.WRITE)) {
            long size = read.size(), offset = 0, validEnd = 0;
            ByteBuffer header = ByteBuffer.allocate(HEADER_BYTES);
            while (offset < size) {
                header.clear();
                int headerRead = readFully(read, header, offset);
                if (headerRead < HEADER_BYTES) break; // torn tail
                header.flip();
                int magic = header.getInt();
                short version = header.getShort();
                int length = header.getInt();
                int expectedCrc = header.getInt();
                if (magic != MAGIC || version != VERSION || length < 0 || length > MAX_FRAME_BYTES) {
                    throw new IOException("Invalid journal frame at byte " + offset);
                }
                if (offset + HEADER_BYTES + (long) length > size) break; // torn tail
                ByteBuffer bodyBuffer = ByteBuffer.allocate(length);
                if (readFully(read, bodyBuffer, offset + HEADER_BYTES) < length) break;
                byte[] body = bodyBuffer.array();
                CRC32C crc = new CRC32C();
                crc.update(body, 0, body.length);
                if ((int) crc.getValue() != expectedCrc) throw new IOException("Journal checksum mismatch at byte " + offset);
                Decoded decoded = decodeBody(body);
                byte[] fingerprint = sha256(body);
                byte[] old = committed.get(decoded.key());
                if (old != null && !Arrays.equals(old, fingerprint)) {
                    throw new IOException("Conflicting duplicate placement key in journal: " + decoded.key());
                }
                if (old == null) publish(decoded.key(), fingerprint, decoded.operations());
                offset += HEADER_BYTES + (long) length;
                validEnd = offset;
            }
            if (validEnd != size) {
                read.truncate(validEnd);
                read.force(true);
            }
        }
        FileChannel opened = FileChannel.open(path, StandardOpenOption.WRITE, StandardOpenOption.READ);
        opened.position(opened.size());
        return opened;
    }

    private void publish(PlacementKey key, byte[] fingerprint, List<CrossChunkOperation> operations) {
        committed.put(key, fingerprint.clone());
        for (CrossChunkOperation operation : operations) {
            ChunkKey target = new ChunkKey(operation.targetChunkX(), operation.targetChunkZ());
            byTargetChunk.computeIfAbsent(target, ignored -> new ArrayList<>()).add(operation);
        }
    }

    private static byte[] encodeBody(PlacementKey key, List<CrossChunkOperation> operations) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bytes)) {
            out.write(key.bytes());
            out.writeInt(operations.size());
            for (CrossChunkOperation op : operations) {
                out.writeInt(op.x()); out.writeInt(op.y()); out.writeInt(op.z());
                out.writeByte(op.layer()); out.writeInt(op.priority());
                out.writeByte(op.policy().ordinal()); out.writeInt(op.ordinal());
                out.writeInt(op.statePayload().length); out.write(op.statePayload());
            }
        }
        if (bytes.size() > MAX_FRAME_BYTES) throw new IOException("Placement journal frame exceeds 64 MiB");
        return bytes.toByteArray();
    }

    private static Decoded decodeBody(byte[] body) throws IOException {
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(body))) {
            byte[] keyBytes = in.readNBytes(32);
            if (keyBytes.length != 32) throw new EOFException("Missing placement key");
            PlacementKey key = PlacementKey.fromBytes(keyBytes);
            int count = in.readInt();
            if (count < 0 || count > MAX_OPERATIONS) throw new IOException("Invalid operation count: " + count);
            List<CrossChunkOperation> operations = new ArrayList<>(Math.min(count, 100_000));
            for (int i = 0; i < count; i++) {
                int x = in.readInt(), y = in.readInt(), z = in.readInt();
                int layer = in.readUnsignedByte(), priority = in.readInt();
                int policy = in.readUnsignedByte(), ordinal = in.readInt();
                int payloadLength = in.readInt();
                if (policy >= CrossChunkOperation.ConflictPolicy.values().length
                        || payloadLength <= 0 || payloadLength > MAX_STATE_BYTES) {
                    throw new IOException("Invalid operation record");
                }
                byte[] payload = in.readNBytes(payloadLength);
                if (payload.length != payloadLength) throw new EOFException("Truncated operation payload");
                operations.add(new CrossChunkOperation(x, y, z, layer, priority,
                        CrossChunkOperation.ConflictPolicy.values()[policy], key, ordinal, payload));
            }
            if (in.available() != 0) throw new IOException("Trailing bytes in placement journal frame");
            return new Decoded(key, List.copyOf(operations));
        } catch (IllegalArgumentException ex) {
            throw new IOException("Invalid placement journal record", ex);
        }
    }

    private static int readFully(FileChannel channel, ByteBuffer buffer, long position) throws IOException {
        int total = 0;
        while (buffer.hasRemaining()) {
            int read = channel.read(buffer, position + total);
            if (read < 0) break;
            if (read == 0) break;
            total += read;
        }
        return total;
    }

    private static byte[] sha256(byte[] input) {
        try { return java.security.MessageDigest.getInstance("SHA-256").digest(input); }
        catch (java.security.NoSuchAlgorithmException impossible) { throw new AssertionError(impossible); }
    }

    private void ensureOpen() { if (closed) throw new IllegalStateException("Journal is closed"); }

    @Override public synchronized void close() throws IOException {
        if (!closed) { closed = true; channel.close(); }
    }

    private record ChunkKey(int x, int z) {}
    private record Decoded(PlacementKey key, List<CrossChunkOperation> operations) {}
}
