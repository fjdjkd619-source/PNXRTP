# PNX-Terra cross-chunk stage 3 — durable placement journal core

Date: 2026-11-28

## Scope

This stage implements the deterministic identity and durable journal core needed by cross-chunk structure placement. It is intentionally **not described as a completed PNX chunk-application pipeline**: the exact PNX/PNX-Terra source checkout could not be fetched in this execution environment (DNS resolution for `github.com` failed), so no unverified lifecycle hooks or PNX serialization calls were invented.

Target revisions remain:
- PNX `c57499365737654eca32df008751ef6bca5af142`
- PNX-Terra `74318b4a1eae95322550f12d5eb8a76d92a93731`
- Terra `05ddc8b8a66e17412670647cce78ef837b091256`

## Implemented Java core

### `PlacementKey`
- Creates a SHA-256 identity from world seed, dimension, feature ID, structure ID, absolute anchor, rotation, and nested-call path.
- Uses domain separation and length-prefixed UTF-8 fields; avoids ambiguous string concatenation.
- Stable across thread scheduling, process restarts, and machine restarts, provided all supplied inputs are stable.
- The nested-call path is mandatory. The earlier stage-1 descriptor currently does not yet carry a collision-free nested-call path, so this must be wired before the key can be used in the live TerraScript path.

### `CrossChunkOperation`
- Stores absolute block coordinates, PNX layer (0/1), priority, conflict policy, placement key, deterministic operation ordinal, and opaque serialized block-state payload.
- Uses `Math.floorDiv` for chunk coordinates; negative world coordinates are handled correctly.
- Payload is opaque by design. PNX-specific block-state serialization is not guessed or faked here.

### `CrossChunkPlacementJournal`
- Append-only write-ahead journal; a complete placement is stored as one CRC32C-protected frame.
- `force(true)` is called before the placement is published into the in-memory target-chunk index.
- Restart recovery replays committed frames; a torn final frame is truncated; a complete frame with a bad checksum fails loudly rather than silently dropping data.
- Duplicate identical placement keys are idempotent. Reusing the same key with different content is rejected as a collision.
- Operations are indexed by target chunk and returned in stable order.
- Includes deterministic per-block conflict selection:
  - `EXCLUSIVE` wins over `PRIORITY` and `ALLOW`;
  - `PRIORITY` wins over `ALLOW`;
  - `REPLACEABLE_ONLY` is eligible only when the adapter says the original terrain state is replaceable;
  - ties use descending priority, then ascending stable placement key, then descending operation ordinal.

## Validation performed

Compiled the standalone core and smoke test with OpenJDK 21:

```text
javac -Xlint:all ...
PASS: deterministic conflict winner, replaceable-only guard, durable append,
      idempotency, negative-coordinate chunking, torn-tail recovery
```

There is one non-fatal `-Xlint:try` warning for the intentionally held `FileLock` resource. No third-party dependencies are used by these core classes.

This test is a standalone smoke test. It is not a PNX build, Terra build, plugin build, or server runtime test.

## Critical integration work still required

The durable journal is a necessary component, not yet the whole cross-chunk solution. The following must be integrated against the pinned source trees before it can be used on a server:

1. **Stable nested identity:** extend the Terra placement descriptor/context with a deterministic nested-call path/ordinal. The current stage-1 nested descriptor (`terrascript:nested`) can collide when the same nested structure is invoked repeatedly at the same origin.
2. **PNX block-state codec:** serialize the complete PNX `BlockState`, including property values and layer, and validate it on replay. The current journal accepts opaque payload bytes only.
3. **Transaction publication:** top-level `WriteTransaction.commit()` must encode its final ordered writes and append one journal placement before exposing the placement to chunk application. Nested commit remains a savepoint merge; nested abort remains local.
4. **No forced chunk loads:** replace the existing `PNXServerWorld.apply()` neighbor `getChunk(..., true)` behavior with a target-availability check that never initiates target generation recursively.
5. **Target-chunk lifecycle:** add a PNX-Terra target-chunk coordinator that applies queued operations after the target's own Terra feature population and before final lighting/heightmap publication. It must also handle late arrivals for already-generated chunks without losing the journal entry.
6. **Generation-order barrier:** a finalization stage alone is insufficient. A neighbor may commit a large structure after the target chunk has finalized. To guarantee a chunk is final before it is sent, each configured feature/structure needs declared write bounds (not a single global 32-block cap), and PNX's generation scheduler must account for the source-chunk halo without blocking worker threads into a deadlock. If PNX's scheduler cannot express that dependency, the implementation can only promise eventual convergence, not order-independent first-publication results.
7. **Deterministic block conflict application:** group operations by absolute block position and layer, evaluate `REPLACEABLE_ONLY` against a stable pre-placement terrain snapshot, select the winner using the journal policy, and apply the result. The application path must update heightmap and lighting safely.
8. **Block entities and entities:** the current stage-2 patch does not transactionally stage block-entity state/loot/signs/spawners or entity spawns. These need explicit commit actions and idempotent replay semantics before structures using them can be considered supported.
9. **Journal lifecycle:** world/dimension identity must select a separate journal namespace; journal compaction/retention and world deletion handling must be designed. The journal must be closed cleanly on plugin/server shutdown.
10. **Tests:** source-level application, exact PNX 3.0.6 compile, Terra fork compile, PNX-Terra compile, randomized generation-order tests, restart/replay tests, overlapping-structure tests, negative-coordinate tests, unloaded-target tests, and multi-thread stress tests.

## Important correctness conclusion

A naive queue that drains once at `PopulateStage` finish is not sufficient. It can miss writes committed later by neighboring source chunks. Likewise, a queue that calls `getChunk(..., true)` can recursively force target generation and reintroduce order/deadlock problems. The next integration step must first verify PNX's exact generation-task scheduling and establish a non-blocking dependency/barrier design using per-feature declared extents.

## Production status

- No production server changes.
- No production world/player/plugin/config data touched.
- No PNX/Terra/PNX-Terra JAR built or installed.
- No claim of full cross-chunk correctness or runtime compatibility.
