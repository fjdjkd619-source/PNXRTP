# Stage 13 Origen bounds inventory

This package contains a conservative source-derived inventory. Every script is UNKNOWN until bounded and validated. It is designed to be consumed by a fail-closed bounds registry, not as proof that current structures have finite known extents.
