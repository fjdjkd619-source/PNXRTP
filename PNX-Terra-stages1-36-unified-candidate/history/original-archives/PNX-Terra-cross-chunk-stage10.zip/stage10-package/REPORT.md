# PNX-Terra cross-chunk generation — Stage 10 report

Date: 2026-11-28  
Target PNX commit: `c57499365737654eca32df008751ef6bca5af142`  
Target PNX-Terra commit: `74318b4a1eae95322550f12d5eb8a76d92a93731`  
Java target: 21

## Result

Stage 10 connects the nested placement transaction core to the PNX-Terra world adapter. This is the first adapter stage where Terra structure writes can be routed into the durable placement WAL instead of being placed immediately into the general `BlockManager` cache.

## Implemented

### 1. Terra placement scope adapter

- `PNXServerWorld` implements `PlacementScopeProvider`.
- Stable placement identity uses world seed, numeric dimension ID, Terra feature ID, structure ID, absolute anchor and rotation ordinal.
- The transaction coordinator inherits the root key, priority and conflict policy across nested scopes.
- Root commits are WAL-durable before the scope is closed. Nested commits merge into their parent; aborts discard staged writes.
- `PNXProtoWorld` forwards the placement provider, which is essential because Terra's feature generation stage receives a proto-world rather than the server-world wrapper directly.

### 2. PNX block write/read bridge

- `PlacementTransactionCoordinator.writeCurrent()` routes adapter writes into the current transaction when one exists.
- `readCurrent()` provides a nested read overlay: a scope sees its own most recent writes and parent savepoint writes.
- `PNXServerWorld.setBlockState()` stages layer 0 and the existing water layer-1 heuristic. Transactional writes no longer enter `BlockManager`'s cross-chunk apply queue.
- `PNXServerWorld.getBlockState()` consults the transaction read overlay before the backing world.
- The old BlockManager path remains only for non-transactional adapter writes.

### 3. Current target chunk application

- `PnxJournalChunkApplier.applyAvailableToChunk(IChunk)` reads the committed journal snapshot for the supplied chunk only.
- It groups operations by absolute coordinate and layer, checks the target chunk is still the already-loaded instance, evaluates `REPLACEABLE_ONLY` using PNX `Block.canBeReplaced()`, decodes the canonical PNX state payload and writes directly through `IChunk.setBlockState()`.
- It recalculates the heightmap and marks the chunk changed.
- It never obtains neighboring chunks and does not invoke `BlockManager.applySubChunkUpdate()` for journal operations.
- `PNXServerWorld.apply()` checks that no placement scope leaked before applying the ordinary legacy queue and current-chunk journal snapshot.

### 4. Runtime ownership

- `TerraCrossChunkRuntime` opens one placement WAL and applied-chunk ledger per world dimension under the provider path: `terra-crosschunk/dimension-N/`.
- Runtime instances are shared by concurrent generation workers and closed by `TerraPlugin.onDisable()`.
- A transactional entity spawn is rejected explicitly. `PNXProtoWorld.spawnEntity()` now delegates to `PNXServerWorld`, ensuring the guard cannot be bypassed.

## Validation

### Standalone Java core

Compiled using `javac --release 21 -Xlint:all -Werror`. All five test suites passed:

- `JournalSmokeTest`
- `Stage4SmokeTest`
- `ChunkGenerationRequestCoordinatorTest`
- `CrossChunkDependencySchedulerTest`
- `PlacementTransactionCoordinatorTest`

The transaction test now additionally verifies:
- non-transactional `writeCurrent()` falls back cleanly;
- active root writes are staged;
- nested scopes can read parent writes;
- nested scopes can read their own writes.

### PNX/Terra adapter contract compile

Compiled all cross-chunk classes, runtime ownership, `PNXServerWorld`, `PNXProtoWorld` and `TerraPlugin` with `--release 21 -Xlint:all -Werror` against local API contract stubs. No compile errors or warnings.

This confirms Java syntax and the declared contract used by the adapter, but does not prove exact binary/API compatibility with the full repositories.

### Adapter behavior test

A separate fake-chunk contract test:
1. created a durable placement journal;
2. encoded a PNX block state;
3. appended a placement targeting an already-loaded chunk;
4. applied the journal snapshot through `applyAvailableToChunk()`;
5. verified exact identifier and special value, and verified the chunk was marked changed.

Result: PASS.

### Patch integrity

- `git diff --check`: PASS.
- `git apply --check` against a fresh Stage 9 baseline: PASS.
- Patch applied to a fresh copy; resulting changed adapter files byte-matched authored source: PASS.

Patch SHA-256: `b56ad4792c7effd315d0fd26d54f0e5b7ddd38f30dbac6a80fd4fa9df679502c`.

## Important unresolved work

Stage 10 is a real adapter integration milestone, but not a production-ready cross-chunk generation solution yet.

1. The earlier Terra API patch (`Terra-placement-scope-prototype.patch`) must first be applied and built. The official Terra 6.6.1-BETA artifact lacks the three placement-scope API types imported here. This Stage 10 patch will not compile against the unmodified Maven artifact.
2. `AppliedChunkLedger` is opened but not acknowledged from this stage. We still need the exact PNX provider save lifecycle, then mark the snapshot applied only after durable save.
3. A target chunk that already passed PopulateStage can receive a later journal operation. Stage 10 preserves that operation durably but does not yet apply it automatically to the already-finished chunk.
4. PNX client publication is not gated by journal finalization. `ChunkState.canSend()` and the packet-send path remain unchanged.
5. Entity placement is deliberately rejected inside a transaction until deferred entity commits are implemented.
6. Terra block entities, loot/container state, signs and spawners remain unsupported by the existing PNX-Terra adapter.
7. Terra's physics flag remains unresolved.
8. The build file still points at `server:nightly-SNAPSHOT`; a full dependency pin/build against exact PNX 3.0.6 remains necessary.

No PNX/Terra Gradle build or server runtime test was run. No production server state was changed.

## Next stage — Stage 11

- Inspect and hook the exact `LevelProvider.saveChunk`/`saveChunks` lifecycle.
- Ensure the current chunk cannot become sendable before its journal digest is stable and its chunk save succeeds.
- Connect the generation dependency scheduler to Terra's source-anchor bounds so late operations are known before target finalization.
- Re-run finalization if a new durable journal frame arrives before publication.
- Define a safe update path for already-published chunks if a late placement is unavoidable.
- Only then write `AppliedChunkLedger` acknowledgements.
