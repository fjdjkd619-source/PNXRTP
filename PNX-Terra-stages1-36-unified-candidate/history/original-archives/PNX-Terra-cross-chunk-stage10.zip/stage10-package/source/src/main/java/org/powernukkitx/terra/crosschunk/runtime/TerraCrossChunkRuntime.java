package org.powernukkitx.terra.crosschunk.runtime;

import org.powernukkitx.level.Level;
import org.powernukkitx.level.format.LevelProvider;
import org.powernukkitx.block.BlockState;
import org.powernukkitx.terra.crosschunk.AppliedChunkLedger;
import org.powernukkitx.terra.crosschunk.CrossChunkPlacementJournal;
import org.powernukkitx.terra.crosschunk.pnx.PnxBlockStatePayloadCodec;
import org.powernukkitx.terra.crosschunk.transaction.PlacementTransactionCoordinator;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Owns one durable placement journal per PNX world dimension. Files live next
 * to the world provider, not in a process-temporary directory. Instances are
 * shared by concurrent chunk-generation workers and closed by TerraPlugin.
 */
public final class TerraCrossChunkRuntime implements AutoCloseable {
    private static final Map<Path, TerraCrossChunkRuntime> INSTANCES = new HashMap<>();

    private final Path directory;
    private final CrossChunkPlacementJournal journal;
    private final AppliedChunkLedger ledger;
    private final PlacementTransactionCoordinator<BlockState> transactions;

    private TerraCrossChunkRuntime(Path directory) throws IOException {
        this.directory = directory;
        this.journal = new CrossChunkPlacementJournal(directory.resolve("placements.wal"));
        this.ledger = new AppliedChunkLedger(directory.resolve("applied-chunks.wal"));
        this.transactions = new PlacementTransactionCoordinator<>(journal, PnxBlockStatePayloadCodec::encode);
    }

    public static synchronized TerraCrossChunkRuntime forLevel(Level level) {
        Objects.requireNonNull(level, "level");
        LevelProvider provider = Objects.requireNonNull(level.getProvider(), "level provider");
        int dimension = provider.getDimensionData().getDimensionId();
        Path directory = Path.of(provider.getPath()).toAbsolutePath().normalize()
                .resolve("terra-crosschunk").resolve("dimension-" + dimension);
        try {
            TerraCrossChunkRuntime runtime = INSTANCES.get(directory);
            if (runtime == null) {
                runtime = new TerraCrossChunkRuntime(directory);
                INSTANCES.put(directory, runtime);
            }
            return runtime;
        } catch (IOException failure) {
            throw new UncheckedIOException("Cannot open Terra placement journal at " + directory, failure);
        }
    }

    public CrossChunkPlacementJournal journal() { return journal; }
    public AppliedChunkLedger ledger() { return ledger; }
    public PlacementTransactionCoordinator<BlockState> transactions() { return transactions; }
    public Path directory() { return directory; }

    public static synchronized void closeAll() throws IOException {
        IOException failure = null;
        for (TerraCrossChunkRuntime runtime : INSTANCES.values()) {
            try {
                runtime.close();
            } catch (IOException closeFailure) {
                if (failure == null) failure = closeFailure;
                else failure.addSuppressed(closeFailure);
            }
        }
        INSTANCES.clear();
        if (failure != null) throw failure;
    }

    @Override
    public void close() throws IOException {
        IOException failure = null;
        try { journal.close(); } catch (IOException e) { failure = e; }
        try { ledger.close(); } catch (IOException e) {
            if (failure == null) failure = e;
            else failure.addSuppressed(e);
        }
        if (failure != null) throw failure;
    }
}
