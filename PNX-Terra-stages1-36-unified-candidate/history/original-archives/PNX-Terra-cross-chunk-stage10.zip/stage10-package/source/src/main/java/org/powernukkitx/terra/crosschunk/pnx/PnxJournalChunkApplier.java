package org.powernukkitx.terra.crosschunk.pnx;

import org.powernukkitx.block.Block;
import org.powernukkitx.block.BlockState;
import org.powernukkitx.level.Level;
import org.powernukkitx.level.format.IChunk;
import org.powernukkitx.level.generator.object.BlockManager;
import org.powernukkitx.terra.crosschunk.AppliedChunkLedger;
import org.powernukkitx.terra.crosschunk.ChunkOperationDigest;
import org.powernukkitx.terra.crosschunk.ChunkPos;
import org.powernukkitx.terra.crosschunk.CrossChunkOperation;
import org.powernukkitx.terra.crosschunk.CrossChunkPlacementJournal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Predicate;

/**
 * Applies the durable journal snapshot to an already-loaded/generated PNX chunk.
 * It never requests or force-loads a target chunk. Persistence is injected so
 * the PNX integration can use its actual provider save path and acknowledge
 * only after that save has completed successfully.
 */
public final class PnxJournalChunkApplier {
    @FunctionalInterface
    public interface ChunkPersister {
        CompletableFuture<Void> persist(IChunk chunk);
    }

    public record ApplyResult(ChunkPos chunk, int operationsApplied, byte[] snapshotDigest) {
        public ApplyResult {
            snapshotDigest = snapshotDigest.clone();
        }
        @Override public byte[] snapshotDigest() { return snapshotDigest.clone(); }
    }

    private final Level level;
    private final CrossChunkPlacementJournal journal;
    private final AppliedChunkLedger ledger;
    private final Predicate<Block> replaceable;
    private final Executor generationExecutor;
    private final ConcurrentHashMap<ChunkPos, CompletableFuture<Void>> tails = new ConcurrentHashMap<>();

    public PnxJournalChunkApplier(Level level, CrossChunkPlacementJournal journal,
                                  AppliedChunkLedger ledger, Predicate<Block> replaceable,
                                  Executor generationExecutor) {
        this.level = Objects.requireNonNull(level, "level");
        this.journal = Objects.requireNonNull(journal, "journal");
        this.ledger = Objects.requireNonNull(ledger, "ledger");
        this.replaceable = Objects.requireNonNull(replaceable, "replaceable");
        this.generationExecutor = Objects.requireNonNull(generationExecutor, "generationExecutor");
    }

    /**
     * Serializes applications per target chunk. If new placements arrive while
     * the previous snapshot is being persisted, it takes and applies the newer
     * snapshot before completing. Failed persistence leaves the ledger
     * unacknowledged, so retry safely replays the idempotent snapshot.
     */
    public CompletableFuture<ApplyResult> applyLatest(ChunkPos target, ChunkPersister persister) {
        Objects.requireNonNull(target, "target");
        Objects.requireNonNull(persister, "persister");
        AtomicReference<CompletableFuture<ApplyResult>> result = new AtomicReference<>();
        tails.compute(target, (key, priorTail) -> {
            CompletableFuture<Void> base = priorTail == null
                    ? CompletableFuture.completedFuture(null)
                    : priorTail.handle((ignored, failure) -> null);
            CompletableFuture<ApplyResult> operation = base.thenComposeAsync(ignored -> applyUntilStable(key, persister), generationExecutor);
            result.set(operation);
            return operation.handle((ignored, failure) -> null);
        });
        return result.get();
    }

    private CompletableFuture<ApplyResult> applyUntilStable(ChunkPos target, ChunkPersister persister) {
        final List<CrossChunkOperation> snapshot = journal.operationsForChunk(target.x(), target.z());
        final byte[] digest = ChunkOperationDigest.calculate(snapshot);
        if (ledger.isApplied(target, digest)) {
            return CompletableFuture.completedFuture(new ApplyResult(target, 0, digest));
        }

        final IChunk chunk = level.getChunkIfLoaded(target.x(), target.z());
        if (chunk == null) {
            return CompletableFuture.failedFuture(new IllegalStateException(
                    "Target chunk is not loaded; refusing to force-load " + target));
        }
        if (!chunk.isGenerated() || !chunk.isInitiated()) {
            return CompletableFuture.failedFuture(new IllegalStateException(
                    "Target chunk is not generated and initialized: " + target));
        }

        final int applied;
        try {
            applied = applySnapshot(chunk, snapshot);
        } catch (Throwable failure) {
            return CompletableFuture.failedFuture(failure);
        }

        CompletableFuture<Void> persisted;
        try {
            persisted = Objects.requireNonNull(persister.persist(chunk), "persister returned null future");
        } catch (Throwable failure) {
            return CompletableFuture.failedFuture(failure);
        }
        return persisted.thenComposeAsync(ignored -> {
            try {
                ledger.markApplied(target, digest);
            } catch (IOException failure) {
                return CompletableFuture.failedFuture(failure);
            }
            byte[] currentDigest = ChunkOperationDigest.calculate(
                    journal.operationsForChunk(target.x(), target.z()));
            if (!java.security.MessageDigest.isEqual(digest, currentDigest)) {
                return applyUntilStable(target, persister);
            }
            return CompletableFuture.completedFuture(new ApplyResult(target, applied, digest));
        }, generationExecutor);
    }

    private int applySnapshot(IChunk chunk, List<CrossChunkOperation> operations) throws IOException {
        if (operations.isEmpty()) return 0;
        Map<BlockLayer, List<CrossChunkOperation>> candidates = new HashMap<>();
        for (CrossChunkOperation operation : operations) {
            if (operation.targetChunkX() != chunk.getX() || operation.targetChunkZ() != chunk.getZ()) {
                throw new IOException("Journal returned operation for the wrong target chunk");
            }
            if (operation.y() < chunk.getDimensionData().getMinHeight()
                    || operation.y() > chunk.getDimensionData().getMaxHeight()) {
                throw new IOException("Journal operation is outside dimension height: " + operation.y());
            }
            candidates.computeIfAbsent(new BlockLayer(operation.x(), operation.y(), operation.z(), operation.layer()),
                    ignored -> new ArrayList<>()).add(operation);
        }

        synchronized (chunk) {
        if (level.getChunkIfLoaded(chunk.getX(), chunk.getZ()) != chunk) {
            throw new IOException("Target chunk was unloaded before journal application: " + chunk.getX() + "," + chunk.getZ());
        }
        BlockManager manager = new BlockManager(level);
        int applied = 0;
        List<Map.Entry<BlockLayer, List<CrossChunkOperation>>> ordered = new ArrayList<>(candidates.entrySet());
        ordered.sort(Map.Entry.comparingByKey(Comparator.comparingInt(BlockLayer::x)
                .thenComparingInt(BlockLayer::y).thenComparingInt(BlockLayer::z).thenComparingInt(BlockLayer::layer)));
        for (var entry : ordered) {
            BlockLayer position = entry.getKey();
            BlockState baseState = chunk.getBlockState(position.x() & 15, position.y(), position.z() & 15, position.layer());
            Block baseBlock = Block.get(baseState, level, position.x(), position.y(), position.z(), position.layer());
            boolean canReplace = replaceable.test(baseBlock);
            var winner = CrossChunkPlacementJournal.resolveWinner(entry.getValue(), canReplace);
            if (winner.isEmpty()) continue;
            BlockState targetState = PnxBlockStatePayloadCodec.decode(winner.get().statePayload());
            manager.setBlockStateAt(position.x(), position.y(), position.z(), position.layer(), targetState);
            applied++;
        }
        manager.applySubChunkUpdate();
        return applied;
        }
    }

    /**
     * Applies the currently committed journal snapshot directly to the supplied
     * chunk. This is the generation-stage path: it never loads neighbouring
     * chunks and deliberately does not acknowledge persistence. The ordinary
     * PNX chunk-save lifecycle must finish before AppliedChunkLedger is updated
     * by the later persistence integration stage.
     */
    public int applyAvailableToChunk(IChunk chunk) throws IOException {
        Objects.requireNonNull(chunk, "chunk");
        ChunkPos target = new ChunkPos(chunk.getX(), chunk.getZ());
        List<CrossChunkOperation> snapshot = journal.operationsForChunk(target.x(), target.z());
        if (snapshot.isEmpty()) return 0;

        Map<BlockLayer, List<CrossChunkOperation>> candidates = new HashMap<>();
        for (CrossChunkOperation operation : snapshot) {
            if (operation.targetChunkX() != target.x() || operation.targetChunkZ() != target.z()) {
                throw new IOException("Journal returned operation for the wrong target chunk");
            }
            if (operation.y() < chunk.getDimensionData().getMinHeight()
                    || operation.y() > chunk.getDimensionData().getMaxHeight()) {
                throw new IOException("Journal operation is outside dimension height: " + operation.y());
            }
            candidates.computeIfAbsent(new BlockLayer(operation.x(), operation.y(), operation.z(), operation.layer()),
                    ignored -> new ArrayList<>()).add(operation);
        }

        synchronized (chunk) {
            if (level.getChunkIfLoaded(target.x(), target.z()) != chunk) {
                throw new IOException("Target chunk is no longer loaded: " + target);
            }
            int applied = 0;
            List<Map.Entry<BlockLayer, List<CrossChunkOperation>>> ordered = new ArrayList<>(candidates.entrySet());
            ordered.sort(Map.Entry.comparingByKey(Comparator.comparingInt(BlockLayer::x)
                    .thenComparingInt(BlockLayer::y).thenComparingInt(BlockLayer::z)
                    .thenComparingInt(BlockLayer::layer)));
            for (var entry : ordered) {
                BlockLayer position = entry.getKey();
                int localX = position.x() & 15;
                int localZ = position.z() & 15;
                BlockState baseState = chunk.getBlockState(localX, position.y(), localZ, position.layer());
                Block baseBlock = Block.get(baseState, level, position.x(), position.y(), position.z(), position.layer());
                var winner = CrossChunkPlacementJournal.resolveWinner(entry.getValue(), replaceable.test(baseBlock));
                if (winner.isEmpty()) continue;
                BlockState targetState = PnxBlockStatePayloadCodec.decode(winner.get().statePayload());
                chunk.setBlockState(localX, position.y(), localZ, targetState, position.layer());
                applied++;
            }
            if (applied > 0) {
                chunk.recalculateHeightMap();
                chunk.setChanged();
            }
            return applied;
        }
    }

    /** Remove an idle tail after the caller has completed chunk unload. */
    public boolean forget(ChunkPos chunk) {
        CompletableFuture<Void> tail = tails.get(chunk);
        return tail == null || (tail.isDone() && tails.remove(chunk, tail));
    }

    private record BlockLayer(int x, int y, int z, int layer) {}
}
