package org.powernukkitx.terra.delegate;

import org.powernukkitx.block.Block;
import org.powernukkitx.block.BlockID;
import org.powernukkitx.level.Level;
import org.powernukkitx.level.Position;
import org.powernukkitx.level.format.IChunk;
import org.powernukkitx.level.generator.object.BlockManager;
import org.powernukkitx.terra.PNXAdapter;
import org.powernukkitx.terra.TerraGenerator;
import org.powernukkitx.terra.crosschunk.ChunkPos;
import org.powernukkitx.terra.crosschunk.CrossChunkOperation;
import org.powernukkitx.terra.crosschunk.pnx.PnxJournalChunkApplier;
import org.powernukkitx.terra.crosschunk.runtime.TerraCrossChunkRuntime;
import org.powernukkitx.math.BlockVector3;
import com.dfsek.terra.api.block.entity.BlockEntity;
import com.dfsek.terra.api.block.state.BlockState;
import com.dfsek.terra.api.config.ConfigPack;
import com.dfsek.terra.api.entity.Entity;
import com.dfsek.terra.api.entity.EntityType;
import com.dfsek.terra.api.world.PlacementDescriptor;
import com.dfsek.terra.api.world.PlacementScope;
import com.dfsek.terra.api.world.PlacementScopeProvider;
import com.dfsek.terra.api.world.ServerWorld;
import com.dfsek.terra.api.world.biome.generation.BiomeProvider;
import com.dfsek.terra.api.world.chunk.Chunk;
import com.dfsek.terra.api.world.chunk.generation.ChunkGenerator;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.Objects;

public class PNXServerWorld implements ServerWorld, PlacementScopeProvider {

    private final TerraGenerator generatorWrapper;
    private final BlockManager level;
    private final Level handle;
    private final TerraCrossChunkRuntime crossChunkRuntime;
    private final PnxJournalChunkApplier journalApplier;

    public PNXServerWorld(TerraGenerator generatorWrapper, Level level) {
        this.generatorWrapper = Objects.requireNonNull(generatorWrapper, "generatorWrapper");
        this.handle = Objects.requireNonNull(level, "level");
        this.level = new BlockManager(level);
        this.crossChunkRuntime = TerraCrossChunkRuntime.forLevel(level);
        this.journalApplier = new PnxJournalChunkApplier(level,
                crossChunkRuntime.journal(), crossChunkRuntime.ledger(),
                Block::canBeReplaced, Runnable::run);
    }

    public TerraGenerator generatorWrapper() {
        return generatorWrapper;
    }

    public Level level() {
        return handle;
    }

    /**
     * Root Terra placements become durable journal frames. Nested placement
     * scopes are savepoints and inherit the root identity in the coordinator.
     */
    @Override
    public PlacementScope beginPlacement(PlacementDescriptor descriptor) {
        Objects.requireNonNull(descriptor, "descriptor");
        var origin = descriptor.origin();
        var rotation = descriptor.rotation();
        var dimension = Integer.toString(handle.getProvider().getDimensionData().getDimensionId());
        var key = org.powernukkitx.terra.crosschunk.PlacementKey.create(
                handle.getSeed(), dimension, descriptor.featureId(), descriptor.structureId(),
                origin.getX(), origin.getY(), origin.getZ(), rotation.ordinal(), "root");
        var scope = crossChunkRuntime.transactions().begin(key, 0, CrossChunkOperation.ConflictPolicy.ALLOW);
        return new PlacementScope() {
            private boolean closed;

            @Override
            public void commit() {
                ensureOpen();
                try {
                    scope.commit();
                    closed = true;
                } catch (IOException failure) {
                    throw new UncheckedIOException("Could not durably commit Terra placement " + key, failure);
                }
            }

            @Override
            public void abort() {
                ensureOpen();
                scope.abort();
                closed = true;
            }

            @Override
            public void close() {
                if (!closed) {
                    scope.close();
                    closed = true;
                }
            }

            private void ensureOpen() {
                if (closed) throw new IllegalStateException("Terra placement scope is already closed");
            }
        };
    }

    /**
     * Applies ordinary adapter writes and then the committed journal snapshot
     * for this chunk only. Journal application never asks PNX to load a
     * neighbouring chunk. Late arrivals for an already-populated chunk are
     * retained in the WAL and handled by the subsequent finalization stage.
     */
    public void apply(IChunk chunk) {
        crossChunkRuntime.transactions().assertNoOpenScopes();
        level.applySubChunkUpdate();
        try {
            journalApplier.applyAvailableToChunk(chunk);
        } catch (IOException failure) {
            throw new UncheckedIOException("Could not apply Terra journal to chunk "
                    + chunk.getX() + "," + chunk.getZ(), failure);
        }
    }

    @Override
    public void setBlockState(int x, int y, int z, BlockState blockState, boolean physics) {
        var innerBlockState = ((PNXBlockStateDelegate) blockState).innerBlockState();

        // Placement writes are staged, not published into BlockManager. This
        // prevents BlockManager.applySubChunkUpdate() from force-loading target
        // chunks while a large structure crosses chunk boundaries.
        if (crossChunkRuntime.transactions().writeCurrent(x, y, z, 0, innerBlockState)) {
            Block old = level.getBlockIfCachedOrLoaded(x, y, z);
            if (Objects.equals(innerBlockState.getIdentifier(), BlockID.KELP)
                    || Objects.equals(old.getId(), BlockID.WATERLILY)
                    || Objects.equals(old.getId(), BlockID.WATER)
                    || Objects.equals(old.getId(), BlockID.FLOWING_WATER)) {
                crossChunkRuntime.transactions().writeCurrent(x, y, z, 1, PNXProtoChunk.water);
            }
            return;
        }

        // Legacy non-placement writes retain the original adapter behavior.
        if (Objects.equals(innerBlockState.getIdentifier(), BlockID.KELP)) {
            level.setBlockStateAt(x, y, z, innerBlockState);
            level.setBlockStateAt(x, y, z, 1, PNXProtoChunk.water);
            return;
        }

        var ob = level.getBlockAt(x, y, z);
        if (Objects.equals(ob.getId(), BlockID.WATERLILY)
                || Objects.equals(ob.getId(), BlockID.WATER)
                || Objects.equals(ob.getId(), BlockID.FLOWING_WATER)) {
            level.setBlockStateAt(x, y, z, innerBlockState);
            level.setBlockStateAt(x, y, z, 1, PNXProtoChunk.water);
        } else {
            level.setBlockStateAt(x, y, z, innerBlockState);
        }
    }

    @Override
    public Entity spawnEntity(double x, double y, double z, EntityType entityType) {
        if (crossChunkRuntime.transactions().hasOpenScope()) {
            throw new UnsupportedOperationException("Entity spawning inside a transactional Terra placement "
                    + "is not supported yet; placement aborted to avoid partial structures");
        }
        String identifier = (String) entityType.getHandle();
        org.powernukkitx.entity.Entity nukkitEntity =
                org.powernukkitx.entity.Entity.createEntity(
                        identifier,
                        new Position(x, y, z, handle)
                );
        return new PNXEntity(nukkitEntity, this);
    }

    @Override
    public BlockState getBlockState(int x, int y, int z) {
        var staged = crossChunkRuntime.transactions().readCurrent(x, y, z, 0);
        if (staged.isPresent()) return PNXAdapter.adapt(staged.get());
        return PNXAdapter.adapt(level.getBlockAt(x, y, z).getBlockState());
    }

    @Override
    public BlockEntity getBlockEntity(int x, int y, int z) {
        org.powernukkitx.blockentity.BlockEntity blockEntity =
                handle.getBlockEntity(new BlockVector3(x, y, z));
        return null;
    }

    @Override
    public ChunkGenerator getGenerator() {
        return generatorWrapper.getHandle();
    }

    @Override
    public BiomeProvider getBiomeProvider() {
        return generatorWrapper.getBiomeProvider();
    }

    @Override
    public ConfigPack getPack() {
        return generatorWrapper.getConfigPack();
    }

    @Override
    public long getSeed() {
        return level.getSeed();
    }

    @Override
    public int getMaxHeight() {
        return generatorWrapper.getDimensionData().getMaxHeight();
    }

    @Override
    public int getMinHeight() {
        return generatorWrapper.getDimensionData().getMinHeight();
    }

    @Override
    public Level getHandle() {
        return handle;
    }

    @Override
    public Chunk getChunkAt(int x, int z) {
        return new PNXChunkDelegate(this, level.getChunk(x, z));
    }
}
