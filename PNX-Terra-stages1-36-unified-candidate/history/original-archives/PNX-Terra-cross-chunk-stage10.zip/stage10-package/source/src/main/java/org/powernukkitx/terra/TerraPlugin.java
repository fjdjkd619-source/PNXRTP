package org.powernukkitx.terra;

import org.powernukkitx.plugin.PluginBase;
import org.powernukkitx.terra.crosschunk.runtime.TerraCrossChunkRuntime;

import java.io.IOException;
import java.io.UncheckedIOException;

public class TerraPlugin extends PluginBase {

    private static TerraPlugin instance;

    public static TerraPlugin getInstance() {
        return instance;
    }

    @Override
    public void onLoad() {
        instance = this;
    }

    @Override
    public void onEnable() {
        PNXPlatform.getInstance();
        getLogger().info("Terra world generator registered, use \"terra\" as generator name");
    }

    @Override
    public void onDisable() {
        try {
            TerraCrossChunkRuntime.closeAll();
        } catch (IOException failure) {
            throw new UncheckedIOException("Failed to close Terra cross-chunk journals", failure);
        } finally {
            instance = null;
        }
    }
}
