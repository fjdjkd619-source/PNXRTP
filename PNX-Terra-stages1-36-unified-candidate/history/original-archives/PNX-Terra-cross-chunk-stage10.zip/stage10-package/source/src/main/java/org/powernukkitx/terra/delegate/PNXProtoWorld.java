package org.powernukkitx.terra.delegate;

import org.powernukkitx.level.Position;
import com.dfsek.terra.api.block.entity.BlockEntity;
import com.dfsek.terra.api.block.state.BlockState;
import com.dfsek.terra.api.config.ConfigPack;
import com.dfsek.terra.api.entity.Entity;
import com.dfsek.terra.api.entity.EntityType;
import com.dfsek.terra.api.world.PlacementDescriptor;
import com.dfsek.terra.api.world.PlacementScope;
import com.dfsek.terra.api.world.PlacementScopeProvider;
import com.dfsek.terra.api.world.ServerWorld;
import com.dfsek.terra.api.world.biome.generation.BiomeProvider;
import com.dfsek.terra.api.world.chunk.generation.ChunkGenerator;
import com.dfsek.terra.api.world.chunk.generation.ProtoWorld;

public record PNXProtoWorld(ServerWorld serverWorld, int centerChunkX, int centerChunkZ)
        implements ProtoWorld, PlacementScopeProvider {

    private static final java.util.logging.Logger LOGGER = java.util.logging.Logger.getLogger(PNXProtoWorld.class.getName());

    @Override public int centerChunkX() { return centerChunkX; }
    @Override public int centerChunkZ() { return centerChunkZ; }
    @Override public ServerWorld getWorld() { return serverWorld; }

    @Override
    public PlacementScope beginPlacement(PlacementDescriptor descriptor) {
        if (serverWorld instanceof PlacementScopeProvider provider) {
            return provider.beginPlacement(descriptor);
        }
        return PlacementScope.noop();
    }

    @Override
    public void setBlockState(int x, int y, int z, BlockState blockState, boolean physics) {
        serverWorld.setBlockState(x, y, z, blockState, physics);
    }

    @Override
    public Entity spawnEntity(double x, double y, double z, EntityType entityType) {
        return serverWorld.spawnEntity(x, y, z, entityType);
    }

    @Override public BlockState getBlockState(int x, int y, int z) { return serverWorld.getBlockState(x, y, z); }
    @Override public BlockEntity getBlockEntity(int x, int y, int z) { return null; }
    @Override public ChunkGenerator getGenerator() { return serverWorld.getGenerator(); }
    @Override public BiomeProvider getBiomeProvider() { return serverWorld.getBiomeProvider(); }
    @Override public ConfigPack getPack() { return serverWorld.getPack(); }
    @Override public long getSeed() { return getHandle().getSeed(); }
    @Override public int getMaxHeight() { return serverWorld.getMaxHeight(); }
    @Override public int getMinHeight() { return serverWorld.getMinHeight(); }
    @Override public ServerWorld getHandle() { return serverWorld; }
}
