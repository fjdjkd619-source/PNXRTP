# Stage 10 — PNX-Terra placement journal integration

Target adapter: PNX-Terra 1.0.0, commit `74318b4a1eae95322550f12d5eb8a76d92a93731`  
Target server API: PowerNukkitX commit `c57499365737654eca32df008751ef6bca5af142`  
Java target: 21

## What this stage integrates

- `PNXServerWorld` implements Terra's `PlacementScopeProvider` and creates a stable root placement key from world seed, dimension, feature/structure IDs, anchor and rotation.
- `TerraCrossChunkRuntime` owns one crash-recoverable placement WAL and applied-chunk ledger per world dimension, under the provider path at `terra-crosschunk/dimension-N/`.
- `PlacementTransactionCoordinator` now exposes `writeCurrent()` and `readCurrent()`. PNX-Terra routes block writes into the active nested transaction and reads its own uncommitted layer-0 writes.
- Nested Terra placement scopes remain savepoints; only root commit writes one durable journal frame.
- Layer-1 water is journaled alongside the layer-0 placement using the adapter's existing kelp/water heuristic.
- `PNXProtoWorld` also implements `PlacementScopeProvider`, forwarding the hook to `PNXServerWorld`; this is required because Terra feature generation receives the proto-world.
- `PNXServerWorld.apply()` checks for leaked scopes and applies only the journal snapshot for the current target chunk directly through `IChunk`. It does not ask PNX to load neighboring chunks. Heightmap is recalculated and the chunk is marked changed.
- The Terra plugin closes open journal/ledger files on disable.

## Required prerequisite

The PNX-Terra code in this patch imports three new Terra API types:

- `com.dfsek.terra.api.world.PlacementScope`
- `com.dfsek.terra.api.world.PlacementScopeProvider`
- `com.dfsek.terra.api.world.PlacementDescriptor`

These are introduced by the earlier `Terra-placement-scope-prototype.patch` against Terra 6.6.1-BETA. That Terra patch must be cleanly applied, compiled, and made available to the PNX-Terra build before this Stage 10 patch can compile. The official Maven Terra 6.6.1-BETA artifact does not contain these API additions.

Apply Stage 10 after the Stage 9 PNX-Terra source patch. The patch is incremental; it is not a standalone replacement for all previous stages.

## Explicit boundaries and safety behavior

1. **No persistence acknowledgement yet.** The current PopulateStage applies its current-chunk journal snapshot to the in-memory `IChunk`, but does not call `AppliedChunkLedger.markApplied()`. The WAL remains authoritative and replay-safe. A later stage must connect the exact PNX provider save lifecycle and only acknowledge after successful durable chunk save.
2. **No complete late-arrival finalization yet.** A write arriving after its target chunk has already passed PopulateStage remains in the WAL. It is not automatically applied to that already-finished chunk in this stage. The generation dependency barrier/finalization stage is still required.
3. **No client publication gate yet.** This patch does not change `ChunkState.canSend()` or the PNX packet-send path. Do not treat this as the final cross-chunk correctness implementation.
4. **Entities fail closed inside a placement.** `PNXProtoWorld.spawnEntity()` now delegates to `PNXServerWorld`; entity creation during an open transaction throws so a structure cannot commit blocks while silently losing its entities. Deferred entity journaling is a future stage.
5. **Block entities remain unsupported.** Terra block-entity reads still return null in the existing adapter. Chest loot, sign state and spawner configuration are not covered by this block-state journal.
6. **Physics argument remains unresolved.** Terra's `physics` flag is still not implemented by PNX-Terra's existing adapter.
7. Non-transactional writes retain the old BlockManager path. The current cross-chunk journal path is used for Terra placements wrapped by the earlier Terra API/generation-stage patch.
8. The `REPLACEABLE_ONLY` policy uses PNX `Block.canBeReplaced()` against the target chunk's pre-apply state. Other conflict policies use deterministic journal winner selection.

## Validation performed

- Standalone core and all five test suites compiled with `javac --release 21 -Xlint:all -Werror`.
- All five suites passed: journal recovery/conflicts, stage-4 bounds/barriers/ledger, request coordinator, dependency scheduler, placement transaction/savepoint tests.
- The PNX/Terra adapter source compiled with Java 21 against local contract stubs for the exact APIs used. This is a contract-stub compile, **not** a full PNX/Terra Gradle build.
- A separate adapter contract test wrote a real journal frame, decoded its PNX state payload, and applied it to an already-loaded fake `IChunk`; it passed.
- `git diff --check` passed.
- Stage 10 patch passed `git apply --check` on a fresh copy of the Stage 9 baseline, was applied, and resulting adapter files byte-matched the authored source.

## Not done

- No Gradle build against the full PNX 3.0.6 or Terra source trees.
- No server runtime test.
- No proof of durable chunk save/ledger acknowledgement or chunk-send gating.
- No automatic application of late journal arrivals to chunks already past PopulateStage.
- No production server files, worlds, player data, configuration, plugins or JARs were modified.
