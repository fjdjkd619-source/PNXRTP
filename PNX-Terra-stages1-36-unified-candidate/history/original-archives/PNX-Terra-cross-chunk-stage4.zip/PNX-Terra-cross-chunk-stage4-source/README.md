# PNX-Terra cross-chunk stage 4 — dependency barrier and apply ledger

This stage extends the standalone stage-3 core. It does not claim that PNX-Terra has been patched or that a plugin JAR has been built.

## New components

- `FeatureWriteBounds`: declares per-feature horizontal write extents relative to its anchor. Bounds must include all rotations and nested structure writes. Source chunks are calculated using block-rectangle intersection and `Math.floorDiv`, including negative coordinates.
- `GenerationBarrierCoordinator`: non-blocking dependency barrier. A target's readiness future completes only after every source chunk whose anchors could reach the target has completed its feature population. Failures propagate exceptionally. No worker thread blocks waiting for another chunk.
- `ChunkOperationDigest`: stable SHA-256 digest of a target chunk's complete operation snapshot.
- `AppliedChunkLedger`: crash-recoverable acknowledgement journal. A new late-arriving operation changes the digest, so an earlier acknowledgement no longer suppresses replay.

## Required integration contract

1. At world setup, collect the bounds of every enabled Terra feature. Bounds must conservatively contain every write after all rotations, nested offsets, decorators, and block-entity operations.
2. Before finalizing target chunk C, ask `GenerationBarrierCoordinator.awaitTarget(C, enabledBounds)`.
3. The PNX scheduler must ensure every source chunk in the returned dependency set is scheduled. Do not block a generation worker with `join()`, `get()`, `wait()`, or a monitor while waiting for another source chunk. Resume finalization asynchronously when the future completes.
4. A source chunk may be marked complete only after all of its feature placements have been committed to the durable placement journal.
5. After the barrier, obtain the latest operations for C, resolve conflicts against a stable pre-placement terrain snapshot, apply them, and persist/save C.
6. Only after target chunk persistence succeeds, call `AppliedChunkLedger.markApplied(C, ChunkOperationDigest.calculate(snapshot))`.
7. If a placement arrives after that snapshot was captured, the new digest differs; C must be scheduled for another apply pass before it is considered final/published.

## Important boundary

This core cannot itself schedule PNX chunk tasks, intercept PNX chunk publication, serialize PNX `BlockState`, update PNX heightmaps/light, or guarantee that clients never observe a chunk before the barrier. Those require exact source integration and scheduler hooks in the pinned PNX revision. Until those hooks are implemented, this is a tested design/core library, not an operational cross-chunk generator.

## Build and smoke test

Requires JDK 21 or newer:

```sh
javac --release 21 -Xlint:all -d out $(find main/java test/java -name '*.java')
java -cp out org.powernukkitx.terra.crosschunk.Stage4SmokeTest
```
