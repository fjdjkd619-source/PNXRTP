package org.powernukkitx.terra.delegate;

import org.powernukkitx.block.BlockAir;
import com.dfsek.terra.api.block.BlockType;
import com.dfsek.terra.api.block.state.BlockState;
import com.dfsek.terra.api.block.state.properties.Property;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public record PNXBlockStateDelegate(org.powernukkitx.block.BlockState innerBlockState) implements BlockState {
    @Override
    public boolean matches(BlockState blockState) {
        return ((PNXBlockStateDelegate) blockState).innerBlockState.equals(this.innerBlockState);
    }

    @Override
    public <T extends Comparable<T>> boolean has(Property<T> property) {
        return false;
    }

    @Override
    public <T extends Comparable<T>> T get(Property<T> property) {
        return null;
    }

    @Override
    public <T extends Comparable<T>> BlockState set(Property<T> property, T t) {
        return null;
    }

    @Override
    public BlockType getBlockType() {
        return new PNXBlockType(innerBlockState);
    }

    @Override
    public String getAsString(boolean properties) {
        var name = innerBlockState.getIdentifier();
        return switch (name) {
            case "minecraft:snow_layer" -> "minecraft:snow";
            case "minecraft:snow" -> "minecraft:snow_block";
            default -> name;
        };
    }

    @Override
    public boolean isAir() {
        return innerBlockState == BlockAir.STATE;
    }

    @Override
    public org.powernukkitx.block.BlockState getHandle() {
        return innerBlockState;
    }
}
